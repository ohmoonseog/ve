package kfi.core.vo;

import java.util.ArrayList;
import java.util.List;

public class BigExcelVO {

	private String fileName;

	// 운영시는 기본값을 true로...
	private boolean isDrm = false;

	private List<BigExcelSheetVO> bigExcelSheetVOList;

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public boolean getIsDrm() {
		return isDrm;
	}

	public void setIsDrm(boolean isDrm) {
		this.isDrm = isDrm;
	}

	public List<BigExcelSheetVO> getBigExcelSheetVOList() {
	    List<BigExcelSheetVO> returnList = new ArrayList<>();
	    returnList.addAll(bigExcelSheetVOList);
		return returnList;
	}

	public void setBigExcelSheetVOList(List<BigExcelSheetVO> bigExcelSheetVOList) {
	    this.bigExcelSheetVOList = new ArrayList<>();
		this.bigExcelSheetVOList.addAll(bigExcelSheetVOList);
	}


}
