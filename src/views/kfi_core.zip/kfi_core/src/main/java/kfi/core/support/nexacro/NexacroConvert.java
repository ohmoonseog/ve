package kfi.core.support.nexacro;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.context.request.NativeWebRequest;

import com.nexacro.uiadapter17.spring.core.context.NexacroContext;
import com.nexacro.uiadapter17.spring.core.context.NexacroContextHolder;
import com.nexacro17.xapi.tx.PlatformException;

import lombok.experimental.UtilityClass;

@UtilityClass
public class NexacroConvert {
	/**
     * <pre>
     * 데이터 변환을 수행하기 전 Request로 부터 Platform 데이터로의 변환을 수행한다.
     * </pre>
     *
     * @param nativeWebRequest
     * @return NexacroCachedData
     * @throws PlatformException
     */
    public NexacroContext prepareResolveArguments(NativeWebRequest nativeWebRequest) throws PlatformException {
        NexacroContext cache = (NexacroContext) parsePlatformRequestOrGetAttribute(nativeWebRequest);
        return cache;
    }
    
    /**
     * NexacroPlatform 형식의 Cache 데이터를 반환 한다.
     *
     * @return
     * @throws PlatformException 
     */
    private NexacroContext parsePlatformRequestOrGetAttribute(NativeWebRequest nativeWebRequest) throws PlatformException {
        
        // when already parsed. ex - methodArgumentResolver or interceptor 
        NexacroContext cache = NexacroContextHolder.getNexacroContext();
        if(cache != null) {
            return  cache;
        }
        
        HttpServletRequest servletRequest = (HttpServletRequest) nativeWebRequest.getNativeRequest();
        HttpServletResponse servletResponse = (HttpServletResponse) nativeWebRequest.getNativeResponse();
        
        cache = NexacroContextHolder.getNexacroContext(servletRequest, servletResponse);
        return cache;
    }
}