package kfi.core.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;


/**
 *
 * @className : ObjectUtil
 * @description : Object conver 지원하는 Utility Class 이다.
 *
 * @modification : 2018. 8. 1.(수정자) 최초생성
 *
 * @author AA lee
 * @Date 2018. 8. 1.
 * @version 1.0
 * @see
 *  == 개정이력(Modification Information) ==
 *
 *   수정일      수정자           수정내용
 *  -------    --------    ---------------------------
 *
 * Copyright (C) by AIRA All right reserved.
 */

/**
 *
 * @className : PropertyService
 * @description :시스템 Property를 조회하는 서비스 이다.
 *
 * @modification : 2020. 4. 10.(수정자) 최초생성
 *
 * @author hirob
 * @Date 2020. 4. 10.
 * @version 1.0
 * @see
 *  == 개정이력(Modification Information) ==
 *
 *   수정일                     수정자                  수정내용
 *  -------    --------    ---------------------------
 *  
 * Copyright (C) by KFI All right reserved.
 * (C) by KFI All right reserved.
 */
@PropertySource(value = {"classpath:config/property/application-${spring.profiles.active}.properties","classpath:config/property/application.properties"})
@Service
public class PropertyService {

	@Autowired
	Environment environment;


	public String getString(String name){

        return environment.getProperty(name);
    }

	public int getInt(String name){

        return Integer.parseInt(environment.getProperty(name));
    }

	public boolean getBoolean(String name){
        return "false".equals(environment.getProperty(name)) ? false : true;
    }
}
