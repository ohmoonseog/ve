package kfi.core.vo;

import java.io.Serializable;


import lombok.Data;

@Data
public class RestTemplateVO implements Serializable {

	private static final long serialVersionUID = -1150364070532030735L;
	int errCd = 0; 					// 에러코드
	String errMsg = null; 			// 에러메시지
	Object resturnObject = null; 	// 리턴 오프젝트
}
