package kfi.core.constants;



/**
 *
 * @className : Constants
 * @description : kfi 에서 사용하는 모든 상수를 관리한다.
 *
 * @modification : 2020. 4. 10.(수정자) 최초생성
 *
 * @author hirob
 * @Date 2020. 4. 10.
 * @version 1.0
 * @see
 *  == 개정이력(Modification Information) ==
 *
 *   수정일                     수정자                  수정내용
 *  -------    --------    ---------------------------
 *  
 * Copyright (C) by KFI All right reserved.
 * (C) by KFI All right reserved.
 */
public final class Constants {

    /**
     * 열 변경에 대한 정의 KEY값이다.
     *
     * client dataset을 server dataset으로 변환하는 과정에서 해당 ROW_TYPE column이 존재한다면 클라이언트에서 정의된 ROW_TYPE의 값을 근거로 rowType 을 지정한다.
     * client는 C(R)UD의 값을 서버로 전송하며 CUD 는 각각 C=INSERT U=UPDATE D=DELETE 의 rowType으로 변경한다.
     */
    public static final String KEY_ROW_TYPE = "rowStatus";

    /**
     * 열에 대한 순번을 정의한 값이다.
     */
    public static final String KEY_ROW_IDX = "ROW_IDX";

    public static final String REQUEST_BODY = "requestBody";

    public static final String ROW_TYPE_INSERT = "C";
    public static final String ROW_TYPE_UPDATE = "U";
    public static final String ROW_TYPE_DELETE = "D";

    public static final String USER_SESSION = "userSession";
    
    public static final String LOG_SEQ_NO = "logSeqNo";

    public static final String IMG_PATH = "/imgAcc/";

    public final static String ONLY_METADATA_RETURN = "ONLY_METADATA_RETURN"; // 메타데이터 코드

    public final static String ERROR_CODE = "ErrorCode"; // 응답 코드 ( >= 0 성공 , < 0 오류)
    public final static String ERROR_MSG = "ErrorMsg"; // 오류 메시지


    public final static String DATASET_ROW_TYPE = "ROW_TYPE"; // row type을 저장하기 위한 Key value

    public final static String SESSION_USER_DATASET_NAME = "gds_userInfo"; // Global User Info DataSet Name
    public final static String SESSION_USER_MAP_NAME = "USER"; // Global User Info Map Name

    public final static String PAGING_DATASET_NAME = "gds_pageInfo"; // Global Paging Info DataSet Name
    public final static String PAGING_MAP_NAME = "PAGE"; // Global Paging Info Map Name

    
    public final static int MAX_SELECT_NUM = 4000; //최대리스트 건수 
    public static ThreadLocal<Object> local = new ThreadLocal<Object>();
    
    public static final String MULTIPART_FILE = "coreMultipartFile";
    
    public static final String NEXACRO_VIEW = "nexacroView";
    public static final String JSON_VIEW = "jsonView";

}
