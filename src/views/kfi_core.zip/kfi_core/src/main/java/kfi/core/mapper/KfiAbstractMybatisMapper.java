package kfi.core.mapper;

import java.util.List;
import java.util.Map;
import egovframework.rte.psl.dataaccess.EgovAbstractMapper;
import kfi.core.util.KfiPaginationInfo;

public abstract class KfiAbstractMybatisMapper extends EgovAbstractMapper {

	/**
	 * 결과건수에 제한을 걸어둠
	 */
	public <E> List<E> selectList(String queryId) {
		List<E> rList = super.selectList(queryId);

//		if(rList.size() > Constants.MAX_SELECT_NUM){
//            throw new RuntimeException("조회된 데이터가 너무 많습니다.");
//        }
		return rList;
	}

	public <E> List<E> selectListAll(String queryId) {
		return super.selectList(queryId);
	}

	public <E> List<E> selectListAll(String queryId, Object parameterObject) {
		return super.selectList(queryId, parameterObject);
	}

//	public abstract <E> List<E> selectListAllForLog(String queryId);


	@SuppressWarnings({"rawtypes", "unchecked"})
    public <E> List<E> selectListForPaging(String queryId, Map<String, Object> map) {

		KfiPaginationInfo paginationInfo = new KfiPaginationInfo();

		/*
		 * 쿼리문에 select 범위를 정하기 위한 parameter 인 firstIndex 와 lastIndex 값을 구하기 위해서
		 * 먼저 currentPage 와 recordCountPerPage의 값(없을경우 default 값)이 필요하다
		 */

		// 보여줘야 할 페이지 값
		int currentPage;
		if(map.get("currentPage") != null){
			currentPage = Integer.parseInt((String)map.get("currentPage"));
		} else {
			currentPage = 1;
		}
		paginationInfo.setCurrentPageNo(currentPage);

		// 페이지당 표시 건수값
		int recordCountPerPage;
		if(map.get("recordCountPerPage") != null){
			// recordCountPerPage(페이지당 표시 건수값)의 값이 셋팅되어 넘어올 경우
			recordCountPerPage = Integer.parseInt((String)map.get("recordCountPerPage"));
			paginationInfo.setRecordCountPerPage(recordCountPerPage);
		} else {
			// recordCountPerPage(페이지당 표시 건수값)의 값이 넘어오지 않을 경우 paginationInfo 에 셋팅되어있는 default 값을 recordCountPerPage 로 셋팅한다.
			recordCountPerPage = paginationInfo.getRecordCountPerPage();
		}

		// 페이징 SQL의 조건절에 사용되는 시작 rownum.
		int firstIndex = paginationInfo.getFirstRecordIndex();
		// 페이징 SQL의 조건절에 사용되는 마지막 rownum.
		int lastIndex = paginationInfo.getLastRecordIndex();

		map.put("firstIndex", firstIndex);
		map.put("lastIndex", lastIndex);

		List<E> rList = super.selectList(queryId, map);

		int totCnt = 0;
		if(rList.size() > 0){
			if(((Map)rList.get(0)).get("totCnt") != null){
				totCnt = Integer.parseInt(((Map)rList.get(0)).get("totCnt").toString());
			}

			int sEnd;
			if(lastIndex > totCnt) sEnd = totCnt;
			else sEnd = lastIndex;

			for(int i=0; i<rList.size(); i++){
				((Map)rList.get(i)).put("currentPage", currentPage);
				((Map)rList.get(i)).put("recordCountPerPage", recordCountPerPage);
				//자동조회시 사용
				if(map.containsKey("nextRowYn")){
					String nextRowYn = "Y";
					nextRowYn = sEnd == totCnt ? "N":"Y";
					((Map)rList.get(i)).put("nextRowYn", nextRowYn);
				}
			}
		}

		return rList;
	}


	public <E> List<E> selectList(String queryId, Object parameterObject) {
		List<E> rList = super.selectList(queryId, parameterObject);
//		if(rList.size() > Constants.MAX_SELECT_NUM){
//		    throw new RuntimeException("조회된 데이터가 너무 많습니다.");
//		}
		return rList;
	}


	public <E> List<E> selectListForAll(String queryId, Object parameterObject) {
		return super.selectList(queryId, parameterObject);
	}
}
