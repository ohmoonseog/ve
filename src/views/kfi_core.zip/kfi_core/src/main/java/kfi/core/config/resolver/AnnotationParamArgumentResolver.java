/*
 * Copyright 2014 MOSPA(Ministry of Security and Public Administration).
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */
package kfi.core.config.resolver;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.springframework.core.MethodParameter;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.support.WebDataBinderFactory;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.method.support.ModelAndViewContainer;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import kfi.core.config.adapter.KfiRequestMappingHandlerAdapter;
import kfi.core.config.annotation.Param;
import kfi.core.constants.Constants;
import kfi.core.support.json.JsonConvertData;
import kfi.core.support.nexacro.NexacroConvertData;
import kfi.core.util.ReqestUtil;
import kfi.core.vo.UserSessionVO;


/**
*
* @className : AnnotationParamArgumentResolver
* @description : @param 이 선안된 Argument 를  사용하기 위한 Resolver class 이다
*
* @modification : 2020. 4. 7.(수정자) 최초생성
*
* @author hirob
* @Date 2020. 4. 7.
* @version 1.0
* @see ModelAndView{@link KfiRequestMappingHandlerAdapter}
*  == 개정이력(Modification Information) ==
*
*   수정일                     수정자                  수정내용
*  -------    --------    ---------------------------
*  
* Copyright (C) by KFI All right reserved.
* (C) by KFI All right reserved.
*/
@Component
public class AnnotationParamArgumentResolver implements HandlerMethodArgumentResolver {
    /**
     * AnnotationParamArgumentResolver를 쓰기 위하여
     * ArgumentResolver list에서 MapMethodProcessor보다 앞에 AnnotationParamArgumentResolver를 추가한다.
     * MapMethodProcessor의 기능을 살리기 위해 AnnotationParamArgumentResolver를 쓸 때는 @Param 을 붙여야 한다.
     *
     * @see Param
     */
    @Override
    public boolean supportsParameter(MethodParameter parameter) {
        return (Object.class.isAssignableFrom(parameter.getParameterType())) && parameter.hasParameterAnnotation(Param.class);
    }

    @Override
    public Object resolveArgument(MethodParameter parameter, ModelAndViewContainer mavContainer, NativeWebRequest webRequest, WebDataBinderFactory binderFactory) throws Exception {
        Map<String, Object> paramdMap = new HashMap<String, Object>();
        HttpServletRequest request = (HttpServletRequest) webRequest.getNativeRequest();
        String headerSvcType = request.getHeader("headerSvcType");
        Enumeration<?> enumeration = request.getParameterNames();
        if (enumeration.hasMoreElements()) {
            while (enumeration.hasMoreElements()) {
                String key = (String) enumeration.nextElement();
                String[] values = request.getParameterValues(key);
                if (values != null) {
                    paramdMap.put(key, (values.length > 1) ? values : values[0]);
                }
            }
        }
        if (headerSvcType !=null && headerSvcType.equals("nexacro")) {
            paramdMap.putAll(NexacroConvertData.getNexacroDataMap(webRequest));
            return paramdMap;
        } else {
            if (request.getContentType() != null && request.getContentType().toLowerCase().indexOf("multipart/form-data") > -1) {
                // session 값
                MultipartHttpServletRequest multiPartRequest = (MultipartHttpServletRequest) webRequest.getNativeRequest();
                Iterator<String> iter = multiPartRequest.getFileNames();
                List<MultipartFile> fileList = new ArrayList<MultipartFile>();
                while(iter.hasNext()) {
                    String uploadFileName = iter.next();
                    MultipartFile mFile = multiPartRequest.getFile(uploadFileName);
                    fileList.add(mFile);
                }
                paramdMap.put(Constants.MULTIPART_FILE, fileList);
                HttpSession session = (HttpSession) request.getSession();
                UserSessionVO userSessionVO = (UserSessionVO) session.getAttribute(Constants.USER_SESSION);
                String sessUserId =  null;
                String sessCmpyId =  null;
                
                if(userSessionVO != null){
                    sessUserId = userSessionVO.getUserId();
                    sessCmpyId = userSessionVO.getCmpyId();
                }
                //session 값 add
                if(sessUserId != null) {
                    paramdMap.put("sessUserId", sessUserId);
                }
                //session 값 add
                if(sessCmpyId != null) {
                    paramdMap.put("sessCmpyId", sessCmpyId);
                }
                paramdMap.put("sessIpAdr", ReqestUtil.getUserIP());
            } else {
                return JsonConvertData.getDataObject(request, parameter, paramdMap);
            }
        }
        return paramdMap;
    }

}
