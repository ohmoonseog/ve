package kfi.core.vo;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

public class BigExcelSheetVO {

	/** 엑셀의 해당시트 명 */
	private String sheetName;

	/** 시트 제목 */
	private String title;

	/** 엑셀의 해당시트에 적용되는 쿼리ID */
	private String queryId;

	/** 엑셀의 해당시트에 삽입되는 코멘트 */
	private String comment;

	/** 엑셀의 해당 시트에 적용되는 엑셀컴럼명과 쿼리결과의 키값과 매핑용 맵 */
	private LinkedHashMap<String, String> colMap;

	/** 엑셀의 해당 시트에 적용되는 DB쿼리의 검색용 맵 */
	private Map<String, Object> searchMap;

	public String getSheetName() {
		return sheetName;
	}

	public void setSheetName(String sheetName) {
		this.sheetName = sheetName;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getQueryId() {
		return queryId;
	}

	public void setQueryId(String queryId) {
		this.queryId = queryId;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public LinkedHashMap<String, String> getColMap() {
		return colMap;
	}

	public void setColMap(LinkedHashMap<String, String> parmaColMap) {
		colMap = parmaColMap;
	}

	public Map<String, Object> getSearchMap() {
	    Map<String , Object> resturMap = new HashMap<String, Object>();
	    resturMap.putAll(searchMap);
		return resturMap;
	}

	public void setSearchMap(Map<String, Object> paramSearchMap) {
	    this.searchMap = new HashMap<String, Object>();
	    if(paramSearchMap != null) {
	        this.searchMap.putAll(paramSearchMap);
	    }
	}

}
