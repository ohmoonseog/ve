package kfi.core.config.aspect;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.ModelAndView;

import kfi.core.constants.Constants;
import kfi.core.util.MessageUtils;

/**
 *
 * @className : MessageAspect
 * @description : 사용자 정의 message를 처리하기 위한 Aspect class 이다
 *
 * @modification : 2020. 4. 10.(수정자) 최초생성
 *
 * @author hirob
 * @Date 2020. 4. 10.
 * @version 1.0
 * @see
 *  == 개정이력(Modification Information) ==
 *
 *   수정일                     수정자                  수정내용
 *  -------    --------    ---------------------------
 *  
 * Copyright (C) by KFI All right reserved.
 * (C) by KFI All right reserved.
 */
@Aspect
@Component
public class MessageAspect {

	@Autowired(required=true)
	private HttpServletRequest request;

	/**
     * Controller 모든 메소드가 호출될때 공통 메시지 처리 힌다.
     * @param jp
     * Object retVal
     * @return
     * @throws Throwable
     */
    @Order(1)
    @AfterReturning(
    		        pointcut 	= " execution(* kfi..web.*Controller.*(..))"
    		      , returning = "retVal" )
    public void changeMsg( JoinPoint jp, Object retVal ) throws Throwable {
    	
    	String uri = request.getRequestURI();
//    	Long time = System.currentTimeMillis();
    	if( retVal != null && retVal.getClass() == ModelAndView.class ) {
    		ModelAndView model = (ModelAndView) retVal;
    		if(model.getViewName().indexOf("index.do") > 0 ) {
    		    return;
    		}
    		Map<String,Object> modelMap =model.getModel();
    		if(modelMap.get(Constants.ERROR_CODE) == null) {
    			model.addObject(Constants.ERROR_CODE, 0);
    		}
    		if(modelMap.get(Constants.ERROR_MSG) == null) {
    			if(uri.indexOf("select") != -1 || uri.indexOf("get") != -1) {
    				  model.addObject(Constants.ERROR_MSG, MessageUtils.getMessage("msg.common.select"));
				}else if(uri.indexOf("update") != -1) {
				  model.addObject(Constants.ERROR_MSG, MessageUtils.getMessage("msg.common.update"));
				}else if(uri.indexOf("save") != -1) {
					  model.addObject(Constants.ERROR_MSG, MessageUtils.getMessage("msg.common.save"));
				}else if(uri.indexOf("insert") != -1) {
				  model.addObject(Constants.ERROR_MSG, MessageUtils.getMessage("msg.common.insert"));
				}else if(uri.indexOf("delete") != -1) {
				  model.addObject(Constants.ERROR_MSG, MessageUtils.getMessage("msg.common.delete"));
				}else if(uri.indexOf("multi") != -1) {
					  model.addObject(Constants.ERROR_MSG, MessageUtils.getMessage("msg.common.multi"));
				}else if(uri.indexOf("process") != -1) {
					  model.addObject(Constants.ERROR_MSG, MessageUtils.getMessage("msg.common.process"));
				}else {
					model.addObject(Constants.ERROR_MSG, MessageUtils.getMessage("msg.request.msg"));
				}
    		}else {
    			int errorCode = (int) modelMap.get(Constants.ERROR_CODE);
    			if(errorCode == -9999) {
    				model.addObject(Constants.ERROR_CODE, -1);
    				model.addObject(Constants.ERROR_MSG, modelMap.get(Constants.ERROR_MSG));
    			}else {
    				Class<?> cls = (Class<?>) modelMap.get(Constants.ERROR_MSG).getClass();
    				if(cls.isAssignableFrom(String[].class)) {
    					String[] arrMsg =  (String[]) modelMap.get(Constants.ERROR_MSG);
    					
    					if(arrMsg.length > 1) {
    						String errorMsg = arrMsg[0];
    						String[] errorMsgAgmt = new String[arrMsg.length - 1];
    						for (int i = 1; i < arrMsg.length; i++) {
    							errorMsgAgmt[i-1] = arrMsg[i];
							}
    						model.addObject(Constants.ERROR_MSG, MessageUtils.getMessage(errorMsg,errorMsgAgmt));
    					}else {
    						model.addObject(Constants.ERROR_MSG, MessageUtils.getMessage(arrMsg[0]));
    					}
                    }else {
                    	model.addObject(Constants.ERROR_MSG, MessageUtils.getMessage((String) modelMap.get(Constants.ERROR_MSG)));
                    }
    				
    			}
    		}
    	}
    }

}
