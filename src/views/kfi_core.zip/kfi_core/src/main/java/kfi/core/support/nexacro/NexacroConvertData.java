package kfi.core.support.nexacro;

import java.lang.reflect.Field;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.springframework.web.context.request.NativeWebRequest;
import com.nexacro.uiadapter17.spring.core.context.NexacroContext;
import com.nexacro17.xapi.data.DataSet;
import com.nexacro17.xapi.data.DataSetList;
import com.nexacro17.xapi.data.DataTypes;
import com.nexacro17.xapi.data.PlatformData;
import com.nexacro17.xapi.data.VariableList;
import com.nexacro17.xapi.tx.PlatformException;
import kfi.core.constants.Constants;
import kfi.core.util.ReqestUtil;
import kfi.core.vo.UserSessionVO;
import lombok.experimental.UtilityClass;

@UtilityClass
public class NexacroConvertData {
	public Map<String, Object> getNexacroDataMap(NativeWebRequest webRequest) throws PlatformException{
        
		Map<String, Object> paramdMap = new HashMap<String, Object>();
		Map <String, DataSetMap> inDataSetMap =  new HashMap<String, DataSetMap>();
		NexacroContext nexacroCachedData = NexacroConvert.prepareResolveArguments(webRequest);
		PlatformData platformData = nexacroCachedData.getPlatformData();
		DataSetList dsList = platformData.getDataSetList();
		VariableList vList = platformData.getVariableList();
		HttpServletRequest request = (HttpServletRequest) webRequest.getNativeRequest();
		HttpSession session = (HttpSession) request.getSession();
        UserSessionVO userSessionVO = (UserSessionVO) session.getAttribute(Constants.USER_SESSION);
        //session 값 add 
        String sessUserId =  null;
        String sessCmpyId =  null;
        
        if(userSessionVO != null){
            sessUserId = userSessionVO.getUserId();
            sessCmpyId = userSessionVO.getCmpyId();
        }
		//데이터 set 변환
		if(dsList != null) {
			for(int i=0; i<dsList.size(); i++){
				DataSet dataset = dsList.get(i);
				String dsName = dataset.getName();
				DataSetMap dataSetMap = new DataSetMap();
				dataSetMap.convertDataSet2DataSetMap(dataset);
				inDataSetMap.put(dsName, dataSetMap);
				if(dsName.substring(dsName.length()-1).equals("M") || dsName.equals("dsParam")) {
				    if(inDataSetMap.get(dsName).size() > 0) {
				        paramdMap.put(dsName, inDataSetMap.get(dsName).get(0));
				    }else {
				        Map<String, Object> addDataMap = new HashMap<String, Object>();
				        
    				    //session 값 add
			            if(sessUserId != null) {
			                addDataMap.put("sessUserId", sessUserId);
			            }
			            //session 값 add
			            if(sessCmpyId != null) {
			                addDataMap.put("sessCmpyId", sessCmpyId);
			            }
				        addDataMap.put("sessIpAdr", ReqestUtil.getUserIP());
				        addDataMap.put(Constants.KEY_ROW_TYPE, "X");
				        //session 값 add
				        paramdMap.put(dsName, addDataMap);
				    }
				}else {
					paramdMap.put(dsName, inDataSetMap.get(dsName).getRowMaps());
				}
			}
		}
		//session 값 add
		//Variable 변환
		for (int i = 0; i < vList.size(); i++) {
			paramdMap.put(vList.get(i).getName(), nvlUtil(vList.get(i).getObject()));
		}
		//session 값 add
        if(sessUserId != null) {
            paramdMap.put("sessUserId", sessUserId);
        }
        //session 값 add
        if(sessCmpyId != null) {
            paramdMap.put("sessCmpyId", sessCmpyId);
        }
		paramdMap.put("sessIpAdr", ReqestUtil.getUserIP());
		return paramdMap;
	}
	public Object nvlUtil(Object param){
		if(param == null || ((String)param).equals("undefined")) return "";
		else {
			return param;
		}
	}
	/**
	 * Object를 데이타셋으로 변환 리턴한다.
	 * @param datasetName
	 * @param listMap
	 * @return
	 * @throws IllegalAccessException
	 * @throws IllegalArgumentException
	 */
    @SuppressWarnings("unchecked")
    public DataSet convertObject2DataSet(String datasetName, Object obj) throws IllegalArgumentException, IllegalAccessException{
		DataSet ds = new DataSet(datasetName);
		
		String fieldName = "";
        SimpleDateFormat timestampFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String strVal = null;	
        
		if(obj == null){

		} else if (obj instanceof Map) {
			Map<String, Object> map = (Map<String, Object>)obj;
			Set<String> keySet = map.keySet();


			String colNmAry[] = new String[keySet.size()];

			int idx = 0;
			Iterator<String> it = keySet.iterator();
			while(it.hasNext()){
				String colNm = it.next();
				ds.addColumn(colNm,DataTypes.STRING);
				colNmAry[idx] = colNm;
				++idx;
			}

			int row = ds.newRow();
			for(int i=0; i<keySet.size(); i++){
				fieldName = colNmAry[i];
				
				if(map.get(colNmAry[i]) !=  null && map.get(colNmAry[i]) instanceof Timestamp) {
				    strVal = timestampFormat.format(map.get(colNmAry[i]));
				    ds.set(row, fieldName, strVal);
				}else if(map.get(colNmAry[i]) !=  null && map.get(colNmAry[i]) instanceof Date) {
				    strVal = dateFormat.format(map.get(colNmAry[i]));
				    ds.set(row, fieldName, strVal);
				}else {
				    ds.set(row, fieldName, map.get(colNmAry[i]));
				}
				
				
			}
		} else if (obj instanceof List) {
			if(((List<Map<String, Object>>)obj).size() != 0){
				List<Map<String, Object>> listMap = convertListObjectToListMap((List<Map<String, Object>>)obj);

				if(listMap==null){
					return ds;
				}

				Set<String> keySet = listMap.get(0).keySet();
				String colNmAry[] = new String[keySet.size()];

				int idx = 0;
				Iterator<String> it = keySet.iterator();
				while(it.hasNext()){
					String colNm = it.next();
					ds.addColumn(colNm,DataTypes.STRING);
					colNmAry[idx] = colNm;
					++idx;
				}

				int row;
				for(int i=0; i<listMap.size(); i++){
					row = ds.newRow();
					for(int j=0; j<keySet.size(); j++){
						fieldName = colNmAry[j];
						if(listMap.get(i).get(colNmAry[j]) !=  null && listMap.get(i).get(colNmAry[j]) instanceof Timestamp) {
		                    strVal = timestampFormat.format(listMap.get(i).get(colNmAry[j]));
		                    ds.set(row, fieldName, strVal);
		                }else if(listMap.get(i).get(colNmAry[j]) !=  null && listMap.get(i).get(colNmAry[j]) instanceof Date) {
		                    strVal = dateFormat.format(listMap.get(i).get(colNmAry[j]));
		                    ds.set(row, fieldName, strVal);
		                }else {
		                    ds.set(row, fieldName, listMap.get(i).get(colNmAry[j]));
		                }
						
					}
				}
			}
		} else {
			Map<String,Object> map = convertVoToMap(obj);
			Set<String> keySet = map.keySet();
			String colNmAry[] = new String[keySet.size()];

			int idx = 0;
			Iterator<String> it = keySet.iterator();
			while(it.hasNext()){
				String colNm = it.next();
				ds.addColumn(colNm,DataTypes.STRING);
				colNmAry[idx] = colNm;
				++idx;
			}

			int row = ds.newRow();
			for(int i=0; i<keySet.size(); i++){
			    
			    fieldName = colNmAry[i];
				
				if(map.get(colNmAry[i]) !=  null && map.get(colNmAry[i]) instanceof Timestamp) {
                    strVal = timestampFormat.format(map.get(colNmAry[i]));
                    ds.set(row, fieldName, strVal);
                }else if(map.get(colNmAry[i]) !=  null && map.get(colNmAry[i]) instanceof Date) {
                    strVal = dateFormat.format(map.get(colNmAry[i]));
                    ds.set(row, fieldName, strVal);
                }else {
                    ds.set(row, fieldName, map.get(colNmAry[i]));
                }
			}
		}
		return ds;
	}
    
	public List<Map<String,Object>> convertListObjectToListMap(List<Map<String,Object>> list) throws IllegalArgumentException, IllegalAccessException{
		Object obj = list.get(0);

		if(obj == null){
			return null;
		} else if(obj instanceof Map) {
			return list;
		} else {
			List<Map<String,Object>> listMap = new ArrayList<Map<String,Object>>();
			for(int i=0; i<list.size(); i++){
				listMap.add(convertVoToMap(list.get(i)));
			}
			return listMap;
		}
	}
	
	public Map<String, Object> convertVoToMap(Object obj) throws IllegalArgumentException, IllegalAccessException{
		Field[] fields = obj.getClass().getDeclaredFields();
		Map<String, Object> resultMap = new HashMap<String, Object>();
		String fieldName = "";
		for(int i=0; i<fields.length; i++){
			fields[i].setAccessible(true);
			fieldName = fields[i].getName();
			resultMap.put(fieldName, fields[i].get(obj));
		}
		return resultMap;
	}
}