package kfi.core.support.nexacro.view;

import java.util.ArrayList;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nexacro.uiadapter17.spring.core.view.NexacroView;
import com.nexacro17.xapi.data.PlatformData;
import com.nexacro17.xapi.data.VariableList;
import com.nexacro17.xapi.tx.PlatformException;

import kfi.core.constants.Constants;
import kfi.core.support.nexacro.NexacroConvertData;

/**
 * <p>nexacro platform으로 데이터를 송신하기 위한 {@link org.springframework.web.servlet.View}이다.
 * 
 * <p>데이터 분한 전송이 이루어진 후 데이터를 전송하는 경우 기 전송된 데이터는 전송되지 않는다.
 * 또한 DataSet이 전송되었을 경우 Variable은 추가적으로 전송되지 않는다.
 * 
 * @author Park SeongMin
 * @since 07.27.2015
 * @version 1.0
 *
 */
public class CustomNexacroView extends  NexacroView{
    
	private Logger logger = LoggerFactory.getLogger(CustomNexacroView.class);
	
	public CustomNexacroView(){
	}
	
	@SuppressWarnings("rawtypes")
    @Override
	protected void renderMergedOutputModel(Map<String, Object> model,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		
    	try {
    		PlatformData platformData = new PlatformData();
    		VariableList varList = platformData.getVariableList();
    		for( String mapKey : model.keySet() ){
    		    Class<?> cls = null;
    		    if(model.get(mapKey) != null) {
    		        cls = (Class<?>) model.get(mapKey).getClass();
    		    }else {
    		        cls = (Class<?>)new ArrayList().getClass();
    		    }
                if(cls.isAssignableFrom(String.class) || cls.isAssignableFrom(Integer.class)
                        || cls.isAssignableFrom(Double.class) || cls.isAssignableFrom(float.class)
                        || cls.isAssignableFrom(long.class)) {
                	if(mapKey.equals(Constants.ERROR_MSG)) {
                		varList.add(mapKey, model.get(mapKey));
                	}else {
                		
                		varList.add(mapKey, model.get(mapKey));
                	}
                }else {
                	platformData.addDataSet(NexacroConvertData.convertObject2DataSet(mapKey, model.get(mapKey)));
                }
    			
    		}
    		
    		for (int i = 0; i < varList.size(); i++) {
    			platformData.addVariable(varList.get(i));
			}
			sendResponse(request, response, platformData);
    	} catch(Throwable e) {
         	// ExceptionResolver가 처리되지 않기 때문에 로그를 남기도록 한다.
         	logger.error("an error has occurred during platform data transfer", e);
         	if(e instanceof Exception) {
         		throw (Exception) e;
         	} else {
         		throw new PlatformException("an error has occurred during platform data transfer", e);
         	}
    	}
	}
}
