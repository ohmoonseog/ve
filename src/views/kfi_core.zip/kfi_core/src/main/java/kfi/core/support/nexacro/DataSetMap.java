package kfi.core.support.nexacro;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import com.nexacro17.xapi.data.DataSet;
import kfi.core.constants.Constants;
import kfi.core.support.nexacro.vo.DataSetVOMapping;
import kfi.core.support.nexacro.vo.RowType;
import kfi.core.util.ReqestUtil;
import kfi.core.vo.UserSessionVO;



public class DataSetMap {

	private List <Map<String, Object>> rowMaps;
	private DataSet ds;

	public DataSetMap(){
		rowMaps = new ArrayList<Map<String, Object>>();
	}

	public Map<String, Object> get(int index){
		return rowMaps.get(index);
	}

	public void add(Map<String, Object> elem){
		rowMaps.add(elem);
	}

	public int size(){
		return rowMaps.size();
	}

	public Object[] toArray(){
		return rowMaps.toArray();
	}

	public void setRowMaps(List<Map<String, Object>> list){
		rowMaps = list;
	}

	public List<Map<String, Object>> getRowMaps(){
		return rowMaps;
	}

	public Object getMapValue(int listIndex, Object key){
		return get(listIndex).get(key);
	}

	public Set<?> getKeySet(int listIndex){
		return get(listIndex).keySet();
	}

	public DataSet getDataSet(){
		return this.ds;
	}
	
	
	/**
	 * DataSet을  List <Object> 형태로 컨버팅한다.
	 * @param dataset
	 * @param voName
	 */
	public List<Object> convertDataSet2ListObject(DataSet dataset, Class<?> clz) {
		if (dataset == null) return null;
		List<Object> rowObjects = new ArrayList<Object>();
		// Noraml, Insert, update
		for (int j = 0; j < dataset.getRowCount(); j++) {
			Object obj = DataSetVOMapping.getVOFromDataSetRow(clz, dataset, j, 0);
			// row type 세팅
			if (obj instanceof RowType) {
				int rowType = dataset.getRowType(j);
				((RowType) obj).setRowType(rowType);
			}
			if (obj != null)
				rowObjects.add(obj);
		}
		// Delete
		for (int i = 0; i < dataset.getRemovedRowCount(); i++) {
			Object obj = DataSetVOMapping.getVOFromDataSetRow(clz, dataset, i, 1);
			if (obj instanceof RowType) {
				((RowType) obj).setRowType(DataSet.ROW_TYPE_DELETED);
			}
			if (obj != null)
				rowObjects.add(obj);
		}
		return rowObjects;
	}

	/**
	 * DataSet을 DataSetMap으로 변경한다.
	 * @param ds 변경할 DataSet
	 */
	public void convertDataSet2DataSetMap(DataSet ds) {

	    ServletRequestAttributes sra = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
        HttpServletRequest servletRequest = sra.getRequest();
	    HttpSession session = (HttpSession) servletRequest.getSession();
		UserSessionVO userSessionVO = (UserSessionVO) session.getAttribute(Constants.USER_SESSION);
		//session 값 add	
		String sessUserId =  null;
		String sessCmpyId =  null;
		
		if(userSessionVO != null){
		    sessUserId = userSessionVO.getUserId();
		    sessCmpyId = userSessionVO.getCmpyId();
		}

		this.ds = ds;
		Map <String, Object> map = null;
		String name = "";
		Object value = "";
		Object ori_val = "";
		for ( int j = 0; j < ds.getRowCount(); j ++ ){		//Dataset의 record 반복
			map = new HashMap<String, Object>();
			for (int k = 0; k < ds.getColumnCount(); k++) {
				Object obj = ds.getObject(j, k);
				if (obj != null){
					name = ds.getColumn(k).getName();
					value = ds.getObject(j, k);
					map.put(name, value);

					ori_val = ds.getSavedData(j, name);
					map.put("ori_"+name, ori_val);
				}else{
					name = ds.getColumn(k).getName();
					value = ds.getObject(j, k);
					map.put(name, null);

					ori_val = ds.getSavedData(j, name);
					map.put("ori_"+name, ori_val);
				}

			}
			int rowType1 = ds.getRowType(j);

			if(rowType1 == DataSet.ROW_TYPE_INSERTED){
				map.put(Constants.KEY_ROW_TYPE, Constants.ROW_TYPE_INSERT);
			} else if(rowType1 == DataSet.ROW_TYPE_UPDATED){
				map.put(Constants.KEY_ROW_TYPE, Constants.ROW_TYPE_UPDATE);
			} else if(rowType1 == DataSet.ROW_TYPE_DELETED){
				map.put(Constants.KEY_ROW_TYPE, Constants.ROW_TYPE_DELETE);
			}

			//session 값 add
			if(sessUserId != null) {
			    map.put("sessUserId", sessUserId);
			}
			//session 값 add
            if(sessCmpyId != null) {
                map.put("sessCmpyId", sessCmpyId);
            }
			map.put("sessIpAdr", ReqestUtil.getUserIP());

			rowMaps.add(map);
		}

		int removeRowCount = ds.getRemovedRowCount();
		for (int i = 0; i < removeRowCount; i++) {
			map = new HashMap<String, Object>();
			map.put(Constants.KEY_ROW_TYPE, Constants.ROW_TYPE_DELETE);
			for (int j = 0; j < ds.getColumnCount(); j++) {
				map.put(ds.getColumn(j).getName(), StringUtils.stripToEmpty(ds.getRemovedStringData(i, j)));
			}

			//session 값 add
			//session 값 add
            if(sessUserId != null) {
                map.put("sessUserId", sessUserId);
            }
            //session 값 add
            if(sessCmpyId != null) {
                map.put("sessCmpyId", sessCmpyId);
            }
			rowMaps.add(map);
		}
	}

	/**
	 * DataSet을 DataSetMap으로 변경한다.
	 * @param ds 변경할 DataSet
	 */
	public void convertDataSet2DataSetMap(DataSet ds, Map<String,Object> mapUserInfo, Map<String,Object> mapPageInfo) {
		this.ds = ds;
		Map <String, Object> map = null;
		for ( int j = 0; j < ds.getRowCount(); j ++ ){		//Dataset의 record 반복
			map = new HashMap<String, Object>();
			for (int k = 0; k < ds.getColumnCount(); k++) {
				Object obj = ds.getObject(j, k);
				if (obj != null){
					map.put(ds.getColumn(k).getName(), ds.getObject(j, k));
				}
			}

			int rowType1 = ds.getRowType(j);
			map.put(Constants.DATASET_ROW_TYPE,new Integer(rowType1));

			map.put(Constants.SESSION_USER_MAP_NAME, mapUserInfo);
			map.put(Constants.PAGING_MAP_NAME, mapPageInfo);

			rowMaps.add(map);
		}

		int removeRowCount = ds.getRemovedRowCount();
		for (int i = 0; i < removeRowCount; i++) {
			map = new HashMap<String, Object>();
			map.put(Constants.DATASET_ROW_TYPE, new Integer(DataSet.ROW_TYPE_DELETED));

			map.put(Constants.SESSION_USER_MAP_NAME, mapUserInfo);
			map.put(Constants.PAGING_MAP_NAME, mapPageInfo);

			for (int j = 0; j < ds.getColumnCount(); j++) {
				map.put(ds.getColumn(j).getName(), StringUtils.stripToEmpty(ds.getRemovedStringData(i, j)));
			}
			rowMaps.add(map);
		}
	}

}