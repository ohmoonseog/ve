package kfi.core.config.datasource;

import javax.sql.DataSource;
import org.springframework.jdbc.datasource.LazyConnectionDataSourceProxy;
import org.springframework.jdbc.datasource.lookup.JndiDataSourceLookup;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import kfi.core.service.PropertyService;
import lombok.experimental.UtilityClass;
import net.sf.log4jdbc.sql.jdbcapi.DataSourceSpy;


/**
 *
 * @className : DataSourceCreator
 * @description : 데이터소스 생성을 위한 Utility Class 이다.
 *
 * @modification : 2020. 4. 10.(수정자) 최초생성
 *
 * @author hirob
 * @Date 2020. 4. 10.
 * @version 1.0
 * @see
 *  == 개정이력(Modification Information) ==
 *
 *   수정일                     수정자                  수정내용
 *  -------    --------    ---------------------------
 *  
 * Copyright (C) by KFI All right reserved.
 * (C) by KFI All right reserved.
 */
@UtilityClass
public class DataSourceCreator {

    /**
     * 데이터 소스 생성한다.
     * @param propertyService
     * @param dataSourcePrefix
     * @return
     */
    public DataSource createDataSource(PropertyService propertyService, String dataSourcePrefix) {
        if (propertyService.getString("spring.datasource." + dataSourcePrefix + ".username") != null) {
            HikariConfig config = new HikariConfig();
            config.setJdbcUrl(propertyService.getString("spring.datasource." + dataSourcePrefix + ".url"));
            config.setDriverClassName(propertyService.getString("spring.datasource." + dataSourcePrefix + ".driver-class-name"));
            config.setUsername(propertyService.getString("spring.datasource." + dataSourcePrefix + ".username"));
            config.setPassword(propertyService.getString("spring.datasource." + dataSourcePrefix + ".password"));
            config.setMinimumIdle(3);
            config.setMaximumPoolSize(5);
            HikariDataSource dataSource = new HikariDataSource(config);
            DataSourceSpy ds = new DataSourceSpy(dataSource);
            return new LazyConnectionDataSourceProxy(ds);

        } else {
            JndiDataSourceLookup lookup = new JndiDataSourceLookup();
            lookup.setResourceRef(false);
            DataSource dataSource = lookup.getDataSource(propertyService.getString("spring.datasource." + dataSourcePrefix + ".jndi-name"));
            DataSourceSpy ds = new DataSourceSpy(dataSource);
            return new LazyConnectionDataSourceProxy(ds);
        }


    }
}
