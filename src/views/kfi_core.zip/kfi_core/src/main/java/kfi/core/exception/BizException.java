package kfi.core.exception;

import java.util.Locale;



/**
 *
 * @className : BizException
 * @description : 업무 개발용 공통 Exception class 이다.
 *
 * @modification : 2020. 4. 10.(수정자) 최초생성
 *
 * @author hirob
 * @Date 2020. 4. 10.
 * @version 1.0
 * @see
 *  == 개정이력(Modification Information) ==
 *
 *   수정일                     수정자                  수정내용
 *  -------    --------    ---------------------------
 *  
 * Copyright (C) by KFI All right reserved.
 * (C) by KFI All right reserved.
 */
public class BizException extends AbstractRuntimeException {

	private static final long serialVersionUID = 1L;

	public void setLocale(Locale locale) {
        this.locale = locale;
    }

    public Locale getLocale() {
        return this.locale;
    }

    public String getMessageId() {
        return this.messageId;
    }

    public Object[] getMessageArgs() {
        return this.messageArgs;
    }


	public BizException(String messageId) {
		super(messageId);
	}

	public BizException(String messageId, Locale locale) {
		super(messageId, locale);
	}

	public BizException(String messageId, Object[] messageArgs) {
		super(messageId, messageArgs);
	}

	public BizException(String messageId, Object[] messageArgs, Locale locale) {
		super(messageId, messageArgs, locale);
	}

	public BizException(String messageId, Throwable cause) {
		super(messageId, cause);
	}

	public BizException(String messageId, Locale locale, Throwable cause) {
		super(messageId, locale, cause);
	}

	public BizException(String messageId, Object[] messageArgs, Throwable cause) {
		super(messageId, messageArgs, cause);
	}

	public BizException(String messageId, Object[] messageArgs, Locale locale, Throwable cause) {
		super(messageId, messageArgs, locale, cause);
	}
}
