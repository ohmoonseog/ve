package kfi.core.support;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.ResourceBundle;

import org.springframework.context.support.ResourceBundleMessageSource;

import kfi.core.service.PropertyService;

/**
 *
 * @className : CustomMessageSource
 * @description : 메시지 전체를 읽어 보기 위한 사용자 정의 MessageSource class 이다.
 *
 * @modification : 2020. 4. 10.(수정자) 최초생성
 *
 * @author hirob
 * @Date 2020. 4. 10.
 * @version 1.0
 * @see
 *  == 개정이력(Modification Information) ==
 *
 *   수정일                     수정자                  수정내용
 *  -------    --------    ---------------------------
 *  
 * Copyright (C) by KFI All right reserved.
 * (C) by KFI All right reserved.
 */
public class CustomMessageSource extends ResourceBundleMessageSource {


    public Map<String, String> listAllMsg(PropertyService propertyService, Locale locale) {
    	
    	Map<String, String> msgList = new HashMap<String, String>();
        ResourceBundle properties = getResourceBundle(propertyService.getString("spring.messages.basename"), locale);
        for(Object key : properties.keySet()){
            msgList.put((String)key, properties.getString((String) key));
        }
        return msgList;
    }

}