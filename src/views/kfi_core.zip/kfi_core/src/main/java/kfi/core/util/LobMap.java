package kfi.core.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.SQLException;
import egovframework.rte.psl.dataaccess.util.EgovMap;
import lombok.extern.slf4j.Slf4j;

/**
 *
 * @className : MegaLobMap
 * @description : Camel Case 표기법 변환 처리를 포함하는 Map 확장 클래스(Clob, Blob 변환포함)
 *
 * @modification : 2018. 8. 1.(수정자) 최초생성
 *
 * @author AA lee
 * @Date 2018. 8. 1.
 * @version 1.0
 * @see
 *  == 개정이력(Modification Information) ==
 *
 *   수정일      수정자           수정내용
 *  -------    --------    ---------------------------
 *
 * Copyright (C) by AIRA All right reserved.
 */
@Slf4j
public class LobMap extends EgovMap {


	private static final long serialVersionUID = 6723434363565852261L;


	@Override
	public Object put(Object key, Object value) {

		if (value instanceof java.sql.Clob){
			value = clobToString((Clob)value);
		} else if(value instanceof java.sql.Blob){
			value = blobToString((Blob)value);
		}

		return super.put(key, value);
	}

	/**
	 * clob 데이터를 문자열로 변환 한다.
	 * @param clob
	 * @return
	 */
	private String clobToString(Clob clob) {
		String retVal = "";

		StringBuffer sb = new StringBuffer();
		BufferedReader br = null;
		try {
			br = new BufferedReader(clob.getCharacterStream());
			while((retVal = br.readLine()) != null)
			 {
				sb.append(retVal);
			 }
		} catch (IOException e) {
			log.error(e.getMessage());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			log.error(e.getMessage());
		}finally {
			try {
				if(br != null) br.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				log.error(e.getMessage());
			}
		}

		return sb.toString();
	}

	/**
	 * Blob 데이터를 문자열로 변환 한다.
	 * @param blob
	 * @return String
	 */
	private String blobToString(Blob blob){
		String retVal = "";

		StringBuffer sb = new StringBuffer();
		InputStreamReader inStreamReader = null;
		BufferedReader reader = null;
		try {
			inStreamReader = new InputStreamReader(blob.getBinaryStream());
			reader = new BufferedReader(inStreamReader);
			while((retVal = reader.readLine()) != null){
				sb.append(retVal);
			}
		} catch (IOException e) {
			log.error(e.getMessage());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			log.error(e.getMessage());
		}finally {

			try {
				if(inStreamReader != null) inStreamReader.close();
				if(reader != null) reader.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				log.error(e.getMessage());
			}
		}

		return sb.toString();
	}
}
