package kfi.core.config.aspect;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.context.annotation.Configuration;
import org.springframework.util.StopWatch;
import lombok.extern.slf4j.Slf4j;

/**
 *
 * @className : LoggingMvcAspect
 * @description : log를 위한 Aspect class 이다
 *
 * @modification : 2020. 5. 27.(수정자) 최초생성
 *
 * @author hirob
 * @Date 2020. 5. 27.
 * @version 1.0
 * @see
 *  == 개정이력(Modification Information) ==
 *
 *   수정일                     수정자                  수정내용
 *  -------    --------    ---------------------------
 *  
 * Copyright (C) by KFI All right reserved.
 * (C) by KFI All right reserved.
 */
@Aspect
@Configuration
@Slf4j
public class LoggingMvcAspect {


	/*@Before("execution(* kfi..controller.*Controller.*(..))")
	public void onBeforeControllerHandler(JoinPoint joinPoint) {
	    //String strLogKey = MDCUtils.get(MDCUtils.TX_ID);
	    //log.debug("tx_id ["+strLogKey+"] kfi start");
	}

	@Before("execution(* kfi..service.*Service.*(..))")
	public void onBeforeServiceHandler(JoinPoint joinPoint) {
		log.debug("=============== onBeforeServiceThing===============");
	}

	@After("execution(* kfi..controller.*Controller.*(..))")
	public void onAfterControllerHandler(JoinPoint joinPoint) {
		log.debug("=============== onAfterControllerThing===============");
		log.debug(joinPoint.getSignature() + "//" + joinPoint.getSignature().getName());
		//String strLogKey = MDCUtils.get(MDCUtils.TX_ID);
		//log.debug("tx_id ["+strLogKey+"] kfi end");

	}*/

	/*@After("execution(* kfi..service.*Service.*(..))")
	public void onAfterServiceHandler(JoinPoint joinPoint) {
		log.debug("=============== onAfterServiceThing===============");
	}*/

	@Around("execution(* kfi..web.*Controller.*(..))")
	public Object aroundAdvice( ProceedingJoinPoint pjp) throws Throwable {
	    // before advice
	    StopWatch sw = new StopWatch();
	    sw.start();

	    Object result = pjp.proceed();

	    // after advice
	    sw.stop();
	    Long total = sw.getTotalTimeMillis();
	    //String strLogKey = MDCUtils.get(MDCUtils.TX_ID);
	    // 어떤 클래스의 메서드인지 출력하는 정보는 pjp 객체에 있다.
	    String className = pjp.getTarget().getClass().getName();
	    String methodName = pjp.getSignature().getName();
	    String taskName = className + "." + methodName;

	    // 실행시간은 로그로 남기는 것이 좋지만, 여기서는 콘솔창에 찍도록 한다.
	    log.info("[ExecutionTime]" + taskName + " , " + total + "(ms)");
	    return result;
	  }
}
