package kfi.core.util;

import java.awt.Color;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.ibatis.session.ResultContext;
import org.apache.ibatis.session.ResultHandler;
import org.apache.ibatis.session.SqlSession;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.springframework.dao.DataAccessException;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.context.support.WebApplicationContextUtils;
import egovframework.rte.psl.dataaccess.EgovAbstractMapper;
import egovframework.rte.psl.dataaccess.util.EgovMap;
import kfi.core.exception.BizException;
import kfi.core.service.PropertyService;
import kfi.core.util.BigExcel.SXSSFWorkbook2;
import kfi.core.vo.BigExcelSheetVO;
import kfi.core.vo.BigExcelVO;


public class BigExcelUtil {

	private final SqlSession sqlSession;

	private final HttpServletResponse response;

	private final HttpServletRequest request;

	static LinkedHashMap<String, String> colMap;

	static EgovMap cellStyleMap;

	static List<String> colKeyList;

	static String comment;

	static int rowNum;

	static Sheet sheet;

	static SXSSFWorkbook2 wb;

	static Cell cell;

	static Row row;

	static String strUserEmpInfo;

	static XSSFCellStyle style1;

	//public BigExcelUtil(EgovAbstractMapper mapper, HttpServletRequest request, HttpServletResponse response){
	public BigExcelUtil(EgovAbstractMapper mapper){
		this.sqlSession = mapper.getSqlSession();
		this.request = ((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getRequest();
		this.response = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getResponse();
		//this.response = response;
		//this.request = request;
	}

	@SuppressWarnings("rawtypes")
    public void download(BigExcelVO bigExcelVO) throws Exception{

		//HttpSession session = request.getSession(true);
		//UserSessionVO userSessionVO = (UserSessionVO)session.getAttribute(Constants.USER_SESSION);

		//strUserEmpInfo = userSessionVO.getEmpNo() == null ? userSessionVO.getUserNm() : userSessionVO.getEmpNo() +"-"+ userSessionVO.getUserNm();

		// 메모리에 100개의 행을 유지한다. 행의수가 넘으면 디스크에 적는다.
		wb = new SXSSFWorkbook2(100);

		try{
			List<BigExcelSheetVO> bigExcelSheetVOList = bigExcelVO.getBigExcelSheetVOList();
			Map<String, Object> sheetCntMap =  new HashMap<String, Object>();
			for(int i=0;i<bigExcelSheetVOList.size();i++){

				BigExcelSheetVO bigExcelSheetVO = bigExcelSheetVOList.get(i);
				// 엑셀 시트명 지정
				String sheetName = bigExcelSheetVO.getSheetName();
				if(sheetName != null){
				    if(wb.getSheetIndex(sheetName) == -1) {
				        sheet = wb.createSheet(sheetName);
				    }else {
				        int sheetCnt = 1;
				        if(sheetCntMap.get(sheetName) == null)
				        {
				            sheetCntMap.put(sheetName,sheetCnt);
				        }else {
				            sheetCnt = (int) sheetCntMap.get(sheetName);
				            sheetCnt++;
				            sheetCntMap.put(sheetName, sheetCnt);
				        }

				        sheet = wb.createSheet(sheetName+"("+sheetCnt+")");
				    }
				} else {
					sheet = wb.createSheet();
				}


				colMap = bigExcelSheetVO.getColMap();
				colKeyList = new ArrayList<String>(colMap.keySet());
				comment = bigExcelSheetVO.getComment();

				// 컬럼 사이즈, 지정
				String tmp1;
				String[] tmp2;
				for(int j=0; j<colKeyList.size(); j++){
					tmp1 = colMap.get(colKeyList.get(j));
					tmp2 = tmp1.split("\\|");

					if(tmp2.length > 1 && !(tmp2[1].trim()).equals("")){
						sheet.setColumnWidth(j, Integer.parseInt(tmp2[1]));
					}
				}

				String key = "";
				cellStyleMap = new EgovMap();
				for(int j=0; j<colKeyList.size(); j++){
					tmp1 = colMap.get(colKeyList.get(j));
					tmp2 = tmp1.split("\\|");
					key = tmp2[0];

					XSSFCellStyle colCellStyle =  (XSSFCellStyle) wb.createCellStyle();
					colCellStyle.setBorderLeft(XSSFCellStyle.BORDER_THIN);
					colCellStyle.setBorderRight(XSSFCellStyle.BORDER_THIN);
					colCellStyle.setBorderBottom(XSSFCellStyle.BORDER_THIN);
					colCellStyle.setBorderTop(XSSFCellStyle.BORDER_THIN);
					colCellStyle.setWrapText(true);

					if(tmp2.length > 2 && !(tmp2[2].trim()).equals("")){
						if(tmp2[2].trim().toUpperCase().equals("LEFT")){
							colCellStyle.setAlignment(XSSFCellStyle.ALIGN_LEFT);
						} else if(tmp2[2].trim().toUpperCase().equals("RIGHT")){
							colCellStyle.setAlignment(XSSFCellStyle.ALIGN_RIGHT);
						} else if(tmp2[2].trim().toUpperCase().equals("CENTER")){
							colCellStyle.setAlignment(XSSFCellStyle.ALIGN_CENTER);
						}
					}

					cellStyleMap.put(key, colCellStyle);
				}


				rowNum = 0;

				// 제목 입력
				row = sheet.createRow(rowNum);
				cell = row.createCell(0);
				cell.setCellValue("제목 : "+StringUtil.nvl(bigExcelSheetVO.getTitle(), ""));
				++rowNum;

				// 작성자 입력
				row = sheet.createRow(rowNum);
				cell = row.createCell(0);
				cell.setCellValue(strUserEmpInfo);
				++rowNum;

				// 작성시간 입력
				row = sheet.createRow(rowNum);
				cell = row.createCell(0);
				cell.setCellValue("출력일 : "+ StringUtil.getCurTime().substring(0, 19));
				++rowNum;
				++rowNum;
				++rowNum;

				// 코멘트 입력
				comment = comment.replaceAll("\\|", ":");
				String[] tmp3 = comment.split("\\$");
				for(int j=0; j<tmp3.length; j++){
					row = sheet.createRow(rowNum);
					cell = row.createCell(0);
					cell.setCellValue(tmp3[j]);
					++rowNum;
				}
				// 마지막 코멘트 다음에 한줄 띄고...
				++rowNum;


				style1 =  (XSSFCellStyle) wb.createCellStyle();
				style1.setFillForegroundColor(new XSSFColor(Color.decode("#ecf3fb")));
				style1.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND);
				style1.setBorderLeft(XSSFCellStyle.BORDER_THIN);
				style1.setBorderRight(XSSFCellStyle.BORDER_THIN);
				style1.setBorderBottom(XSSFCellStyle.BORDER_THIN);
				style1.setBorderTop(XSSFCellStyle.BORDER_THIN);
				style1.setAlignment(XSSFCellStyle.ALIGN_CENTER);
				style1.setWrapText(true);

				// 컬럼의 컬럼명 입력
				row = sheet.createRow(rowNum);
				for(int j=0; j<colKeyList.size(); j++){
					cell = row.createCell(j);
					cell.setCellValue(colKeyList.get(j));
					cell.setCellStyle(style1);
				}

				sqlSession.select(bigExcelSheetVO.getQueryId(), bigExcelSheetVO.getSearchMap(), new ResultHandler<Map>() {

					@SuppressWarnings("unchecked")
                    @Override
					public void handleResult(ResultContext<? extends Map> context) {

						Map<String,Object> rsltMap = context.getResultObject();

						row = sheet.createRow(++rowNum);
						String[] tmp;
						for(int i=0; i<colKeyList.size(); i++){
							cell = row.createCell(i);
							tmp = colMap.get(colKeyList.get(i)).split("\\|");
							String val = StringUtil.nvl(rsltMap.get(tmp[0]), "").toString();
//							if(tmp.length > 3 && (tmp[3].trim()).equals("DEC")){
//							    String decVal = XecuredbUtil.decrypt(val);
//							    if(decVal == null) {
//							        cell.setCellValue(val);
//							    }else {
//							        cell.setCellValue(decVal);
//							    }
//							}else {
//
//							    cell.setCellValue(val);
//							}
							cell.setCellValue(val);
							cell.setCellStyle((XSSFCellStyle)cellStyleMap.get(tmp[0]));

						}
					}
				});
			}

			String strClient = request.getHeader("User-Agent");
			response.setHeader("Set-Cookie", "fileDownload=true;path=/");
	        if (strClient.indexOf("MSIE 5.5") != -1) {
	            response.setHeader("Content-Disposition", "filename=\"" + bigExcelVO.getFileName() + ".xlsx\";");
	        } else {
	            response.setHeader("Content-Disposition", "attachment; filename=" + bigExcelVO.getFileName() + ".xlsx;");
	            response.setHeader("Content-Type", "application/octet-stream; charset=utf-8");
	        }
	        response.setHeader("Content-Transfer-Encoding", "binary;");
	        response.setHeader("Pragma", "no-cache;");
	        response.setHeader("Expires", "-1;");

			wb.write(response.getOutputStream(), bigExcelVO.getIsDrm());
		} catch(IllegalArgumentException | IOException | DataAccessException e){
			String s = e.getMessage();
			if(e  instanceof DataAccessException) {
			    SQLException se = (SQLException) ((DataAccessException) e).getRootCause();
			    s = se.getMessage();
			}
			if(s.indexOf("outside allowable range")!=-1){
				throw new BizException("대용량 엑셀 최대행수는 1,048,000행 까지입니다.");
			}
			response.setHeader("Set-Cookie", "fileDownload=true;path=/");
			response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
			response.setHeader("Content-Type", "text/html; charset=utf-8");
			wb.dispose();
			throw e;
		} finally {
			// 디스크에 적었던 임시파일을 제거한다.
			wb.dispose();
		}
	}

	@SuppressWarnings({ "rawtypes"})
    public String save(BigExcelVO bigExcelVO) throws Exception{
	    String filePath = "";
        //HttpSession session = request.getSession(true);
        //UserSessionVO userSessionVO = (UserSessionVO)session.getAttribute(Constants.USER_SESSION);
        //strUserEmpInfo = userSessionVO.getEmpNo() +"-"+ userSessionVO.getUserNm();

        // 메모리에 100개의 행을 유지한다. 행의수가 넘으면 디스크에 적는다.
        wb = new SXSSFWorkbook2(100);
        FileOutputStream out = null;
        try{
            List<BigExcelSheetVO> bigExcelSheetVOList = bigExcelVO.getBigExcelSheetVOList();
            Map<String, Object> sheetCntMap =  new HashMap<String, Object>();
            for(int i=0;i<bigExcelSheetVOList.size();i++){

                BigExcelSheetVO bigExcelSheetVO = bigExcelSheetVOList.get(i);
                // 엑셀 시트명 지정
                String sheetName = bigExcelSheetVO.getSheetName();
                if(sheetName != null){
                    if(wb.getSheetIndex(sheetName) == -1) {
                        sheet = wb.createSheet(sheetName);
                    }else {
                        int sheetCnt = 1;
                        if(sheetCntMap.get(sheetName) == null)
                        {
                            sheetCntMap.put(sheetName,sheetCnt);
                        }else {
                            sheetCnt = (int) sheetCntMap.get(sheetName);
                            sheetCnt++;
                            sheetCntMap.put(sheetName, sheetCnt);
                        }

                        sheet = wb.createSheet(sheetName+"("+sheetCnt+")");
                    }
                } else {
                    sheet = wb.createSheet();
                }


                colMap = bigExcelSheetVO.getColMap();
                colKeyList = new ArrayList<String>(colMap.keySet());
                comment = bigExcelSheetVO.getComment();

                // 컬럼 사이즈, 지정
                String tmp1;
                String[] tmp2;
                for(int j=0; j<colKeyList.size(); j++){
                    tmp1 = colMap.get(colKeyList.get(j));
                    tmp2 = tmp1.split("\\|");

                    if(tmp2.length > 1 && !(tmp2[1].trim()).equals("")){
                        sheet.setColumnWidth(j, Integer.parseInt(tmp2[1]));
                    }
                }

                String key = "";
                cellStyleMap = new EgovMap();
                for(int j=0; j<colKeyList.size(); j++){
                    tmp1 = colMap.get(colKeyList.get(j));
                    tmp2 = tmp1.split("\\|");
                    key = tmp2[0];

                    XSSFCellStyle colCellStyle =  (XSSFCellStyle) wb.createCellStyle();
                    colCellStyle.setBorderLeft(XSSFCellStyle.BORDER_THIN);
                    colCellStyle.setBorderRight(XSSFCellStyle.BORDER_THIN);
                    colCellStyle.setBorderBottom(XSSFCellStyle.BORDER_THIN);
                    colCellStyle.setBorderTop(XSSFCellStyle.BORDER_THIN);
                    colCellStyle.setWrapText(true);

                    if(tmp2.length > 2 && !(tmp2[2].trim()).equals("")){
                        if(tmp2[2].trim().toUpperCase().equals("LEFT")){
                            colCellStyle.setAlignment(XSSFCellStyle.ALIGN_LEFT);
                        } else if(tmp2[2].trim().toUpperCase().equals("RIGHT")){
                            colCellStyle.setAlignment(XSSFCellStyle.ALIGN_RIGHT);
                        } else if(tmp2[2].trim().toUpperCase().equals("CENTER")){
                            colCellStyle.setAlignment(XSSFCellStyle.ALIGN_CENTER);
                        }
                    }

                    cellStyleMap.put(key, colCellStyle);
                }


                rowNum = 0;

                // 제목 입력
                row = sheet.createRow(rowNum);
                cell = row.createCell(0);
                cell.setCellValue("제목 : "+StringUtil.nvl(bigExcelSheetVO.getTitle(), ""));
                ++rowNum;

                // 작성자 입력
                row = sheet.createRow(rowNum);
                cell = row.createCell(0);
                cell.setCellValue(strUserEmpInfo);
                ++rowNum;

                // 작성시간 입력
                row = sheet.createRow(rowNum);
                cell = row.createCell(0);
                cell.setCellValue("출력일 : "+ StringUtil.getCurTime().substring(0, 19));
                ++rowNum;
                ++rowNum;
                ++rowNum;

                // 코멘트 입력
                comment = comment.replaceAll("\\|", ":");
                String[] tmp3 = comment.split("\\$");
                for(int j=0; j<tmp3.length; j++){
                    row = sheet.createRow(rowNum);
                    cell = row.createCell(0);
                    cell.setCellValue(tmp3[j]);
                    ++rowNum;
                }
                // 마지막 코멘트 다음에 한줄 띄고...
                ++rowNum;


                style1 =  (XSSFCellStyle) wb.createCellStyle();
                style1.setFillForegroundColor(new XSSFColor(Color.decode("#ecf3fb")));
                style1.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND);
                style1.setBorderLeft(XSSFCellStyle.BORDER_THIN);
                style1.setBorderRight(XSSFCellStyle.BORDER_THIN);
                style1.setBorderBottom(XSSFCellStyle.BORDER_THIN);
                style1.setBorderTop(XSSFCellStyle.BORDER_THIN);
                style1.setAlignment(XSSFCellStyle.ALIGN_CENTER);
                style1.setWrapText(true);

                // 컬럼의 컬럼명 입력
                row = sheet.createRow(rowNum);
                for(int j=0; j<colKeyList.size(); j++){
                    cell = row.createCell(j);
                    cell.setCellValue(colKeyList.get(j));
                    cell.setCellStyle(style1);
                }

                sqlSession.select(bigExcelSheetVO.getQueryId(), bigExcelSheetVO.getSearchMap(), new ResultHandler<Map>() {

                    @SuppressWarnings("unchecked")
                    @Override
                    public void handleResult(ResultContext<? extends Map> context) {

                        Map<String,Object> rsltMap = context.getResultObject();

                        row = sheet.createRow(++rowNum);
                        String[] tmp;
                        for(int i=0; i<colKeyList.size(); i++){
                            cell = row.createCell(i);
                            tmp = colMap.get(colKeyList.get(i)).split("\\|");
                            cell.setCellValue( StringUtil.nvl(rsltMap.get(tmp[0]), "").toString());

                            cell.setCellStyle((XSSFCellStyle)cellStyleMap.get(tmp[0]));

                        }
                    }
                });
            }
            Calendar cal = Calendar.getInstance();
            String dateString = String.format("%04d/%02d/%02d", cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH));
            ServletContext servletContext = request.getServletContext();
            WebApplicationContext wac = WebApplicationContextUtils.getRequiredWebApplicationContext(servletContext);
            PropertyService propertyService = (PropertyService)wac.getBean("propertyService");

            filePath = propertyService.getString("base.file.path_co")+"excel/"+dateString+"/";
            File file = new File(filePath);
            if(!file.isDirectory()){
                file.setExecutable(false,true);
                file.setReadable(true);
                file.setWritable(false,true);
                file.mkdirs();
            }
            filePath = filePath + bigExcelVO.getFileName()+".xlsx";
            out = new FileOutputStream(filePath);


            wb.write(out, bigExcelVO.getIsDrm());

        } catch(IllegalArgumentException | IOException e){
            String s = e.getCause().getMessage();
            if(s.indexOf("outside allowable range")!=-1){
                throw new BizException("대용량 엑셀 최대행수는 1,048,000행 까지입니다.");
            }
            wb.dispose();
            throw e;
        }finally {
            // 디스크에 적었던 임시파일을 제거한다.
            if(wb != null)
                wb.dispose();
            if(out != null)
                out.close();

        }
        return filePath;
    }
}
