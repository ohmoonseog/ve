package kfi.core.log;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;

import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.classic.spi.StackTraceElementProxy;
import ch.qos.logback.core.LayoutBase;

/**
 *
 * @className : LoggingFileLayout
 * @description : 사용자 정의 LOG Layout 구성 하기위한 class 이다.
 *
 * @modification : 2020. 4. 10.(수정자) 최초생성
 *
 * @author hirob
 * @Date 2020. 4. 10.
 * @version 1.0
 * @see
 *  == 개정이력(Modification Information) ==
 *
 *   수정일                     수정자                  수정내용
 *  -------    --------    ---------------------------
 *  
 * Copyright (C) by KFI All right reserved.
 * (C) by KFI All right reserved.
 */
@Component
public class LoggingFileLayout extends LayoutBase<ILoggingEvent>{
    /*@Resource
    private PropertyService propertyService2;

    static PropertyService propertyService;

    @PostConstruct
    public void initialize() {
        propertyService = propertyService2;

    }*/
    @Override
    public String doLayout(ILoggingEvent event) {
        //String server_name = null;
        //String sysCd = null;
        boolean status = true;
        Map<String ,Object> logMap = new HashMap<>();
//        try {
//            server_name = propertyService.getString("serverName");
//            sysCd = propertyService.getString("sysCd");
//            logMap.put("server_name", server_name);
//            logMap.put("sys_cd", sysCd);
//            logMap.put("tx_id", MDCUtils.get(MDCUtils.TX_ID));
//            logMap.put("clientIp", ReqestUtil.getUserIP());
//            logMap.put("uri", ReqestUtil.getUri());
//        } catch (NullPointerException e) {
//            // TODO: handle exception
//            status = false;
//        } catch (IllegalStateException e) {
//            // TODO: handle exception
//            status = false;
//        }

        String strMessage = event.getFormattedMessage();

        logMap.put("time", new Timestamp((long)event.getTimeStamp()));
        logMap.put("level", event.getLevel().levelStr);
        logMap.put("logger", event.getLoggerName());
        if(event.getLevel().levelStr.equals("ERROR")) {
            StringBuilder strBuilder = new StringBuilder(128);
            strBuilder.append(strMessage);
            strBuilder.append(System.getProperty("line.separator"));
            if(event.getThrowableProxy() != null) {
            strBuilder.append(event.getThrowableProxy().getClassName() +" : "+event.getThrowableProxy().getMessage());
            strBuilder.append(System.getProperty("line.separator"));
            StackTraceElementProxy[] stackTraceElementProxy = event.getThrowableProxy().getStackTraceElementProxyArray();
            if(stackTraceElementProxy != null) {
                for (int i = 0; i < stackTraceElementProxy.length; i++) {
                    //strMessage += "\r\n  "+ stackTraceElementProxy[i].toString();
                    strBuilder.append("\t"+stackTraceElementProxy[i].toString());
                    strBuilder.append(System.getProperty("line.separator"));
                }
            }
        }
            logMap.put("message", strBuilder.toString());
        }else {
            logMap.put("message", strMessage);
        }
        ObjectMapper mapper = new ObjectMapper();
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.mmm", Locale.getDefault());
        mapper.setDateFormat(df);
        String logStr = null;
        if(status) {
            //logStr =  logMap.get("time") +"  "+ logMap.get("level")+"  ["+ logMap.get("logger")+"]   "+ logMap.get("server_name")+",  "+ logMap.get("clientIp")+",  "+ logMap.get("tx_id")+ ",  "+ logMap.get("uri")+"  :  "+ logMap.get("message");
        	logStr =  logMap.get("time") +"  "+ logMap.get("level")+"  ["+ logMap.get("logger")+"]   ,  "+ logMap.get("clientIp")+",  "+ logMap.get("tx_id")+ ",  "+ logMap.get("uri")+"  :  "+ logMap.get("message");
        }else {
            logStr =  logMap.get("time") +"  "+ logMap.get("level")+"  ["+ logMap.get("logger")+"]  : "+  logMap.get("message");
        }
        StringBuilder stringBuilder = new StringBuilder(128);
        stringBuilder.append(logStr);
        stringBuilder.append(System.getProperty("line.separator"));
        return stringBuilder.toString();
    }
}