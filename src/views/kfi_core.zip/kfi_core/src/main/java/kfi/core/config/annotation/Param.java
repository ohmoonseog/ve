/*
 * Copyright 2014 MOSPA(Ministry of Security and Public Administration).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package kfi.core.config.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import kfi.core.config.resolver.AnnotationParamArgumentResolver;


/**
 *
 * @className : Param
 * @description : Map,List기반 Argument를 처리하기 위한 Annotation class 이다 
 *
 * @modification : 2020. 4. 10.(수정자) 최초생성
 *
 * @author hirob
 * @Date 2020. 4. 10.
 * @version 1.0
 * @see AnnotationParamArgumentResolver
 *  == 개정이력(Modification Information) ==
 *
 *   수정일                     수정자                  수정내용
 *  -------    --------    ---------------------------
 *  
 * Copyright (C) by KFI All right reserved.
 * (C) by KFI All right reserved.
 */
@Target(ElementType.PARAMETER)
@Retention(RetentionPolicy.RUNTIME)
public @interface Param {
}
