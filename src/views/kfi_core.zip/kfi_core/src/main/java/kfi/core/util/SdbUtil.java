package kfi.core.util;


import com.ksign.securedb.api.SDBCrypto;
import com.ksign.securedb.api.util.SDBException;
import lombok.extern.slf4j.Slf4j;


/**
 *
 * @className : SdbUtil
 * @description : Ksgin sdb 암호화 솔류션 사용을 위한 class 이다 
 *
 * @modification : 2020. 6. 24.(수정자) 최초생성
 *
 * @author hirob
 * @Date 2020. 6. 24.
 * @version 1.0
 * @see
 *  == 개정이력(Modification Information) ==
 *
 *   수정일                     수정자                  수정내용
 *  -------    --------    ---------------------------
 *  
 * Copyright (C) by KFI All right reserved.
 * (C) by KFI All right reserved.
 */
@Slf4j
public class SdbUtil
{
    
    /**
     * 패스워드를 암호화 한다.
     * @param val
     * @return encVal
     */
    public static  String encptPwd(String val) {
        
        try {
            return SDBCrypto.encryptCEV("dbsec", "securekey", "pwd", val,"MS949");
        } catch (SDBException e) {
            // TODO Auto-generated catch block
            log.debug(e.getMessage());
            return null;
        }
    }
    /**
     * 패스워드를 암호화 한다.
     * @param val
     * @return encVal
     */
    public static  String asisEncptPwd(String val) {
        
        try {
            return SDBCrypto.encryptCEV("dbsec", "securekey", "sha256", val,"MS949");
        } catch (SDBException e) {
            // TODO Auto-generated catch block
            log.debug(e.getMessage());
            return null;
        }
    }
    /**
     * 주민번호를 암호화 한다.
     * @param val
     * @return encVal
     */
    public static  String encptRrno(String val) {
        
        try {
            return SDBCrypto.encryptCEV("dbsec", "securekey", "rrno", val,"MS949");
        } catch (SDBException e) {
            // TODO Auto-generated catch block
            log.debug(e.getMessage());
            return null;
        }
    }
    
    /**
     * 주민번호를 복암호화 한다.
     * @param encval
     * @return decVal
     */
    public static  String decptRrno(String encVal) {
        
        try {
            return SDBCrypto.decryptCEV("dbsec", "securekey", "rrno", encVal,"MS949");
        } catch (SDBException e) {
            // TODO Auto-generated catch block
            log.debug(e.getMessage());
            return null;
        }
    }
    
    /**
     * 핸드폰 번호를 암호화 한다.
     * @param val
     * @return encVal
     */
    public static  String encptMblTelno(String val) {
        
        try {
            return SDBCrypto.encryptCEV("dbsec", "securekey", "mbl_telno", val,"MS949");
        } catch (SDBException e) {
            // TODO Auto-generated catch block
            log.debug(e.getMessage());
            return null;
        }
    }
    
    /**
     * 핸드폰 번호를 복호화 한다.
     * @param encval
     * @return decVal
     */
    public static  String decptMblTelno(String encVal) {
        
        try {
            return SDBCrypto.decryptCEV("dbsec", "securekey", "mbl_telno", encVal,"MS949");
        } catch (SDBException e) {
            // TODO Auto-generated catch block
            log.debug(e.getMessage());
            return null;
        }
    }
    /**
     * 핸드폰 번호를 복호화 한다.
     * @param encval
     * @return decVal
     */
    public static  String decptMaskMblTelno(String encVal) {
        
        try {
                if(encVal != null) {
                    return StringUtil.getMaskedPhoneNum(SDBCrypto.decryptCEV("dbsec", "securekey", "mbl_telno", encVal,"MS949"));
                }
           return null;
            
        } catch (SDBException e) {
            // TODO Auto-generated catch block
            log.debug(e.getMessage());
            return null;
        }
    }
    /**
     * 이메일 주소를 암호화 한다.
     * @param val
     * @return encVal
     */
    public static  String encptEmlAdr(String val) {
        
        try {
            return SDBCrypto.encryptCEV("dbsec", "securekey", "eml_adr", val,"MS949");
        } catch (SDBException e) {
            // TODO Auto-generated catch block
            log.debug(e.getMessage());
            return null;
        }
    }
    
    /**
     * 이메일 주소를 복호화 한다.
     * @param encval
     * @return decVal
     */
    public static  String decptEmlAdr(String encVal) {
        
        try {
            return SDBCrypto.decryptCEV("dbsec", "securekey", "eml_adr", encVal,"MS949");
        } catch (SDBException e) {
            // TODO Auto-generated catch block
            log.debug(e.getMessage());
            return null;
        }
    }
    /**
     * 이메일 주소를 복호화 한다.
     * @param encval
     * @return decVal
     */
    public static  String decptMaskEmlAdr(String encVal) {
        
        try {
                if(encVal != null) {
                     return StringUtil.getMaskEmailAdr(SDBCrypto.decryptCEV("dbsec", "securekey", "eml_adr", encVal,"MS949"));
                }
                return null;
        } catch (SDBException e) {
            // TODO Auto-generated catch block
            log.debug(e.getMessage());
            return null;
        }
    }
    /**
     * 계좌번호를 암호화 한다.
     * @param val
     * @return encVal
     */
    public static  String encptAcno(String val) {
        
        try {
            return SDBCrypto.encryptCEV("dbsec", "securekey", "acno", val,"MS949");
        } catch (SDBException e) {
            // TODO Auto-generated catch block
            log.debug(e.getMessage());
            return null;
        }
    }
    
    /**
     * 계좌번호를 복암호화 한다.
     * @param encval
     * @return decVal
     */
    public static  String decptAcno(String encVal) {
        
        try {
            return SDBCrypto.decryptCEV("dbsec", "securekey", "acno", encVal,"MS949");
        } catch (SDBException e) {
            // TODO Auto-generated catch block
            log.debug(e.getMessage());
            return null;
        }
    }
}
