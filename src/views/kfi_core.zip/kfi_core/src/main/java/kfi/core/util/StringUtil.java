package kfi.core.util;


import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.net.URLEncoder;
import java.security.SecureRandom;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.Set;
import java.util.Stack;
import java.util.StringTokenizer;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import lombok.extern.slf4j.Slf4j;


/**
 *
 * @docNo : 정보관리부-652호 (2010.05.03)
 *
 * @className : HiraBatchAdaptor
 * @description : HiraBatchAdaptor 는 Batch TestCase 가 상속받는 class로서 다음의 역할을 수행한다.
 *
 *              <ul>
 *              <li>jsonBatchParam 을 이용해서 batchParam Map 을 생성한다.</li>
 *              </ul>
 *
 * @modification : 2011. 1. 20.(전승호) 최초생성
 *                 2011. 1. 25.(김일영) ThreadLocal 추가
 *
 * @author 공통개발팀 전승호
 * @since 2011. 1. 20.
 * @version 1.0
 * @see
 *
 * Copyright (C) by HIRA All right reserved.
 */
@Slf4j
public class StringUtil
{
	private static final long CONFIG_SET = 123123;
	private static class SortNode
    {

        private final int left;
        private final int right;


        public int getLeft()
        {
            return left;
        }

        public int getRight()
        {
            return right;
        }

        public SortNode(int i, int j)
        {
            left = i;
            right = j;
        }
    }

    public static final int STRING_UTIL_EXCEPTION_CODE = 6200;
    private static Random rgen = new Random();
    public static final String EMPTY_STRING_ARRAY[] = new String[0];
    public static final int IP_ADDRESS = 0;
    public static final int EMAIL_ADDRESS = 1;
    public static final int WEB_ADDRESS = 2;
    public static final int ZIP_CODE = 3;
    public static final int SS_NO = 4;
    public static final int ER_NO = 5;
    public static final int TEL_NO = 6;
    public static final String IP_ADDRESS_PATTERN = "((([2][0-5]{2})|([1][0-9]{2})|([1-9][0-9])|([0-9]))\\.){3}(([2][0-5]{2})|([1][0-" +
"9]{2})|([1-9][0-9])|([0-9]))"
;
    public static final String EMAIL_ADDRESS_PATTERN = ".+@.+\\..+(\\..+){0,1}";
    public static final String WEB_ADDRESS_PATTERN = "http://.+";
    public static final String ZIP_CODE_PATTERN = "[0-9]{3}-[0-9]{3}";
    public static final String SSNO_PATTERN = "[0-9]{2}(([0][1-9])|([1][0-2]))[0|1|2|3][0-9]-[1|2][0-9]{6}";
    public static final String ERNO_PATTERN = "[0-9]{3}-[0-9]{2}-[0-9]{5}";
    public static final String TELNO_PATTERN = "[0](([2])|([0-9]{2}))-[1-9][0-9]{2,3}-[0-9]{4}";

    /**
     * 2011 차세대 프로젝트 Util 함수용 Define 추가
     */
    public static final String SPACE_PATTERN = "\\p{Space}";
    public static final String EMPTY = "";

    /**
     * 2011 차세대 프로젝트 Util 함수용 Define 추가
     */



    public StringUtil()
    {
    }

    public static boolean hasLength(String str)
    {
        return str != null && str.length() > 0;
    }

    public static boolean hasText(String str)
    {
        int strLen;
        if(str == null || (strLen = str.length()) == 0)
        {
            return false;
        }
        for(int i = 0; i < strLen; i++)
        {
            if(!Character.isWhitespace(str.charAt(i)))
            {
                return true;
            }
        }

        return false;
    }

    public static int countOccurrencesOf(String s, String sub)
    {
        if(s == null || sub == null || "".equals(sub))
        {
            return 0;
        }
        int count = 0;
        int pos = 0;
        for(int idx = 0; (idx = s.indexOf(sub, pos)) != -1;)
        {
            count++;
            pos = idx + sub.length();
        }

        return count;
    }

    public static String replace(String inString, String oldPattern, String newPattern)
    {
        if(inString == null)
        {
            return null;
        }
        if(oldPattern == null || newPattern == null)
        {
            return inString;
        }
        StringBuffer sbuf = new StringBuffer();
        int pos = 0;
        int index = inString.indexOf(oldPattern);
        int patLen = oldPattern.length();
        for(; index >= 0; index = inString.indexOf(oldPattern, pos))
        {
            sbuf.append(inString.substring(pos, index));
            sbuf.append(newPattern);
            pos = index + patLen;
        }

        sbuf.append(inString.substring(pos));
        return sbuf.toString();
    }

    public static String delete(String inString, String pattern)
    {
        return replace(inString, pattern, "");
    }

    public static String deleteAny(String inString, String chars)
    {
        if(inString == null || chars == null)
        {
            return inString;
        }
        StringBuffer out = new StringBuffer();
        for(int i = 0; i < inString.length(); i++)
        {
            char c = inString.charAt(i);
            if(chars.indexOf(c) == -1)
            {
                out.append(c);
            }
        }

        return out.toString();
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    public static String[] tokenizeToStringArray(String s, String delimiters, boolean trimTokens, boolean ignoreEmptyTokens)
    {
        StringTokenizer st = new StringTokenizer(s, delimiters);
        List tokens = new ArrayList();
        do
        {
            if(!st.hasMoreTokens())
            {
                break;
            }
            String token = st.nextToken();
            if(trimTokens)
            {
                token = token.trim();
            }
            if(!ignoreEmptyTokens || token.length() != 0)
            {
                tokens.add(token);
            }
        } while(true);
        return (String[])tokens.toArray(new String[tokens.size()]);
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    public static String[] delimitedListToStringArray(String s, String delim)
    {
        if(s == null)
        {
            return new String[0];
        }
        if(delim == null)
        {
            return new String[] {s} ;
        }
        List l = new LinkedList();
        int pos = 0;
        for(int delPos = 0; (delPos = s.indexOf(delim, pos)) != -1;)
        {
            l.add(s.substring(pos, delPos));
            pos = delPos + delim.length();
        }

        if(pos <= s.length())
        {
            l.add(s.substring(pos));
        }
        return (String[])l.toArray(new String[l.size()]);
    }

    public static String[] commaDelimitedListToStringArray(String s)
    {
        return delimitedListToStringArray(s, ",");
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    public static Set commaDelimitedListToSet(String s)
    {
        Set set = new TreeSet();
        String tokens[] = commaDelimitedListToStringArray(s);
        for(int i = 0; i < tokens.length; i++)
        {
            set.add(tokens[i]);
        }

        return set;
    }

    public static String arrayToDelimitedString(Object arr[], String delim)
    {
        if(arr == null)
        {
            return "null";
        }
        StringBuffer sb = new StringBuffer();
        for(int i = 0; i < arr.length; i++)
        {
            if(i > 0)
            {
                sb.append(delim);
            }
            sb.append(arr[i]);
        }

        return sb.toString();
    }

    @SuppressWarnings("rawtypes")
    public static String collectionToDelimitedString(Collection c, String delim)
    {
        if(c == null)
        {
            return "null";
        }
        StringBuffer sb = new StringBuffer();
        Iterator it = c.iterator();
        int i = 0;
        for(; it.hasNext(); sb.append(it.next()))
        {
            if(i++ > 0)
            {
                sb.append(delim);
            }
        }

        return sb.toString();
    }

    public static String arrayToCommaDelimitedString(Object arr[])
    {
        return arrayToDelimitedString(arr, ",");
    }

    @SuppressWarnings("rawtypes")
    public static String collectionToCommaDelimitedString(Collection c)
    {
        return collectionToDelimitedString(c, ",");
    }

    public static String[] addStringToArray(String arr[], String s)
    {
        String newArr[] = new String[arr.length + 1];
        System.arraycopy(arr, 0, newArr, 0, arr.length);
        newArr[arr.length] = s;
        return newArr;
    }

    public static String unqualify(String qualifiedName)
    {
        return unqualify(qualifiedName, '.');
    }

    public static String unqualify(String qualifiedName, char separator)
    {
        return qualifiedName.substring(qualifiedName.lastIndexOf(separator) + 1);
    }

    public static String capitalize(String str)
    {
        return changeFirstCharacterCase(true, str);
    }

    public static String uncapitalize(String str)
    {
        return changeFirstCharacterCase(false, str);
    }

    private static String changeFirstCharacterCase(boolean capitalize, String str)
    {
        int strLen;
        if(str == null || (strLen = str.length()) == 0)
        {
            return str;
        }
        StringBuffer buf = new StringBuffer(strLen);
        if(capitalize)
        {
            buf.append(Character.toUpperCase(str.charAt(0)));
        } else
        {
            buf.append(Character.toLowerCase(str.charAt(0)));
        }
        buf.append(str.substring(1));
        return buf.toString();
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    public static String cleanPath(String path)
    {
        String p = replace(path, "\\", "/");
        String pArray[] = delimitedListToStringArray(p, "/");
        List pList = new LinkedList();
        int tops = 0;
        for(int i = pArray.length - 1; i >= 0; i--)
        {
            if(".".equals(pArray[i]))
            {
                continue;
            }
            if("..".equals(pArray[i]))
            {
                tops++;
                continue;
            }
            if(tops > 0)
            {
                tops--;
            } else
            {
                pList.add(0, pArray[i]);
            }
        }

        return collectionToDelimitedString(pList, "/");
    }

    public static boolean pathEquals(String path1, String path2)
    {
        return cleanPath(path1).equals(cleanPath(path2));
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    public static String[] split(String str, char separatorChar)
    {
        if(str == null)
        {
            return null;
        }
        int len = str.length();
        if(len == 0)
        {
            return EMPTY_STRING_ARRAY;
        }
        List list = new ArrayList();
        int i = 0;
        int start = 0;
        boolean match = false;
        while(i < len)
        {
            if(str.charAt(i) == separatorChar)
            {
                if(match)
                {
                    list.add(str.substring(start, i));
                    match = false;
                }
                start = ++i;
            } else
            {
                match = true;
                i++;
            }
        }
        if(match)
        {
            list.add(str.substring(start, i));
        }
        return (String[])list.toArray(new String[list.size()]);
    }


    public static boolean isHangul(char inputChar)
    {
        String unicodeBlock = Character.UnicodeBlock.of(inputChar).toString();
        return unicodeBlock.equals("HANGUL_JAMO") || unicodeBlock.equals("HANGUL_SYLLABLES") || unicodeBlock.equals("HANGUL_COMPATIBILITY_JAMO");
    }

    public static boolean isHangul(String inputStr, boolean full)
    {
        char chars[] = inputStr.toCharArray();
        if(!full)
        {
            for(int i = 0; i < chars.length; i++)
            {
                if(isHangul(chars[i]))
                {
                    return true;
                }
            }

            return false;
        }
        for(int i = 0; i < chars.length; i++)
        {
            if(!isHangul(chars[i]))
            {
                return false;
            }
        }

        return true;
    }

    public static boolean isLetter(String letter)
    {
        if(letter == null)
        {
            return false;
        }
        char chars[] = letter.toCharArray();
        for(int i = 0; i < chars.length; i++)
        {
            if(!Character.isLetter(chars[i]))
            {
                return false;
            }
        }

        return true;
    }

    public static boolean isDigit(String digit)
    {
        if(digit == null)
        {
            return false;
        }
        char chars[] = digit.toCharArray();
        for(int i = 0; i < chars.length; i++)
        {
            if(!Character.isDigit(chars[i]))
            {
                return false;
            }
        }

        return true;
    }

    public static boolean isLetterOrDigit(String letterOrDigit)
    {
        if(letterOrDigit == null)
        {
            return false;
        }
        char chars[] = letterOrDigit.toCharArray();
        for(int i = 0; i < chars.length; i++)
        {
            if(!Character.isLetterOrDigit(chars[i]))
            {
                return false;
            }
        }

        return true;
    }

    public static Object nvl(Object obj, Object value)
    {
        return obj != null ? obj : value;
    }

    public static String nvl(String str, String value)
    {
        return str != null ? str : value;
    }

    public static boolean isFormattedString(String string, int patternId)
    {
        switch(patternId)
        {
        case 0: // '\0'
            return isFormattedString(string, "((([2][0-5]{2})|([1][0-9]{2})|([1-9][0-9])|([0-9]))\\.){3}(([2][0-5]{2})|([1][0-" +
"9]{2})|([1-9][0-9])|([0-9]))"
);

        case 1: // '\001'
            return isFormattedString(string, ".+@.+\\..+(\\..+){0,1}");

        case 2: // '\002'
            return isFormattedString(string, "http://.+");

        case 3: // '\003'
            return isFormattedString(string, "[0-9]{3}-[0-9]{3}");

        case 4: // '\004'
            return isFormattedString(string, "[0-9]{2}(([0][1-9])|([1][0-2]))[0|1|2|3][0-9]-[1|2][0-9]{6}");

        case 5: // '\005'
            return isFormattedString(string, "[0-9]{3}-[0-9]{2}-[0-9]{5}");

        case 6: // '\006'
            return isFormattedString(string, "[0](([2])|([0-9]{2}))-[1-9][0-9]{2,3}-[0-9]{4}");
        default : return false;
        }
    }

    public static boolean isFormattedString(String string, String pattern)
    {
        if(string == null || pattern == null)
        {
            return false;
        } else
        {
            return string.matches(pattern);
        }
    }

    public static String toZipCodePattern(String string)
    {
        if(string == null)
        {
            return "";
        }
        if(string.length() != 6 || !isDigit(string))
        {
            return "";
        } else
        {
            StringBuffer buffer = new StringBuffer();
            buffer.append(string.substring(0, 3));
            buffer.append('-');
            buffer.append(string.substring(3, 6));
            return buffer.toString();
        }
    }

    public static String toErNoPattern(String string)
    {
        if(string == null)
        {
            return "";
        }
        if(string.length() != 10 || !isDigit(string))
        {
            return "";
        } else
        {
            StringBuffer buffer = new StringBuffer();
            buffer.append(string.substring(0, 3));
            buffer.append('-');
            buffer.append(string.substring(3, 5));
            buffer.append('-');
            buffer.append(string.substring(5, 10));
            return buffer.toString();
        }
    }

    public static String toSsNoPattern(String string)
    {
        if(string == null)
        {
            return "";
        }
        if(string.length() != 13 || !isDigit(string))
        {
            return "";
        } else
        {
            StringBuffer buffer = new StringBuffer();
            buffer.append(string.substring(0, 6));
            buffer.append('-');
            buffer.append(string.substring(6));
            return buffer.toString();
        }
    }

    public static String numberFormat(double d, String s)
    {
        DecimalFormat decimalformat = new DecimalFormat(s);
        return decimalformat.format(d);
    }

    public static String numberFormat(float f, String s)
    {
        DecimalFormat decimalformat = new DecimalFormat(s);
        return decimalformat.format(f);
    }

    public static String numberFormat(long l, String s)
    {
        DecimalFormat decimalformat = new DecimalFormat(s);
        return decimalformat.format(l);
    }

    public static String numberFormat(int i, String s)
    {
        DecimalFormat decimalformat = new DecimalFormat(s);
        return decimalformat.format(i);
    }

    public static String numberFormat(short word0, String s)
    {
        DecimalFormat decimalformat = new DecimalFormat(s);
        return decimalformat.format(word0);
    }

    public static boolean isSpace(String s)
    {
        if(s == null)
        {
            return false;
        } else
        {
            return s.trim().length() <= 0;
        }
    }

    public static final boolean isNull(String s)
    {
        return s == null || s.equals("");
    }

    public static String lpad(String str, int length, String pad)
    {
        if(str == null)
        {
            str = "";
        }
        if(pad == null)
        {
            pad = " ";
        }
        int j = str.length();
        if(j > length)
        {
            return str.substring(0, length);
        }
        if(j == length)
        {
            return str;
        }
        int k = pad.length();
        int l = length - j;
        int i1 = l / k;
        int j1 = l % k;
        StringBuffer stringbuffer = new StringBuffer();
        for(; i1 > 0; i1--)
        {
            stringbuffer.append(pad);
        }

        if(j1 > 0)
        {
            stringbuffer.append(pad.substring(0, j1));
        }
        stringbuffer.append(str);
        return stringbuffer.toString();
    }

    public static String lpadHangeul(String str, int length, String pad)
    {
        if(str == null)
        {
            str = "";
        }
        if(pad == null)
        {
            pad = " ";
        }
        byte abyte0[] = str.getBytes();
        byte abyte1[] = pad.getBytes();
        int j = abyte0.length;
        if(j > length)
        {
            byte abyte2[] = new byte[length];
            System.arraycopy(abyte0, 0, abyte2, 0, length);
            return new String(abyte2);
        }
        if(j == length)
        {
            return str;
        }
        int k = abyte1.length;
        int l = length - j;
        int i1 = l / k;
        int j1 = l % k;
        StringBuffer stringbuffer = new StringBuffer();
        for(; i1 > 0; i1--)
        {
            stringbuffer.append(pad);
        }

        if(j1 > 0)
        {
            if(j1 % 2 == 0)
            {
                byte abyte3[] = new byte[j1];
                System.arraycopy(abyte1, 0, abyte3, 0, j1);
                stringbuffer.append(new String(abyte3));
            } else
            {
                byte abyte4[] = new byte[j1 - 1];
                System.arraycopy(abyte1, 0, abyte4, 0, j1 - 1);
                stringbuffer.append(new String(abyte4));
            }
        }
        if(stringbuffer.toString().getBytes().length < l)
        {
            stringbuffer.append(" ");
        }
        stringbuffer.append(str);
        return stringbuffer.toString();
    }

    public static String rpad(String str, int length, String pad)
    {
        if(str == null)
        {
            str = "";
        }
        if(pad == null)
        {
            pad = " ";
        }
        int j = str.length();
        if(j > length)
        {
            return str.substring(j - length);
        }
        if(j == length)
        {
            return str;
        }
        int k = pad.length();
        int l = length - j;
        int i1 = l / k;
        int j1 = l % k;
        StringBuffer stringbuffer = new StringBuffer();
        stringbuffer.append(str);
        for(; i1 > 0; i1--)
        {
            stringbuffer.append(pad);
        }

        if(j1 > 0)
        {
            stringbuffer.append(pad.substring(0, j1));
        }
        return stringbuffer.toString();
    }

    public static String rpadHangeul(String str, int length, String pad)
    {
        if(str == null)
        {
            str = "";
        }
        if(pad == null)
        {
            pad = " ";
        }
        byte abyte0[] = str.getBytes();
        byte abyte1[] = pad.getBytes();
        int j = abyte0.length;
        if(j > length)
        {
            byte abyte2[] = new byte[length];
            System.arraycopy(abyte0, 0, abyte2, 0, length);
            return new String(abyte2);
        }
        if(j == length)
        {
            return str;
        }
        int k = abyte1.length;
        int l = length - j;
        int i1 = l / k;
        int j1 = l % k;
        StringBuffer stringbuffer = new StringBuffer();
        stringbuffer.append(str);
        for(; i1 > 0; i1--)
        {
            stringbuffer.append(pad);
        }

        if(j1 > 0)
        {
            if(j1 % 2 == 0)
            {
                byte abyte3[] = new byte[j1];
                System.arraycopy(abyte1, 0, abyte3, 0, j1);
                stringbuffer.append(new String(abyte3));
            } else
            {
                byte abyte4[] = new byte[j1 - 1];
                System.arraycopy(abyte1, 0, abyte4, 0, j1 - 1);
                stringbuffer.append(new String(abyte4));
            }
        }
        if(stringbuffer.toString().getBytes().length < length)
        {
            stringbuffer.append(" ");
        }
        return stringbuffer.toString();
    }

    private static int rand(int i, int j)
    {
		rgen.setSeed(CONFIG_SET);
    	return i + Math.abs(rgen.nextInt()) % ((j - i) + 1);
    }

    public static Object[] swap(Object aobj[], int i, int j)
    {
        Object obj = aobj[i];
        aobj[i] = aobj[j];
        aobj[j] = obj;
        return aobj;
    }

    @SuppressWarnings({ "rawtypes", "unchecked", "unused" })
    public static String[] sort(String src[], int left, int right, boolean flag)
    {
        if(src == null)
        {
            return src;
        }
        if(left < 0)
        {
            left = 0;
        }
        if(right >= src.length)
        {
            right = src.length - 1;
        }
        Stack stack = new Stack();
        SortNode sortnode = new SortNode(left, right);
        stack.push(sortnode);
        boolean flag1 = false;
        if(flag)
        {
            do
            {
                if(stack.empty())
                {
                    break;
                }
                SortNode sortnode1 = (SortNode)stack.pop();
                int k1 = sortnode1.getLeft();
                int i2 = sortnode1.getRight();
                int k = rand(k1, i2);
                swap(src, k1, k);
                int i1 = k1;
                for(int k2 = k1 + 1; k2 <= i2; k2++)
                {
                    if(src[k2].compareToIgnoreCase(src[k1]) < 0)
                    {
                        swap(src, ++i1, k2);
                    }
                }

                swap(src, k1, i1);
                if(i1 < i2)
                {
                    stack.push(new SortNode(i1 + 1, i2));
                }
                if(i1 > k1)
                {
                    stack.push(new SortNode(k1, i1 - 1));
                }
            } while(true);
        } else
        {
            do
            {
                if(stack.empty())
                {
                    break;
                }
                SortNode sortnode2 = (SortNode)stack.pop();
                int l1 = sortnode2.getLeft();
                int j2 = sortnode2.getRight();
                int l = rand(l1, j2);
                swap(src, l1, l);
                int j1 = l1;
                for(int l2 = l1 + 1; l2 <= j2; l2++)
                {
                    if(src[l2].compareToIgnoreCase(src[l1]) > 0)
                    {
                        swap(src, ++j1, l2);
                    }
                }

                swap(src, l1, j1);
                if(j1 < j2)
                {
                    stack.push(new SortNode(j1 + 1, j2));
                }
                if(j1 > l1)
                {
                    stack.push(new SortNode(l1, j1 - 1));
                }
            } while(true);
        }
        return src;
    }


    /**
    * 2011 차세대 프로젝트 Util 함수 추가
    */

	public static final String ENTER_CHAR = "\\u000D";
	public static final String ENTER_PATTERN = "[\\r]";



	/**
	 * subject에 포함된 각각의 문자를 object로 변환한다.
	 *
	 * @param source
	 *            원본 문자열
	 * @param subject
	 *            원본 문자열에 포함된 특정 문자열
	 * @param object
	 *            변환할 문자열
	 * @return sb.toString() 새로운 문자열로 변환된 문자열
	 */
	public static String replaceChar(String source, String subject,
			String object) {
		StringBuffer rtnStr = new StringBuffer();
		String preStr = "";
		String nextStr = source;
		String srcStr = source;

		char chA;

		for (int i = 0; i < subject.length(); i++) {
			chA = subject.charAt(i);

			if (srcStr.indexOf(chA) >= 0) {
				preStr = srcStr.substring(0, srcStr.indexOf(chA));
				nextStr = srcStr.substring(srcStr.indexOf(chA) + 1, srcStr
						.length());
				srcStr = rtnStr.append(preStr).append(object).append(nextStr)
						.toString();
			}
		}

		return srcStr;
	}

	/**
	 * <p>
	 * <code>str</code> 중 <code>searchStr</code>의 시작(index) 위치를 반환.
	 * </p>
	 *
	 * <p>
	 * 입력값 중 <code>null</code>이 있을 경우 <code>-1</code>을 반환.
	 * </p>
	 *
	 * <pre>
	 * StringUtil.indexOf(null, *)          = -1
	 * StringUtil.indexOf(*, null)          = -1
	 * StringUtil.indexOf(&quot;&quot;, &quot;&quot;)           = 0
	 * StringUtil.indexOf(&quot;aabaabaa&quot;, &quot;a&quot;)  = 0
	 * StringUtil.indexOf(&quot;aabaabaa&quot;, &quot;b&quot;)  = 2
	 * StringUtil.indexOf(&quot;aabaabaa&quot;, &quot;ab&quot;) = 1
	 * StringUtil.indexOf(&quot;aabaabaa&quot;, &quot;&quot;)   = 0
	 * </pre>
	 *
	 * @param str
	 *            검색 문자열
	 * @param searchStr
	 *            검색 대상문자열
	 * @return 검색 문자열 중 검색 대상문자열이 있는 시작 위치 검색대상 문자열이 없거나 null인 경우 -1
	 */
	public static int indexOf(String str, String searchStr) {
		if (str == null || searchStr == null) {
			return -1;
		}
		return str.indexOf(searchStr);
	}



	/**
	 * <p>
	 * 오라클의 decode 함수와 동일한 기능을 가진 메서드이다. <code>sourStr</code>과
	 * <code>compareStr</code>의 값이 같으면 <code>returStr</code>을 반환하며, 다르면
	 * <code>defaultStr</code>을 반환한다.
	 * </p>
	 *
	 * <pre>
	 * StringUtil.decode(null, null, &quot;foo&quot;, &quot;bar&quot;)= &quot;foo&quot;
	 * StringUtil.decode(&quot;&quot;, null, &quot;foo&quot;, &quot;bar&quot;) = &quot;bar&quot;
	 * StringUtil.decode(null, &quot;&quot;, &quot;foo&quot;, &quot;bar&quot;) = &quot;bar&quot;
	 * StringUtil.decode(&quot;하이&quot;, &quot;하이&quot;, null, &quot;bar&quot;) = null
	 * StringUtil.decode(&quot;하이&quot;, &quot;하이  &quot;, &quot;foo&quot;, null) = null
	 * StringUtil.decode(&quot;하이&quot;, &quot;하이&quot;, &quot;foo&quot;, &quot;bar&quot;) = &quot;foo&quot;
	 * StringUtil.decode(&quot;하이&quot;, &quot;하이  &quot;, &quot;foo&quot;, &quot;bar&quot;) = &quot;bar&quot;
	 * </pre>
	 *
	 * @param sourceStr
	 *            비교할 문자열
	 * @param compareStr
	 *            비교 대상 문자열
	 * @param returnStr
	 *            sourceStr와 compareStr의 값이 같을 때 반환할 문자열
	 * @param defaultStr
	 *            sourceStr와 compareStr의 값이 다를 때 반환할 문자열
	 * @return sourceStr과 compareStr의 값이 동일(equal)할 때 returnStr을 반환하며, <br/>
	 *         다르면 defaultStr을 반환한다.
	 */
	public static String decode(String sourceStr, String compareStr,
			String returnStr, String defaultStr) {
		if (sourceStr == null && compareStr == null) {
			return returnStr;
		}

		if (sourceStr == null && compareStr != null) {
			return defaultStr;
		}

		if (sourceStr.trim().equals(compareStr)) {
			return returnStr;
		}

		return defaultStr;
	}

	/**
	 * <p>
	 * 오라클의 decode 함수와 동일한 기능을 가진 메서드이다. <code>sourStr</code>과
	 * <code>compareStr</code>의 값이 같으면 <code>returStr</code>을 반환하며, 다르면
	 * <code>sourceStr</code>을 반환한다.
	 * </p>
	 *
	 * <pre>
	 * StringUtil.decode(null, null, &quot;foo&quot;) = &quot;foo&quot;
	 * StringUtil.decode(&quot;&quot;, null, &quot;foo&quot;) = &quot;&quot;
	 * StringUtil.decode(null, &quot;&quot;, &quot;foo&quot;) = null
	 * StringUtil.decode(&quot;하이&quot;, &quot;하이&quot;, &quot;foo&quot;) = &quot;foo&quot;
	 * StringUtil.decode(&quot;하이&quot;, &quot;하이 &quot;, &quot;foo&quot;) = &quot;하이&quot;
	 * StringUtil.decode(&quot;하이&quot;, &quot;바이&quot;, &quot;foo&quot;) = &quot;하이&quot;
	 * </pre>
	 *
	 * @param sourceStr
	 *            비교할 문자열
	 * @param compareStr
	 *            비교 대상 문자열
	 * @param returnStr
	 *            sourceStr와 compareStr의 값이 같을 때 반환할 문자열
	 * @return sourceStr과 compareStr의 값이 동일(equal)할 때 returnStr을 반환하며, <br/>
	 *         다르면 sourceStr을 반환한다.
	 */
	public static String decode(String sourceStr, String compareStr,
			String returnStr) {
		return decode(sourceStr, compareStr, returnStr, sourceStr);
	}

	/**
	 *<pre>
	 * 인자로 받은 String이 null일 경우 &quot;&quot;로 리턴한다.
	 * &#064;param src null값일 가능성이 있는 String 값.
	 * &#064;return 만약 String이 null 값일 경우 &quot;&quot;로 바꾼 String 값.
	 *</pre>
	 */
	public static String nullConvert(Object src) {
		// if (src != null &&
		// src.getClass().getName().equals("java.math.BigDecimal")) {
		if (src != null && src instanceof java.math.BigDecimal) {
			return ((BigDecimal) src).toString();
		}else if (src != null && src instanceof java.lang.Integer) {
			return ((Integer) src).toString();
		}

		if (src == null || src.equals("null")) {
			return "";
		} else {
			return ((String) src).trim();
		}
	}

	/**
	 *<pre>
	 * 인자로 받은 String이 null일 경우 &quot;&quot;로 리턴한다.
	 * &#064;param src null값일 가능성이 있는 String 값.
	 * &#064;return 만약 String이 null 값일 경우 &quot;&quot;로 바꾼 String 값.
	 *</pre>
	 */
	public static String nullConvert(String src) {

		if (src == null || src.equals("null") || "".equals(src)
				|| " ".equals(src)) {
			return "";
		} else {
			return src.trim();
		}
	}

	/**
	 *<pre>
	 * 인자로 받은 String이 null일 경우 &quot;0&quot;로 리턴한다.
	 * &#064;param src null값일 가능성이 있는 String 값.
	 * &#064;return 만약 String이 null 값일 경우 &quot;0&quot;로 바꾼 String 값.
	 *</pre>
	 */
	public static int zeroConvert(Object src) {

		if (src == null || src.equals("null")) {
			return 0;
		} else {
			return Integer.parseInt(((String) src).trim());
		}
	}

	/**
	 *<pre>
	 * 인자로 받은 String이 null일 경우 &quot;&quot;로 리턴한다.
	 * &#064;param src null값일 가능성이 있는 String 값.
	 * &#064;return 만약 String이 null 값일 경우 &quot;&quot;로 바꾼 String 값.
	 *</pre>
	 */
	public static int zeroConvert(String src) {

		if (src == null || src.equals("null") || "".equals(src)
				|| " ".equals(src)) {
			return 0;
		} else {
			return Integer.parseInt(src.trim());
		}
	}

	/**
	 * <p>
	 * 문자열에서 {@link Character#isWhitespace(char)}에 정의된 모든 공백문자를 제거한다.
	 * </p>
	 *
	 * <pre>
	 * StringUtil.removeWhitespace(null)         = null
	 * StringUtil.removeWhitespace(&quot;&quot;)           = &quot;&quot;
	 * StringUtil.removeWhitespace(&quot;abc&quot;)        = &quot;abc&quot;
	 * StringUtil.removeWhitespace(&quot;   ab  c  &quot;) = &quot;abc&quot;
	 * </pre>
	 *
	 * @param str
	 *            공백문자가 제거도어야 할 문자열
	 * @return the 공백문자가 제거된 문자열, null이 입력되면 <code>null</code>이 리턴
	 */
	public static String removeWhitespace(String str) {
		if (isNull(str)) {
			return str;
		}
		int sz = str.length();
		char[] chs = new char[sz];
		int count = 0;
		for (int i = 0; i < sz; i++) {
			if (!Character.isWhitespace(str.charAt(i))) {
				chs[count++] = str.charAt(i);
			}
		}
		if (count == sz) {
			return str;
		}

		return new String(chs, 0, count);
	}

	/**
	 * Html 코드가 들어간 문서를 표시할때 태그에 손상없이 보이기 위한 메서드
	 *
	 * @param strString
	 * @return HTML 태그를 치환한 문자열
	 */
	public static String checkHtmlView(String strString) {
		String strNew = "";

		try {
			StringBuffer strTxt = new StringBuffer("");

			char chrBuff;
			int len = strString.length();

			for (int i = 0; i < len; i++) {
				chrBuff = (char) strString.charAt(i);

				switch (chrBuff) {
				case '<':
					strTxt.append("&lt;");
					break;
				case '>':
					strTxt.append("&gt;");
					break;
				case '"':
					strTxt.append("&quot;");
					break;
				case 10:
					strTxt.append("<br>");
					break;
				case ' ':
					strTxt.append("&nbsp;");
					break;
				// case '&' :
				// strTxt.append("&amp;");
				// break;
				default:
					strTxt.append(chrBuff);
				}
			}

			strNew = strTxt.toString();

		} catch (NullPointerException ex) {
			return null;
		}

		return strNew;
	}


	/**
	 * 문자열을 지정한 분리자에 의해 배열로 리턴하는 메서드.
	 *
	 * @param source
	 *            원본 문자열
	 * @param separator
	 *            분리자
	 * @return result 분리자로 나뉘어진 문자열 배열
	 */
	public static String[] split(String source, String separator)
			throws NullPointerException {
		String[] returnVal = null;
		int cnt = 1;

		int index = source.indexOf(separator);
		int index0 = 0;
		while (index >= 0) {
			cnt++;
			index = source.indexOf(separator, index + 1);
		}
		returnVal = new String[cnt];
		cnt = 0;
		index = source.indexOf(separator);
		while (index >= 0) {
			returnVal[cnt] = source.substring(index0, index);
			index0 = index + 1;
			index = source.indexOf(separator, index + 1);
			cnt++;
		}
		returnVal[cnt] = source.substring(index0);

		return returnVal;
	}





	/**
	 * 입력된 String의 앞쪽에서 두번째 인자로 전달된 문자(stripChars)를 모두 제거한다.
	 * StringUtil.stripStart(null, *) = null StringUtil.stripStart(&quot;&quot;,
	 * *) = &quot;&quot; StringUtil.stripStart(&quot;abc&quot;, &quot;&quot;) =
	 * &quot;abc&quot; StringUtil.stripStart(&quot;abc&quot;, null) =
	 * &quot;abc&quot; StringUtil.stripStart(&quot; abc&quot;, null) =
	 * &quot;abc&quot; StringUtil.stripStart(&quot;abc &quot;, null) = &quot;abc
	 * &quot; StringUtil.stripStart(&quot; abc &quot;, null) = &quot;abc &quot;
	 * StringUtil.stripStart(&quot;yxabc &quot;, &quot;xyz&quot;) = &quot;abc
	 * &quot;
	 *
	 * @param str
	 *            지정된 문자가 제거되어야 할 문자열
	 * @param stripChars
	 *            제거대상 문자열
	 * @return 지정된 문자가 제거된 문자열, null이 입력되면 <code>null</code> 리턴
	 */
	public static String stripStart(String str, String stripChars) {
		int strLen;
		if (str == null || (strLen = str.length()) == 0) {
			return str;
		}
		int start = 0;
		if (stripChars == null) {
			while ((start != strLen)
					&& Character.isWhitespace(str.charAt(start))) {
				start++;
			}
		} else if (stripChars.length() == 0) {
			return str;
		} else {
			while ((start != strLen)
					&& (stripChars.indexOf(str.charAt(start)) != -1)) {
				start++;
			}
		}

		return str.substring(start);
	}

	/**
	 * 입력된 String의 뒤쪽에서 두번째 인자로 전달된 문자(stripChars)를 모두 제거한다.
	 * StringUtil.stripEnd(null, *) = null StringUtil.stripEnd(&quot;&quot;, *)
	 * = &quot;&quot; StringUtil.stripEnd(&quot;abc&quot;, &quot;&quot;) =
	 * &quot;abc&quot; StringUtil.stripEnd(&quot;abc&quot;, null) =
	 * &quot;abc&quot; StringUtil.stripEnd(&quot; abc&quot;, null) = &quot;
	 * abc&quot; StringUtil.stripEnd(&quot;abc &quot;, null) = &quot;abc&quot;
	 * StringUtil.stripEnd(&quot; abc &quot;, null) = &quot; abc&quot;
	 * StringUtil.stripEnd(&quot; abcyx&quot;, &quot;xyz&quot;) = &quot;
	 * abc&quot;
	 *
	 * @param str
	 *            지정된 문자가 제거되어야 할 문자열
	 * @param stripChars
	 *            제거대상 문자열
	 * @return 지정된 문자가 제거된 문자열, null이 입력되면 <code>null</code> 리턴
	 */
	public static String stripEnd(String str, String stripChars) {
		int end;
		if (str == null || (end = str.length()) == 0) {
			return str;
		}

		if (stripChars == null) {
			while ((end != 0) && Character.isWhitespace(str.charAt(end - 1))) {
				end--;
			}
		} else if (stripChars.length() == 0) {
			return str;
		} else {
			while ((end != 0)
					&& (stripChars.indexOf(str.charAt(end - 1)) != -1)) {
				end--;
			}
		}

		return str.substring(0, end);
	}

	/**
	 * <p>
	 * 입력된 String의 앞, 뒤에서 두번째 인자로 전달된 문자(stripChars)를 모두 제거한다.
	 * </p>
	 *
	 * <pre>
	 * StringUtil.strip(null, *)          = null
	 * StringUtil.strip(&quot;&quot;, *)            = &quot;&quot;
	 * StringUtil.strip(&quot;abc&quot;, null)      = &quot;abc&quot;
	 * StringUtil.strip(&quot;  abc&quot;, null)    = &quot;abc&quot;
	 * StringUtil.strip(&quot;abc  &quot;, null)    = &quot;abc&quot;
	 * StringUtil.strip(&quot; abc &quot;, null)    = &quot;abc&quot;
	 * StringUtil.strip(&quot;  abcyx&quot;, &quot;xyz&quot;) = &quot;  abc&quot;
	 * </pre>
	 *
	 * @param str
	 *            지정된 문자가 제거되어야 할 문자열
	 * @param stripChars
	 *            제거대상 문자열
	 * @return 지정된 문자가 제거된 문자열, null이 입력되면 <code>null</code> 리턴
	 */
	public static String strip(String str, String stripChars) {
		if (isNull(str)) {
			return str;
		}

		String srcStr = str;
		srcStr = stripStart(srcStr, stripChars);

		return stripEnd(srcStr, stripChars);
	}

	/**
	 * 문자열을 지정한 분리자에 의해 지정된 길이의 배열로 리턴하는 메서드.
	 *
	 * @param source
	 *            원본 문자열
	 * @param separator
	 *            분리자
	 * @param arraylength
	 *            배열 길이
	 * @return 분리자로 나뉘어진 문자열 배열
	 */
	public static String[] split(String source, String separator,
			int arraylength) throws NullPointerException {
		String[] returnVal = new String[arraylength];
		int cnt = 0;
		int index0 = 0;
		int index = source.indexOf(separator);
		while (index >= 0 && cnt < (arraylength - 1)) {
			returnVal[cnt] = source.substring(index0, index);
			index0 = index + 1;
			index = source.indexOf(separator, index + 1);
			cnt++;
		}
		returnVal[cnt] = source.substring(index0);
		if (cnt < (arraylength - 1)) {
			for (int i = cnt + 1; i < arraylength; i++) {
				returnVal[i] = "";
			}
		}

		return returnVal;
	}

	/**
	 * 문자열 A에서 Z사이의 랜덤 문자열을 구하는 기능을 제공 시작문자열과 종료문자열 사이의 랜덤 문자열을 구하는 기능
	 *
	 * @param startChr
	 *            - 첫 문자
	 * @param endChr
	 *            - 마지막문자
	 * @return 랜덤문자
	 * @exception MyException
	 * @see
	 */
	public static String getRandomStr(char startChr, char endChr) {

		int randomInt;
		String randomStr = null;

		// 시작문자 및 종료문자를 아스키숫자로 변환한다.
		int startInt = Integer.valueOf(startChr);
		int endInt = Integer.valueOf(endChr);

		// 시작문자열이 종료문자열보가 클경우
		if (startInt > endInt) {
			throw new IllegalArgumentException("Start String: " + startChr
					+ " End String: " + endChr);
		}

		try {
			// 랜덤 객체 생성
			SecureRandom rnd = new SecureRandom();

			do {
				// 시작문자 및 종료문자 중에서 랜덤 숫자를 발생시킨다.
				randomInt = rnd.nextInt(endInt + 1);
			} while (randomInt < startInt); // 입력받은 문자 'A'(65)보다 작으면 다시 랜덤 숫자
			// 발생.

			// 랜덤 숫자를 문자로 변환 후 스트링으로 다시 변환
			randomStr = (char) randomInt + "";
		} catch (NullPointerException e) {
			log.debug(e.getMessage());
		}

		// 랜덤문자열를 리턴
		return randomStr;
	}



/**
     * 특수문자를 웹 브라우저에서 정상적으로 보이기 위해 특수문자를 처리('<' -> & lT)하는 기능이다
     * @param 	srcString 		- '<'
     * @return 	변환문자열('<' -> "&lt"
     * @exception MyException
     * @see
     */
	public static String getSpclStrCnvr(String srcString) {

		String rtnStr = null;

		try {
			StringBuffer strTxt = new StringBuffer("");

			char chrBuff;
			int len = srcString.length();

			for (int i = 0; i < len; i++) {
				chrBuff = (char) srcString.charAt(i);

				switch (chrBuff) {
				case '<':
					strTxt.append("&lt;");
					break;
				case '>':
					strTxt.append("&gt;");
					break;
				case '&':
					strTxt.append("&amp;");
					break;
				default:
					strTxt.append(chrBuff);
				}
			}

			rtnStr = strTxt.toString();

		} catch (NullPointerException e) {
			log.debug(e.getMessage());
		}

		return rtnStr;
	}

	/**
	 * 응용어플리케이션에서 고유값을 사용하기 위해 시스템에서17자리의TIMESTAMP값을 구하는 기능
	 *
	 * @param
	 * @return Timestamp 값
	 * @exception MyException
	 * @see
	 */
	public static String getTimeStamp() {

		String rtnStr = null;

		// 문자열로 변환하기 위한 패턴 설정(년도-월-일 시:분:초:초(자정이후 초))
		String pattern = "yyyyMMddhhmmssSSS";

		try {
			SimpleDateFormat sdfCurrent = new SimpleDateFormat(pattern,
					Locale.KOREA);
			Timestamp ts = new Timestamp(System.currentTimeMillis());

			rtnStr = sdfCurrent.format(ts.getTime());
		} catch (NullPointerException e) {
			log.debug(e.getMessage());
		}

		return rtnStr;
	}

	/**
	 * html의 특수문자를 표현하기 위해
	 *
	 * @param srcString
	 * @return String
	 * @exception Exception
	 * @see
	 */
	public static String getHtmlStrCnvr(String srcString) {

		String tmpString = srcString;

		try {
			tmpString = tmpString.replaceAll("&lt;", "<");
			tmpString = tmpString.replaceAll("&gt;", ">");
			tmpString = tmpString.replaceAll("&amp;", "&");
			tmpString = tmpString.replaceAll("&nbsp;", " ");
			tmpString = tmpString.replaceAll("&apos;", "\'");
			tmpString = tmpString.replaceAll("&quot;", "\"");
		} catch (NullPointerException e) {
			log.debug(e.getMessage());
		}

		return tmpString;

	}

	/**
	 * <p>
	 * 날짜 형식의 문자열 내부에 마이너스 character(-)를 추가한다.
	 * </p>
	 *
	 * <pre>
	 * StringUtil.addMinusChar(&quot;20100901&quot;) = &quot;2010-09-01&quot;
	 * </pre>
	 *
	 * @param date
	 *            입력받는 문자열
	 * @return " - "가 추가된 입력문자열
	 */
	public static String addMinusChar(String date) {
		if (date.length() == 8)
			return date.substring(0, 4).concat("-")
					.concat(date.substring(4, 6)).concat("-").concat(
							date.substring(6, 8));
		else
			return "";
	}



	/**
	 * 문자열의 Space 제거
	 *
	 * @param str 문자열
	 * @return Space 제거된 문자열
	 */
	public static String RemoveSpaceFromString(String str) {
		if (isNull(str)) {
			return "";
		}
		return str.replaceAll(SPACE_PATTERN, "");
	}

	/**
	 *
	 * String.toUpperCase()를 이용하여 대문자로 변환한다.
	 *
	 * StringUtil.upperCase(null)  = null
	 * StringUtil.upperCase(&quot;&quot;)    = &quot;&quot;
	 * StringUtil.upperCase(&quot;aBc&quot;) = &quot;ABC&quot;
	 *
	 * @param str
	 *            대문자로 변환되어야 할 문자열
	 * @return 대문자로 변환된 문자열, null이 입력되면 <code>null</code> 리턴
	 */
	public static String upperCase(String str) {
		if (str == null) {
			return null;
		}
		return str.toUpperCase();
	}
	/**
	 * String.toLowerCase()를 이용하여 소문자로 변환한다.
	 *
	 * StringUtil.lowerCase(null)  = null
	 * StringUtil.lowerCase(&quot;&quot;)    = &quot;&quot;
	 * StringUtil.lowerCase(&quot;aBc&quot;) = &quot;abc&quot;
	 * @param str
	 *            소문자로 변환되어야 할 문자열
	 * @return 소문자로 변환된 문자열, null이 입력되면 <code>null</code> 리턴
	 */
	public static String lowerCase(String str) {
		if (str == null) {
			return null;
		}

		return str.toLowerCase();
	}


	/**
	 * 10진수 16진수로 변환
	 *
	 * @param sDecNumber : 변환할 10진수 정수
	 * @return String : 변환된 16진수 값
	 */
	public static String ChangeDecToHex(String sDecNumber) {
		if (StringUtil.isDigit(sDecNumber))
			return StringUtil.upperCase(Integer.toHexString(Integer
					.parseInt(sDecNumber)));
		else {
			return "";
		}
	}

	/**
	 * 객체가 null인지 확인하고 null인 경우 "" 로 바꾸는 메서드
	 *
	 * @param object
	 *            원본 객체
	 * @return resultVal 문자열
	 */
	public static String isNullToString(Object object) {
		String string = "";

		if (object != null) {
			string = object.toString().trim();
		}

		return string;
	}


	/**
	 * 기준 문자열에 포함된 모든 대상 문자(char)를 제거한다. StringUtil.remove(null, *) = null
	 * StringUtil.remove(&quot;&quot;, *) = &quot;&quot;
	 * StringUtil.remove(&quot;queued&quot;, 'u') = &quot;qeed&quot;
	 * StringUtil.remove(&quot;queued&quot;, 'z') = &quot;queued&quot;
	 *
	 * @param str
	 *            입력받는 기준 문자열
	 * @param remove
	 *            입력받는 문자열에서 제거할 대상 문자열
	 * @return 제거대상 문자열이 제거된 입력문자열. 입력문자열이 null인 경우 출력문자열은 null
	 */
	public static String remove(String str, char remove) {
		if (isNull(str) || str.indexOf(remove) == -1) {
			return str;
		}
		char[] chars = str.toCharArray();
		int pos = 0;
		for (int i = 0; i < chars.length; i++) {
			if (chars[i] != remove) {
				chars[pos++] = chars[i];
			}
		}
		return new String(chars, 0, pos);
	}

	/**
	 * 문자열 내부의 콤마 character(,)를 모두 제거한다.
	 * StringUtil.removeCommaChar(null)       = null
	 * StringUtil.removeCommaChar(&quot;&quot;)         = &quot;&quot;
	 * StringUtil.removeCommaChar(&quot;asdfg,qweqe&quot;) = &quot;asdfgqweqe&quot;
	 *
	 * @param str
	 *            입력받는 기준 문자열
	 * @return " , "가 제거된 입력문자열 입력문자열이 null인 경우 출력문자열은 null
	 */
	public static String removeCommaChar(String str) {
		return remove(str, ',');
	}

	/**
	 * 문자열 내부의 마이너스 character(-)를 모두 제거한다. StringUtil.removeMinusChar(null) =
	 * null StringUtil.removeMinusChar(&quot;&quot;) = &quot;&quot;
	 * StringUtil.removeMinusChar(&quot;a-sdfg-qweqe&quot;) =
	 * &quot;asdfgqweqe&quot;
	 *
	 * @param str
	 *            입력받는 기준 문자열
	 * @return " - "가 제거된 입력문자열 입력문자열이 null인 경우 출력문자열은 null
	 */
	public static String removeMinusChar(String str) {
		return remove(str, '-');
	}

	/**
	 * 문자열 Length Check
	 *
	 * @param str
	 *            문자열
	 * @param strLength
	 *            문자열 길이
	 * @return true(기준 문자열 길이와 동일시)/false
	 */
	public static boolean checkStingLength(String str, int strLength) {

		if (isNull(str)) {
			return false;
		}
		if (str.length() == strLength)
			return true;
		else
			return false;
	}

	/**
	 * 금액을 한글 변환
	 *
	 * @param 금액
	 * @return 한글 변환 금액
	 */
	public static String ConvertMoneyToHangul(String money) {

		String tempMoney = ReplaceSpecialKeyToCode(money, ",", "");
		if (!isDigit(tempMoney)) {
			return "영";
		}
		if (tempMoney.length() > 16) {
			return "최대 9999조를 초과 할수 었습니다. 확인하십시요.";
		}
		String[] han1 = { "", "일", "이", "삼", "사", "오", "육", "칠", "팔", "구" };
		String[] han2 = { "", "십", "백", "천" };
		String[] han3 = { "", "만", "억", "조" };

		StringBuffer result = new StringBuffer();
		int len = tempMoney.length();
		for (int i = len - 1; i >= 0; i--) {
			result.append(han1[Integer.parseInt(tempMoney.substring(
					len - i - 1, len - i))]);
			if (Integer.parseInt(tempMoney.substring(len - i - 1, len - i)) > 0) {
				result.append(han2[i % 4]);
			}
			if (i % 4 == 0) {
				result.append(han3[i / 4]);
			}
		}
		return result.toString() + "원";
	}

	/**
	 * 금액을 한자 변환
	 *
	 * @param 금액
	 * @return 한자 변환 금액
	 */
	public static String ConvertMoneyToHanja(String money) {

		String tempMoney = ReplaceSpecialKeyToCode(money, ",", "");
		if (!isDigit(tempMoney)) {
			return "零";
		}
		if (tempMoney.length() > 16) {
			return "최대 9999조를 초과 할수 었습니다. 확인하십시요.";
		}
		String[] han1 = { "", "壹", "貳", "參", "四", "五", "六", "七", "八", "九" };
		String[] han2 = { "", "拾", "佰", "仟" };
		String[] han3 = { "", "萬", "億", "兆" };

		StringBuffer result = new StringBuffer();
		int len = tempMoney.length();
		for (int i = len - 1; i >= 0; i--) {
			result.append(han1[Integer.parseInt(tempMoney.substring(
					len - i - 1, len - i))]);
			if (Integer.parseInt(tempMoney.substring(len - i - 1, len - i)) > 0) {
				result.append(han2[i % 4]);
			}
			if (i % 4 == 0) {
				result.append(han3[i / 4]);
			}
		}
		return result.toString() + "원整";
	}
	//기존 코드 검사 필요
	/**
	 * 문자열에서 특수문자열 변환
	 *
	 * @param 문자열
	 * @param 변경
	 *            대상 문자열
	 * @param 변경
	 *            할 문자열 * @return 변경된 문자열
	 */
	public static String ReplaceSpecialKeyToCode(String oriStr, String fromStr,
			String toStr) {
		if (isNull(oriStr)) {
			return "";
		}
		return oriStr.replaceAll(fromStr, toStr);
	}
	/**
	 * 문자열에서 EnterKey를 특수 문자로 변환
	 *
	 * @param 문자열
	 *            * @return Space 제거된 문자열
	 */
	public static String ReplaceFromEnterKeyToCode(String srcString) {
		if (isNull(srcString)) {
			return "";
		}

		String rtnStr = null;
		String temp = Character.toString((char) 127);
		try {
			StringBuffer strTxt = new StringBuffer("");

			char chrBuff1;
			char chrBuff2;
			int len = srcString.length();

			for (int i = 0; i < len; i++) {

				chrBuff1 = (char) srcString.charAt(i);
				switch (chrBuff1) {
				case '\r':
					if (i + 1 < len) {
						chrBuff2 = (char) srcString.charAt(i + 1);
						if (chrBuff2 == '\n') {
							strTxt.append(temp);
						} else {
							strTxt.append(chrBuff1);
						}
					} else
						strTxt.append(chrBuff1);
					break;
				case '\n':
					if (i - 1 > 0) {
						chrBuff2 = (char) srcString.charAt(i - 1);
						if (chrBuff2 == '\r') {
							strTxt.append(temp);
						} else {
							strTxt.append(chrBuff1);
						}
					} else
						strTxt.append(chrBuff1);
					break;
				default:
					strTxt.append(chrBuff1);
				}
			}

			rtnStr = strTxt.toString();

		} catch (NullPointerException e) {
			log.debug(e.getMessage());
		}
		return rtnStr;
	}

	/**
	 * 문자열의 비교 (Byte 단위 비교)
	 *
	 * @param 문자열1
	 * @param 문자열2
	 * @return 비교 결과 0 : 문자열 동일 -1 : 첫번째 입력 문자열 NULL -2 : 두번째 입력 문자열 NULL -3 :
	 *         동일 문자열 아님
	 */
	public static int CompareStringByBytes(String str1, String str2) {
		if (isNull(str1)) {
			return -1;
		}
		if (isNull(str2)) {
			return -2;
		}
		if (str1.getBytes().length != str2.getBytes().length) {
			return -3;
		}
		for (int j = 0; j < str1.getBytes().length; j++) {
			if (str1.getBytes()[j] != str2.getBytes()[j]) {
				return -3;
			}
		}

		return 0;
	}
	/**
	 * 문자열에서 특수 문자를 Enter로 변환
	 *
	 * @param 문자열
	 * @return 특수 문자를 Enter로 변환된 문자열
	 */
	public static String ReplaceFromCodeToEnterKey(String srcString) {
		if (isNull(srcString)) {
			return "";
		}
		char car = '\r';
		char newl = '\n';
		String rtnStr = Character.toString(car) + Character.toString(newl);
		String temp = Character.toString((char) 127)
				+ Character.toString((char) 127);
		String tmpString = srcString;

		try {
			tmpString = tmpString.replaceAll(temp, rtnStr);
		} catch (NullPointerException e) {
			log.debug(e.getMessage());
		}
		return tmpString;
	}

	/**
	 * Number를 Char(아라비아) 숫자로 변환
	 *
	 * @param number
	 * @return 한글 변환
	 */
	public static String ConvertNumberToChar(String number) {
		String tempNumber = ReplaceSpecialKeyToCode(number, ",", "");
		if (!isDigit(tempNumber)) {
			return "영";
		}
		String[] han1 = { "", "일", "이", "삼", "사", "오", "육", "칠", "팔", "구" };
		String[] han2 = { "", "십", "백", "천" };
		String[] han3 = { "", "만", "억", "조" };

		StringBuffer result = new StringBuffer();
		int len = tempNumber.length();
		for (int i = len - 1; i >= 0; i--) {
			result.append(han1[Integer.parseInt(tempNumber.substring(len - i
					- 1, len - i))]);
			if (Integer.parseInt(tempNumber.substring(len - i - 1, len - i)) > 0) {
				result.append(han2[i % 4]);
			}
			if (i % 4 == 0) {
				result.append(han3[i / 4]);
			}
		}
		return result.toString();
	}

	/**
	 * DB의 Date로 들어갈때 영향 미치는 특수 문자 변형 위한 메서드
	 *
	 * @param strString
	 * @return DB Date로 저장하기 위해 특수문자 치환된 문자열
	 */
	public static String checkDBDate(String strString) {
		String strNew = "";
		try {
			StringBuffer strTxt = new StringBuffer("");

			char chrBuff;
			int len = strString.length();
			if (len == 0) {
				strTxt.append("NUL");
				strNew = strTxt.toString();
			} else {
				for (int i = 0; i < len; i++) {
					chrBuff = (char) strString.charAt(i);

					switch (chrBuff) {
					case '"':
						strTxt.append("\\\"");
						break;
					case '\'':
						strTxt.append("\\'");
						break;
					case '\\':
						strTxt.append("\\\\");
						break;
					default:
						strTxt.append(chrBuff);
					}
				}

				strNew = strTxt.toString();
			}

		} catch (NullPointerException ex) {
			return null;
		}

		return strNew;
	}

	/**
	 *
	 * str 중 시작위지 이후에 searchStr의 시작(index) 위치를 반환. 입력값 중 null이 있을 경우 -1을 반환.
	 *
	 * @param str
	 *            검색 문자열
	 * @param searchStr
	 *            검색 대상문자열
	 * @param startPos
	 *            검색 대상문자열
	 * @return 검색 문자열 중 검색 대상문자열이 있는 시작 위치 검색대상 문자열이 없거나 null인 경우 -1
	 */
	public static int indexOfWithStartPos(String str, String searchStr,
			int startPos) {
		if (str == null || searchStr == null) {
			return -1;
		}
		if (startPos > 0) {
			String tmpStr = str.substring(startPos);
			return tmpStr.indexOf(searchStr);
		} else {
			return str.indexOf(searchStr);
		}
	}
	/**
	 * 원본 문자열에서 처음 발견된 포함된 특정 문자열을 새로운 문자열로 변환하는 메서드
	 *
	 * @param source
	 *            원본 문자열
	 * @param subject
	 *            원본 문자열에 포함된 특정 문자열
	 * @param object
	 *            변환할 문자열
	 * @return sb.toString() 새로운 문자열로 변환된 문자열
	 */
	public static String replaceFirst(String source, String subject,
			String object) {
		StringBuffer rtnStr = new StringBuffer();
		String preStr = "";
		String nextStr = source;
		String srcStr = source;

		if (srcStr.indexOf(subject) >= 0) {
			preStr = srcStr.substring(0, srcStr.indexOf(subject));
			nextStr = srcStr.substring(srcStr.indexOf(subject)
					+ subject.length(), srcStr.length());
			srcStr = nextStr;
			rtnStr.append(preStr).append(object);
		}
		rtnStr.append(nextStr);
		return rtnStr.toString();
	}
	/**
	 * 문자열의 Enter 값 처리 (검색)
	 *
	 * @param 문자열
	 * @return 문자열의 Enter 값 처리된 문자열
	 */
	public static String RemoveEnterFromString(String srcString) {
		if (isNull(srcString)) {
			return "";
		}
		int endPos = 0;
		int endTab = 0;
		int startPos = 0;
		String oldNew, oldTab;
		String newStr = " ";
		String tmp = srcString;
		oldTab = Character.toString('\t');
		oldNew = Character.toString('\r') + Character.toString('\n');

		while (endTab != -1) {
			// 전체 string을 enter 별로 끊어 처리한다

			endPos = indexOfWithStartPos(tmp, oldNew, startPos);
			endTab = indexOfWithStartPos(tmp, oldTab, startPos);
			if (endTab == -1 || endPos == -1) {
				return tmp;
			} else if (endTab > endPos) {
				tmp = replaceFirst(tmp, oldNew, newStr);
				startPos = endPos + newStr.length();
			} else {
				startPos = endPos;
			}
		}
		return srcString;
	}
	/**
	 * 2 Byte 조합(상용조합)형 한글을 2 Byte 완성형(KSC 5601) String temp = new
	 * String(문자열.getBytes("8859_1"),"KSC5601"); => UTF-8 에서 EUC-KR
	 *
	 * @param srcString
	 *            - 문자열
	 * @param srcCharsetNm
	 *            - 원래 CharsetNm
	 * @param charsetNm
	 *            - CharsetNm
	 * @return 인(디)코딩 문자열
	 * @exception MyException
	 * @see
	 */
	public static String EncodeUNICODEToKSC5601(String conStr) {
		return getEncdDcd(conStr, "UNICODE", "KSC5601");
	}

	/**
	 * 문자열을 다양한 문자셋(EUC-KR[KSC5601],UTF-8..)을 사용하여 인코딩하는 기능 역으로 디코딩하여 원래의 문자열을
	 * 복원하는 기능을 제공함 String temp = new String(문자열.getBytes("바꾸기전 인코딩"),"바꿀 인코딩");
	 * String temp = new String(문자열.getBytes("8859_1"),"KSC5601"); => UTF-8 에서
	 * EUC-KR
	 *
	 * @param srcString
	 *            - 문자열
	 * @param srcCharsetNm
	 *            - 원래 CharsetNm
	 * @param charsetNm
	 *            - CharsetNm
	 * @return 인(디)코딩 문자열
	 * @exception MyException
	 * @see
	 */
	public static String getEncdDcd(String srcString, String srcCharsetNm,
			String cnvrCharsetNm) {

		String rtnStr = null;

		if (srcString == null)
			return null;

		try {
			rtnStr = new String(srcString.getBytes(srcCharsetNm), cnvrCharsetNm);
		} catch (UnsupportedEncodingException e) {
			rtnStr = null;
		}
		return rtnStr;
	}
	/**
	 * 문자열이 지정한 길이를 초과했을때 지정한길이에다가 해당 문자열을 붙여주는 메서드.
	 *
	 * @param source
	 *            원본 문자열 배열
	 * @param output
	 *            더할문자열
	 * @param slength
	 *            지정길이
	 * @return 지정길이로 잘라서 더할분자열 합친 문자열
	 */
	public static String cutString(String source, String output, int slength) {
		String returnVal = null;
		if (source != null) {
			if (source.length() > slength) {
				returnVal = source.substring(0, slength) + output;
			} else
				returnVal = source;
		}
		return returnVal;
	}

	/**
	 * 문자열이 지정한 길이를 초과했을때 해당 문자열을 삭제하는 메서드
	 *
	 * @param source
	 *            원본 문자열 배열
	 * @param slength
	 *            지정길이
	 * @return 지정길이로 잘라서 더할분자열 합친 문자열
	 */
	public static String cutString(String source, int slength) {
		String result = null;
		if (source != null) {
			if (source.length() > slength) {
				result = source.substring(0, slength);
			} else
				result = source;
		}
		return result;
	}





	/**
	 * 원본 문자열의 포함된 특정 문자열 첫번째 한개만 새로운 문자열로 변환하는 메서드
	 *
	 * @param source
	 *            원본 문자열
	 * @param subject
	 *            원본 문자열에 포함된 특정 문자열
	 * @param object
	 *            변환할 문자열
	 * @return sb.toString() 새로운 문자열로 변환된 문자열 / source 특정문자열이 없는 경우 원본 문자열
	 */
	public static String replaceOnce(String source, String subject,
			String object) {
		StringBuffer rtnStr = new StringBuffer();
		String preStr = "";
		String nextStr = source;
		if (source.indexOf(subject) >= 0) {
			preStr = source.substring(0, source.indexOf(subject));
			nextStr = source.substring(source.indexOf(subject)
					+ subject.length(), source.length());
			rtnStr.append(preStr).append(object).append(nextStr);
			return rtnStr.toString();
		} else {
			return source;
		}
	}


	 /**
	 * 원본 문자열의 특정 위치의 글자를 추출하는 기능
	 *
     * tgt.substring(sPos, ePos) 기능인데 outofindexException 발생안함.
     * ex)
     * substring("abcd", 2, 3) ====> "c"
     * substring("abcd", 2, 4) ====> "cd"
     * substring("abcd", 2, 5) ====> "cd"
     * substring("abcd", 5, 10) ====> ""
     *
     * substring("abcde", 3) ====> "de"
     * substring("abcde", 8) ====> ""
     * substring("abcde", 0) ====> "abcde"
     *
     * @param tgt
     * @param sPos
     * @param ePos
     * @return
     */

    public static String substring(String tgt, int sPos){
        if( tgt == null ){
        	return "";
        }
        return substring(tgt, sPos, tgt.length());
    }

    public static String substring(String tgt, int sPos, int ePos){
        if( tgt == null ){
        	return "";
        }
        int maxLen = tgt.length();
        if( maxLen <= sPos ){
        	return "";
        }
        return tgt.substring(sPos, (maxLen < ePos)?maxLen:ePos);
    }

    /**
     * 현재시간 리턴 (형식 2017-01-01 11:11:11)
     * @return
     */
	public static String getCurTime(){
		Calendar cal = Calendar.getInstance(Locale.KOREA);

		String rtrn = Integer.toString(cal.get(Calendar.YEAR))
				+"-"+StringUtil.lpad(Integer.toString(cal.get(Calendar.MONTH)+1),2,"0")
				+"-"+StringUtil.lpad(Integer.toString(cal.get(Calendar.DATE)),2,"0")
				+" "+StringUtil.lpad(Integer.toString(cal.get(Calendar.HOUR_OF_DAY)),2,"0")
				+":"+StringUtil.lpad(Integer.toString(cal.get(Calendar.MINUTE)),2,"0")
				+":"+StringUtil.lpad(Integer.toString(cal.get(Calendar.SECOND)),2,"0")
				+":"+StringUtil.lpad(Integer.toString(cal.get(Calendar.MILLISECOND)),3,"0");

		return rtrn;
	}
	@SuppressWarnings("unused")
    public static String[] stringByteCutStringArr(String val, int size) {
	    String[] arr =null;
	    if(val == null) return arr;
	    if(val.length() == 0) {
	        arr = new String[1];
            arr[0] = val;
	        return arr;
	    }

	    try {
            byte strByte[] = val.getBytes("UTF-8");
            int rawLength =strByte.length;
            if(strByte.length <= size) {
                arr = new String[1];
                arr[0] = val;
                return arr;
            }
            int endPos = 0; //마지막 바이트 위치
            int currByte = 0; //현재까지 조사한 바이트 수
            int maxSize = size;
            List<String> list = new ArrayList<>();
            for (int i  = 0; i < val.length(); i++) {
                char ch = val.charAt(i);
                currByte = currByte + availibleByteNum(ch);
                if(currByte > maxSize) {
                    endPos = currByte - availibleByteNum(ch);
                    maxSize = endPos+size;
                    list.add(endPos+"");
                }
                if(i == val.length()-1) {
                    list.add(currByte+"");
                }
            }
            arr = new String[list.size()];
            int listEndPos = 0;
            for (int i  = 0; i < list.size(); i++) {
                listEndPos =  Integer.parseInt(list.get(i));
                int lastSzie = i == 0 ? listEndPos : listEndPos- Integer.parseInt(list.get(i-1));
                byte newValByte[] = new byte[lastSzie];
                if(i == 0) {
                    System.arraycopy(strByte, 0, newValByte, 0, listEndPos);
                }else {
                    System.arraycopy(strByte, Integer.parseInt(list.get(i-1)), newValByte, 0, lastSzie);
                }
                arr[i] = new String(newValByte, "UTF-8");
            }

        } catch (UnsupportedEncodingException e) {
            // TODO Auto-generated catch block
            log.debug(e.getMessage());
        }


	    return arr;
	}

	@SuppressWarnings("unused")
    public static String[] stringByteCutStringArr(String val, int size, String lastVal) {
        String[] arr =null;
        if(val == null) return arr;
        if(val.length() == 0) {
            arr = new String[1];
            arr[0] = val;
            return arr;
        }

        try {
            byte strByte[] = val.getBytes("UTF-8");
            int rawLength =strByte.length;
            if(strByte.length <= size) {
                arr = new String[1];
                arr[0] = val;
                return arr;
            }
            int endPos = 0; //마지막 바이트 위치
            int currByte = 0; //현재까지 조사한 바이트 수
            int maxSize = size;
            int checkData = 0;
            List<String> list = new ArrayList<>();
            for (int i  = 0; i < val.length(); i++) {
                char ch = val.charAt(i);
                currByte = currByte + availibleByteNum(ch);
                if(ch == lastVal.charAt(0))
                {
                    checkData = currByte;
                }
                if(currByte > maxSize) {
                    //endPos = currByte - availibleByteNum(ch);
                    endPos =checkData;
                    maxSize = endPos+size;
                    list.add(endPos+"");
                }
                if(i == val.length()-1) {
                    list.add(currByte+"");
                }
            }
            arr = new String[list.size()];
            int listEndPos = 0;

            for (int i  = 0; i < list.size(); i++) {
                listEndPos =  Integer.parseInt(list.get(i));
                int lastSzie = i == 0 ? listEndPos : listEndPos- Integer.parseInt(list.get(i-1));
                byte newValByte[] = new byte[lastSzie];
                if(i == 0) {
                    System.arraycopy(strByte, 0, newValByte, 0, listEndPos);
                }else {
                    System.arraycopy(strByte, Integer.parseInt(list.get(i-1)), newValByte, 0, lastSzie);
                }
                arr[i] = new String(newValByte, "UTF-8");
            }

        } catch (UnsupportedEncodingException e) {
            // TODO Auto-generated catch block
            log.debug(e.getMessage());
        }


        return arr;
    }
	public static int availibleByteNum(char c) {
	    int oneByteMin = 0x0000;
	    int oneByteMax = 0x007F;

	    int twoByteMin = 0x0800;
	    int twoByteMax = 0x07FF;

	    int threeByteMin = 0x0800;
	    int threeByteMax = 0xFFFF;

	    int surrogateMin = 0x10000;
	    int surrogateMax = 0x10FFFF;

	    int digit = (int)c;
	    if(oneByteMin <= digit && digit <= oneByteMax) return 1;
	    else if(twoByteMin <= digit && digit <= twoByteMax) return 2;
	    else if(threeByteMin <= digit && digit <= threeByteMax) return 3;
	    else if(surrogateMin <= digit && digit <= surrogateMax) return 4;
	    return -1;
	}
	
	public static String[] objectConvert(Object... array) {
	    
	    List<String> tmpList = new ArrayList<String>();
        for (int i = 0; i < array.length; i++) {
            if(array[i] instanceof String[]) {
                String[] arrStrTmp = (String[]) array[i];
                for (int j = 0; j < arrStrTmp.length; j++) {
                    tmpList.add(arrStrTmp[j]);
                }
            }else {
                tmpList.add(array[i]+"");
            }
                
        }
        String[] arrStr = tmpList.toArray(new String[tmpList.size()]);
        return arrStr;
    }
	
	public static String[] convertArray(String... array) {
	    return array;
	}

	public static String[] convertArray(int... array) {
	    String[] arrStr = new String[array.length];
	    for (int i = 0; i < array.length; i++) {
	        arrStr[i] = array[i]+"";
        }

        return arrStr;
    }
	public static String getMaskedPhoneNum(String phoneNum) {
	    String regex = "(\\d{2,3})(\\d{3,4})(\\d{4})$";
	    //String regex = "(\\d{2,3})-?(\\d{3,4})-?(\\d{4})$";       //휴대폰번호 '-' 포함
	    Matcher matcher = Pattern.compile(regex).matcher(phoneNum);
	    if (matcher.find()) {
	        String replaceTarget = matcher.group(2);
	        char[] c = new char[replaceTarget.length()];
	        Arrays.fill(c, '*');

	        return phoneNum.replace(replaceTarget, String.valueOf(c));
	    }
	    
	    return phoneNum;
	}
	public static String getMaskEmailAdr(String email) {
	    final String mask = "*****";
	    final int at = email.indexOf("@");
	    if (at > 2) {
	        final int maskLen = Math.min(Math.max(at / 2, 2), 4);
	        final int start = (at - maskLen) / 2;
	        return email.substring(0, start) + mask.substring(0, maskLen) + email.substring(start + maskLen);
	    }
	    return email;
	}
	/**
    * Encodes the passed String as UTF-8 using an algorithm that's compatible
    * with JavaScript's
    * <code>encodeURIComponent</code> function. Returns
    * <code>null</code> if the String is
    * <code>null</code>.
    *
    * @param s The String to be encoded
    * @return the encoded String
    */
   public static String encodeURI(String s) {
       String result;
       try {
           result = URLEncoder.encode(s, "UTF-8")
                   .replaceAll("%3A", ":")
                   .replaceAll("%2F", "/")
                   .replaceAll("%3F", "?")
                   .replaceAll("%3D", "=")
                   .replaceAll("%26", "&");
       } // This exception should never occur.
       catch (Exception e) {
           result = s;
       }

       return result;
   }
}
