package kfi.core.exception;

import java.util.Locale;
import org.springframework.context.MessageSource;
import kfi.core.util.MessageUtils;



/**
 *
 * @className : AbstractRuntimeException
 * @description : Exception Abstract Base Class 이다.
 *
 * @modification : 2020. 4. 10.(수정자) 최초생성
 *
 * @author hirob
 * @Date 2020. 4. 10.
 * @version 1.0
 * @see
 *  == 개정이력(Modification Information) ==
 *
 *   수정일                     수정자                  수정내용
 *  -------    --------    ---------------------------
 *  
 * Copyright (C) by KFI All right reserved.
 * (C) by KFI All right reserved.
 */
public abstract class AbstractRuntimeException extends RuntimeException {
    private static final long serialVersionUID = 1L;

    protected String messageId;
    protected Object[] messageArgs;
    protected Locale locale;
    protected MessageSource messageSource;

    protected AbstractRuntimeException() {
        super();
        this.messageId = null;
        this.messageArgs = null;
        this.locale = null;
        this.messageSource = null;
    }

    protected AbstractRuntimeException(String messageId) {
        super();
        this.messageId = messageId;
        this.messageArgs = null;
        this.locale = MessageUtils.getLocale();
        this.messageSource = MessageUtils.getMessageSource();
    }

    protected AbstractRuntimeException(String messageId, Locale locale) {
        super();
        this.messageId = messageId;
        this.messageArgs = null;
        this.locale = locale;
        this.messageSource = MessageUtils.getMessageSource();
    }

    protected AbstractRuntimeException(String messageId, Object[] messageArgs) {
        super();
        this.messageId = messageId;
        this.messageArgs = messageArgs;
        this.locale = MessageUtils.getLocale();
        this.messageSource = MessageUtils.getMessageSource();
    }

    protected AbstractRuntimeException(String messageId, Object[] messageArgs, Locale locale) {
        super();
        this.messageId = messageId;
        this.messageArgs = messageArgs;
        this.locale = locale;
        this.messageSource = MessageUtils.getMessageSource();
    }

    protected AbstractRuntimeException(Throwable cause) {
        super(cause);
        this.messageId = null;
        this.messageArgs = null;
        this.locale = MessageUtils.getLocale();
        this.messageSource = MessageUtils.getMessageSource();
    }

    protected AbstractRuntimeException(String messageId, Throwable cause) {
        super(cause);
        this.messageId = messageId;
        this.messageArgs = null;
        this.locale = MessageUtils.getLocale();
        this.messageSource = MessageUtils.getMessageSource();
    }

    protected AbstractRuntimeException(String messageId, Locale locale, Throwable cause) {
        super(cause);
        this.messageId = messageId;
        this.messageArgs = null;
        this.locale = locale;
        this.messageSource = MessageUtils.getMessageSource();
    }

    protected AbstractRuntimeException(String messageId, Object[] messageArgs, Throwable cause) {
        super(cause);
        this.messageId = messageId;
        this.messageArgs = messageArgs;
        this.locale = MessageUtils.getLocale();
        this.messageSource = MessageUtils.getMessageSource();
    }

    protected AbstractRuntimeException(String messageId, Object[] messageArgs, Locale locale, Throwable cause) {
        super(cause);
        this.messageId = messageId;
        this.messageArgs = messageArgs;
        this.locale = locale;
        this.messageSource = MessageUtils.getMessageSource();
    }

    /**
     * 로케일을 설정합니다.
     *
     * @param locale
     *            국가/언어지정
     */
    public void setLocale(Locale locale) {
        this.locale = locale;
    }

    public Locale getLocale() {
        return this.locale;
    }

    public String getMessageId() {
        return this.messageId;
    }

    public Object[] getMessageArgs() {
        return this.messageArgs;
    }

    @Override
    public String getMessage() {
        if (messageSource == null) {
            throw new CoreException("Please override getMessageSource to return MessageSource.");
        }
        return messageSource.getMessage(messageId, messageArgs, locale);
    }
}
