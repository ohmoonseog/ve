/*
 *  ====================================================================
 *    Licensed to the Apache Software Foundation (ASF) under one or more
 *    contributor license agreements.  See the NOTICE file distributed with
 *    this work for additional information regarding copyright ownership.
 *    The ASF licenses this file to You under the Apache License, Version 2.0
 *    (the "License"); you may not use this file except in compliance with
 *    the License.  You may obtain a copy of the License at
 *
 *        http://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 * ====================================================================
 */

package kfi.core.util.BigExcel;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.Writer;
import java.util.Iterator;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FormulaError;
import org.apache.poi.ss.util.CellReference;
import kfi.core.exception.CoreException;
import lombok.extern.slf4j.Slf4j;

/**
 * Initially copied from BigGridDemo "SpreadsheetWriter".
 * Unlike the original code which wrote the entire document,
 * this class only writes the "sheetData" document fragment
 * so that it was renamed to "SheetDataWriter"
 */
@Slf4j
public class SheetDataWriter2 {
    private final File pfFile;
    private final Writer pfWriter;
    private int rownum;

    boolean rowContainedNullCells;
    int numberOfFlushedRows;
    int lowestIndexOfFlushedRows; // meaningful only of numberOfFlushedRows>0
    int numberOfCellsOfLastFlushedRow; // meaningful only of numberOfFlushedRows>0

    public SheetDataWriter2() throws IOException {
        pfFile = createTempFile();
        pfWriter = createWriter(pfFile);
    }

    /**
     * Create a temp file to write sheet data.
     * By default, temp files are created in the default temporary-file directory
     * with a prefix "poi-sxssf-sheet" and suffix ".xml".  Subclasses can override
     * it and specify a different temp directory or filename or suffix, e.g. <code>.gz</code>
     *
     * @return temp file to write sheet data
     */
    public File createTempFile()throws IOException {
        File fd = File.createTempFile("poi-sxssf-sheet", ".xml");
        return fd;
    }

    /**
     * Create a writer for the sheet data.
     *
     * @param  fd the file to write to
     * @throws IOException
     */
	public Writer createWriter(File fd) throws IOException {
    	BufferedWriter bufferedWriter = null;
    	FileWriter fileWriter = null;

    	if (fd.exists())
    	{
			fileWriter = new FileWriter(fd);
			bufferedWriter = new BufferedWriter(fileWriter);
    	}
        return bufferedWriter;
    }

    /**
     * flush and close the temp data writer.
     * This method <em>must</em> be invoked before calling {@link #getWorksheetXMLInputStream()}
     */
    public void close() throws IOException{
        pfWriter.flush();
        pfWriter.close();
    }

    File getTempFile(){
        return pfFile;
    }

    /**
     * @return a stream to read temp file with the sheet data
     */
    public InputStream getWorksheetXMLInputStream() throws IOException {
        File fd = getTempFile();
        return new FileInputStream(fd);
    }

    public int getNumberOfFlushedRows() {
        return numberOfFlushedRows;
    }

    public int getNumberOfCellsOfLastFlushedRow() {
        return numberOfCellsOfLastFlushedRow;
    }

    public int getLowestIndexOfFlushedRows() {
        return lowestIndexOfFlushedRows;
    }

    protected void finalize() throws Throwable {
        pfFile.delete();
    }

    /**
     * Write a row to the file
     *
     * @param rownum 0-based row number
     * @param row    a row
     */
    public void writeRow(int rownum, SXSSFRow2 row) throws IOException {
        if (numberOfFlushedRows == 0)
            lowestIndexOfFlushedRows = rownum;
        numberOfCellsOfLastFlushedRow = row.getLastCellNum();
        numberOfFlushedRows++;
        beginRow(rownum, row);
        Iterator<Cell> cells = row.allCellsIterator();
        int columnIndex = 0;
        while (cells.hasNext()) {
            writeCell(columnIndex++, cells.next());
        }
        endRow();
    }

    void beginRow(int rownum, SXSSFRow2 row) throws IOException {
        pfWriter.write("<row r=\"" + (rownum + 1) + "\"");
        if (row.hasCustomHeight())
            pfWriter.write(" customHeight=\"true\"  ht=\"" + row.getHeightInPoints() + "\"");
        if (row.getZeroHeight())
            pfWriter.write(" hidden=\"true\"");
        if (row.isFormatted()) {
            pfWriter.write(" s=\"" + row.shortStyle + "\"");
            pfWriter.write(" customFormat=\"1\"");
        }
        if (row.getOutlineLevel() != 0) {
            pfWriter.write(" outlineLevel=\"" + row.getOutlineLevel() + "\"");
        }
        pfWriter.write(">\n");
        this.rownum = rownum;
        rowContainedNullCells = false;
    }

    void endRow() throws IOException {
        pfWriter.write("</row>\n");
    }

    public void writeCell(int columnIndex, Cell cell) throws IOException {
        if (cell == null) {
            rowContainedNullCells = true;
            return;
        }
        String ref = new CellReference(rownum, columnIndex).formatAsString();
        pfWriter.write("<c r=\"" + ref + "\"");
        CellStyle cellStyle = cell.getCellStyle();
        if (cellStyle.getIndex() != 0) pfWriter.write(" s=\"" + cellStyle.getIndex() + "\"");
        int cellType = cell.getCellType();
        switch (cellType) {
            case Cell.CELL_TYPE_BLANK: {
                pfWriter.write(">");
                break;
            }
            case Cell.CELL_TYPE_FORMULA: {
                pfWriter.write(">");
                pfWriter.write("<f>");
                outputQuotedString(cell.getCellFormula());
                pfWriter.write("</f>");
                switch (cell.getCachedFormulaResultType()) {
                    case Cell.CELL_TYPE_NUMERIC:
                        double nval = cell.getNumericCellValue();
                        if (!Double.isNaN(nval)) {
                            pfWriter.write("<v>" + nval + "</v>");
                        }
                        break;
                    default : break;
                }
            }
            case Cell.CELL_TYPE_STRING: {
                pfWriter.write(" t=\"inlineStr\">");
                pfWriter.write("<is><t");
                if(hasLeadingTrailingSpaces(cell.getStringCellValue())) {
                    pfWriter.write(" xml:space=\"preserve\"");
                }
                pfWriter.write(">");
                outputQuotedString(cell.getStringCellValue());
                pfWriter.write("</t></is>");
                break;
            }
            case Cell.CELL_TYPE_NUMERIC: {
                pfWriter.write(" t=\"n\">");
                pfWriter.write("<v>" + cell.getNumericCellValue() + "</v>");
                break;
            }
            case Cell.CELL_TYPE_BOOLEAN: {
                pfWriter.write(" t=\"b\">");
                pfWriter.write("<v>" + (cell.getBooleanCellValue() ? "1" : "0") + "</v>");
                break;
            }
            case Cell.CELL_TYPE_ERROR: {
                FormulaError error = FormulaError.forInt(cell.getErrorCellValue());

                pfWriter.write(" t=\"e\">");
                pfWriter.write("<v>" + error.getString() + "</v>");
                break;
            }
            default: {
                throw new CoreException("Huh?");
            }
        }
        pfWriter.write("</c>");
    }


    /**
     * @return  whether the string has leading / trailing spaces that
     *  need to be preserved with the xml:space=\"preserve\" attribute
     */
    boolean hasLeadingTrailingSpaces(String str) {
        if (str != null && str.length() > 0) {
            char firstChar = str.charAt(0);
            char lastChar  = str.charAt(str.length() - 1);
            return Character.isWhitespace(firstChar) || Character.isWhitespace(lastChar) ;
        }
        return false;
    }

    //Taken from jdk1.3/src/javax/swing/text/html/HTMLWriter.java
    protected void outputQuotedString(String s) throws IOException {
        if (s == null || s.length() == 0) {
            return;
        }

        char[] chars = s.toCharArray();
        int last = 0;
        int length = s.length();
        for (int counter = 0; counter < length; counter++) {
            char c = chars[counter];
            switch (c) {
                case '<':
                    if (counter > last) {
                        pfWriter.write(chars, last, counter - last);
                    }
                    last = counter + 1;
                    pfWriter.write("&lt;");
                    break;
                case '>':
                    if (counter > last) {
                        pfWriter.write(chars, last, counter - last);
                    }
                    last = counter + 1;
                    pfWriter.write("&gt;");
                    break;
                case '&':
                    if (counter > last) {
                        pfWriter.write(chars, last, counter - last);
                    }
                    last = counter + 1;
                    pfWriter.write("&amp;");
                    break;
                case '"':
                    if (counter > last) {
                        pfWriter.write(chars, last, counter - last);
                    }
                    last = counter + 1;
                    pfWriter.write("&quot;");
                    break;
                // Special characters
                case '\n':
                case '\r':
                    if (counter > last) {
                        pfWriter.write(chars, last, counter - last);
                    }
                    pfWriter.write("&#xa;");
                    last = counter + 1;
                    break;
                case '\t':
                    if (counter > last) {
                        pfWriter.write(chars, last, counter - last);
                    }
                    pfWriter.write("&#x9;");
                    last = counter + 1;
                    break;
                case 0xa0:
                    if (counter > last) {
                        pfWriter.write(chars, last, counter - last);
                    }
                    pfWriter.write("&#xa0;");
                    last = counter + 1;
                    break;
                default:
                    // YK: XmlBeans silently replaces all ISO control characters ( < 32) with question marks.
                    // the same rule applies to unicode surrogates and "not a character" symbols.
                    if( c < ' ' || Character.isLowSurrogate(c) || Character.isHighSurrogate(c) ||
                            ('\uFFFE' <= c && c <= '\uFFFF')) {
                        if (counter > last) {
                            pfWriter.write(chars, last, counter - last);
                        }
                        pfWriter.write('?');
                        last = counter + 1;
                    }
                    else if (c > 127) {
                        if (counter > last) {
                            pfWriter.write(chars, last, counter - last);
                        }
                        last = counter + 1;
                        // If the character is outside of ascii, write the
                        // numeric value.
                        pfWriter.write("&#");
                        pfWriter.write(String.valueOf((int) c));
                        pfWriter.write(";");
                    }
                    break;
            }
        }
        if (last < length) {
            pfWriter.write(chars, last, length - last);
        }
    }

    /**
     * Deletes the temporary file that backed this sheet on disk.
     * @return true if the file was deleted, false if it wasn't.
     */
    boolean dispose() {
        try {
            return pfFile.delete();
        }finally {
            try {
                pfWriter.close();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                log.debug(e.getMessage());
            }
        }
    }
}
