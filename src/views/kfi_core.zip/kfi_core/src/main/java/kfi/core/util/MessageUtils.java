package kfi.core.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.context.support.AbstractMessageSource;
import org.springframework.context.support.MessageSourceSupport;
import org.springframework.stereotype.Component;
import kfi.core.service.PropertyService;
import kfi.core.support.CustomMessageSource;

/**
 *
 * @className : MessageUtils
 * @description : .properties 등록된 메시지처리 Utility Class 이다.
 *
 *
 *
 * @modification : 2018. 8. 1.(수정자) 최초생성
 *
 * @author AA lee
 * @Date 2018. 8. 1.
 * @version 1.0
 * @see
 *  == 개정이력(Modification Information) ==
 *
 *   수정일      수정자           수정내용
 *  -------    --------    ---------------------------
 *
 * Copyright (C) by AIRA All right reserved.
 */
@Component
public class MessageUtils {

	@Resource(name = "messageSource")
	private MessageSourceSupport source;

	static MessageSourceSupport messageSource;
	static PropertyService propertyService2;

	@Resource
	PropertyService propertyService;


	@PostConstruct
	public void initialize() {
		messageSource = source;
		propertyService2 = propertyService;

	}

	public static AbstractMessageSource getMessageSource() {
		return (AbstractMessageSource) messageSource;
	}

	public static PropertyService getPropertyService() {
		return propertyService2;
	}

	public void setSource(MessageSourceSupport source) {
		this.source = source;
	}

	public static Locale getLocale() {
		return LocaleContextHolder.getLocale();
	}

	public static String getMessage(String code) {
		return getMessageSource().getMessage(code, null, getLocale());
	}

	public static String getMessage(String code, Object[] args) {
		return getMessageSource().getMessage(code, args, getLocale());
	}
	public static Map<String, String> getListAllMsg() {
		CustomMessageSource customMessageSource = new CustomMessageSource();
		return customMessageSource.listAllMsg(getPropertyService(), getLocale());
	}
	
    public static List<Map<String, String>> getListAllMsgList() {
        CustomMessageSource customMessageSource = new CustomMessageSource();
        Map<String, String> resultMap = customMessageSource.listAllMsg(getPropertyService(), getLocale());
        List<Map<String, String>> returnList = new ArrayList<Map<String, String>>();
        
        Map<String, String> msgMap = null;
        for (String mapkey : resultMap.keySet()){
            msgMap = new HashMap<String, String>();
            msgMap.put("msgId", mapkey);
            msgMap.put("msgNm", resultMap.get(mapkey));
            returnList.add(msgMap);
        }
        
        return returnList;
    }

	public static Map<String, String> getListAllMsg(Locale locale) {
        CustomMessageSource customMessageSource = new CustomMessageSource();
        return customMessageSource.listAllMsg(getPropertyService(), locale);
    }
}