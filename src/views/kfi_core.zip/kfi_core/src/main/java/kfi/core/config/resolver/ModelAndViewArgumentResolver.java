/*
 * Copyright 2014 MOSPA(Ministry of Security and Public Administration).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package kfi.core.config.resolver;

import javax.servlet.http.HttpServletRequest;
import org.springframework.core.MethodParameter;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.support.WebDataBinderFactory;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.method.support.ModelAndViewContainer;
import org.springframework.web.servlet.ModelAndView;
import kfi.core.constants.Constants;


/**
 *
 * @className : ModelAndViewArgumentResolver
 * @description : ModelAndView가 선언된 Argument ViewName을 설정하기 위한 resolver class 이다.
 *
 * @modification : 2020. 4. 7.(수정자) 최초생성
 *
 * @author hirob
 * @Date 2020. 4. 7.
 * @version 1.0
 * @see ModelAndView
 *  == 개정이력(Modification Information) ==
 *
 *   수정일                     수정자                  수정내용
 *  -------    --------    ---------------------------
 *  
 * Copyright (C) by KFI All right reserved.
 * (C) by KFI All right reserved.
 */
@Component
public class ModelAndViewArgumentResolver implements HandlerMethodArgumentResolver {

    /* (non-Javadoc)
     * @see org.springframework.web.method.support.HandlerMethodArgumentResolver#supportsParameter(org.springframework.core.MethodParameter)
     */
    @Override
    public boolean supportsParameter(MethodParameter parameter) {
        return ModelAndView.class.isAssignableFrom(parameter.getParameterType());
    }

    /* (non-Javadoc)
     * @see org.springframework.web.method.support.HandlerMethodArgumentResolver#resolveArgument(org.springframework.core.MethodParameter, org.springframework.web.method.support.ModelAndViewContainer, org.springframework.web.context.request.NativeWebRequest, org.springframework.web.bind.support.WebDataBinderFactory)
     */
    @Override
    public Object resolveArgument(MethodParameter parameter, ModelAndViewContainer mavContainer, NativeWebRequest webRequest, WebDataBinderFactory binderFactory) throws Exception {
        ModelAndView model = new ModelAndView();
        HttpServletRequest request = (HttpServletRequest) webRequest.getNativeRequest();
        String headerSvcType = request.getHeader("headerSvcType");
        String nexacroFileType = request.getParameter("nexacroFileType");
        if (headerSvcType !=null && headerSvcType.equals("nexacro") || nexacroFileType != null) {
            model.setViewName(Constants.NEXACRO_VIEW);
        } else {
            model.setViewName(Constants.JSON_VIEW);
        }
        return model;
    }

}
