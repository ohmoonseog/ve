package kfi.core.util;

import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import lombok.extern.slf4j.Slf4j;
import kfi.core.constants.Constants;
import kfi.core.vo.UserSessionVO;


/**
 *
 * @className : ObjectUtil
 * @description : Object conver 지원하는 Utility Class 이다.
 *
 * @modification : 2018. 8. 1.(수정자) 최초생성
 *
 * @author AA lee
 * @Date 2018. 8. 1.
 * @version 1.0
 * @see
 *  == 개정이력(Modification Information) ==
 *
 *   수정일      수정자           수정내용
 *  -------    --------    ---------------------------
 *
 * Copyright (C) by AIRA All right reserved.
 */
@Slf4j
public class ObjectUtil {

    public static Map<String, Object> convertObjectToMap(Object obj) {
        Map<String, Object> map = new HashMap<String, Object>();
        Field[] fields = obj.getClass().getDeclaredFields();
        for (int i = 0; i < fields.length; i++) {
            fields[i].setAccessible(true);
            try {
                map.put(fields[i].getName(), fields[i].get(obj));
            } catch (IllegalArgumentException | IllegalAccessException e) {
                // TODO Auto-generated catch block
                log.error(e.getMessage());
            }
        }
        return map;
    }


    public static Object convertMapToObject(Map<?, ?> map, Object obj) {
        String keyAttribute = null;

        String setMethodString = "set";
        String methodString = null;
        Iterator<?> itr = map.keySet().iterator();
        while (itr.hasNext()) {
            keyAttribute = (String) itr.next();
            methodString = setMethodString + keyAttribute.substring(0, 1).toUpperCase() + keyAttribute.substring(1);
            Method[] methods = obj.getClass().getDeclaredMethods();
            for (int i = 0; i < methods.length; i++) {
                if (methodString.equals(methods[i].getName())) {
                    try {
                        methods[i].invoke(obj, map.get(keyAttribute));
                    } catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
                        // TODO Auto-generated catch block
                        log.error(e.getMessage());
                    }
                }
            }
        }
        return obj;
    }

    @SuppressWarnings("unchecked")
    public static Object convertListMapToListObject(Object object, Type[] types) {

        try {
            ServletRequestAttributes sra = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
            HttpServletRequest servletRequest = sra.getRequest();
            HttpSession session = (HttpSession) servletRequest.getSession();
            UserSessionVO userSessionVO = (UserSessionVO) session.getAttribute(Constants.USER_SESSION);
            String sessUserId =  null;
            String sessCmpyId =  null;
            
            if(userSessionVO != null){
                sessUserId = userSessionVO.getUserId();
                sessCmpyId = userSessionVO.getCmpyId();
            }
            String type = null;
            if (types.length > 0) {
                Class<?> cls = (Class<?>) types[0];
                if (cls.isAssignableFrom(String.class) || cls.isAssignableFrom(Integer.class) || cls.isAssignableFrom(Double.class) || cls.isAssignableFrom(float.class) || cls.isAssignableFrom(long.class)) {
                    return object;
                } else if (cls.isAssignableFrom(Map.class)) {
                    List<Object> objectResult = new ArrayList<Object>();
                    List<Map<String, Object>> objectList = (List<Map<String, Object>>) object;
                    for (int i = 0; i < objectList.size(); i++) {
                        Map<String, Object> objectMap = (Map<String, Object>) objectList.get(i);
                        String keyRowType = (String) objectMap.get(Constants.KEY_ROW_TYPE) == null ? "" : (String) objectMap.get(Constants.KEY_ROW_TYPE);
                        if (keyRowType.equals("E")) {
                            objectMap.put(Constants.KEY_ROW_TYPE, "D");
                        }
                        //session 값 add
                        if(sessUserId != null) {
                            objectMap.put("sessUserId", sessUserId);
                        }
                        //session 값 add
                        if(sessCmpyId != null) {
                            objectMap.put("sessCmpyId", sessCmpyId);
                        }
                        objectMap.put("sessIpAdr", ReqestUtil.getUserIP());

                        objectResult.add(objectMap);
                    }
                    return objectResult;
                } else {
                    type = types[0].getTypeName();
                }
            }
            Class<?> cls = Class.forName(type);
            List<Object> objectResult = new ArrayList<Object>();
            List<Map<String, Object>> objectList = (List<Map<String, Object>>) object;
            for (int i = 0; i < objectList.size(); i++) {
                Map<String, Object> objectMap = (Map<String, Object>) objectList.get(i);
                Object newCls;
                newCls = cls.newInstance();
                newCls = ObjectUtil.convertMapToObject(objectMap, newCls);
                objectResult.add(newCls);
            }
            return objectResult;
        } catch (ClassNotFoundException e) {
            return object;
        } catch (InstantiationException | IllegalAccessException e) {
            return object;
        }
    }

    @SuppressWarnings("unchecked")
    public static Object convertMapToObject(Map<String, Object> paramMap, Type[] types) {
        ServletRequestAttributes sra = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
        HttpServletRequest servletRequest = sra.getRequest();
        HttpSession session = (HttpSession) servletRequest.getSession();
        UserSessionVO userSessionVO = (UserSessionVO) session.getAttribute(Constants.USER_SESSION);
        String sessUserId =  null;
        String sessCmpyId =  null;
        
        if(userSessionVO != null){
            sessUserId = userSessionVO.getUserId();
            sessCmpyId = userSessionVO.getCmpyId();
        }
        try {
            for (String key : paramMap.keySet()) {

                if (types.length > 0) {
                    if (paramMap.get(key) instanceof List) {
                        List<Object> objectResult = new ArrayList<Object>();
                        List<Map<String, Object>> objectList = (List<Map<String, Object>>) paramMap.get(key);
                        for (int i = 0; i < objectList.size(); i++) {
                            Map<String, Object> objectMap = (Map<String, Object>) objectList.get(i);
                            Map<String, Object> converMap = new HashMap<String, Object>();
                            for (String mapKey : objectMap.keySet()) {
                                if (objectMap.get(mapKey) != null) {
                                    Class<?> cls = (Class<?>) objectMap.get(mapKey).getClass();
                                    if (cls.isAssignableFrom(String.class) || cls.isAssignableFrom(Integer.class) || cls.isAssignableFrom(Double.class) || cls.isAssignableFrom(float.class) || cls.isAssignableFrom(long.class)) {
                                        converMap.put(mapKey, objectMap.get(mapKey) + "");
                                    } else {
                                        converMap.put(mapKey, objectMap.get(mapKey));
                                    }
                                } else {
                                    converMap.put(mapKey, objectMap.get(mapKey));
                                }
                            }

                            String keyRowType = (String) objectMap.get(Constants.KEY_ROW_TYPE) == null ? "" : (String) objectMap.get(Constants.KEY_ROW_TYPE);
                            if (keyRowType.equals("E")) {
                                converMap.put(Constants.KEY_ROW_TYPE, "D");
                            }
                            //session 값 add
                            if(sessUserId != null) {
                                converMap.put("sessUserId", sessUserId);
                            }
                            //session 값 add
                            if(sessCmpyId != null) {
                                converMap.put("sessCmpyId", sessCmpyId);
                            }
                            converMap.put("sessIpAdr", ReqestUtil.getUserIP());
                            objectResult.add(converMap);
                        }
                        paramMap.put(key, objectResult);
                    } else if (paramMap.get(key) instanceof Map) {
                        Map<String, Object> objectMap = (Map<String, Object>) paramMap.get(key);
                        Map<String, Object> converMap = new HashMap<String, Object>();
                        for (String mapKey : objectMap.keySet()) {
                            if (objectMap.get(mapKey) != null) {
                                Class<?> cls = (Class<?>) objectMap.get(mapKey).getClass();
                                if (cls.isAssignableFrom(String.class) || cls.isAssignableFrom(Integer.class) || cls.isAssignableFrom(Double.class) || cls.isAssignableFrom(float.class) || cls.isAssignableFrom(long.class)) {
                                    converMap.put(mapKey, objectMap.get(mapKey) + "");
                                } else {
                                    converMap.put(mapKey, objectMap.get(mapKey));
                                }
                            } else {
                                converMap.put(mapKey, objectMap.get(mapKey));
                            }
                        }
                        //session 값 add
                        if(sessUserId != null) {
                            converMap.put("sessUserId", sessUserId);
                        }
                        //session 값 add
                        if(sessCmpyId != null) {
                            converMap.put("sessCmpyId", sessCmpyId);
                        }
                        converMap.put("sessIpAdr", ReqestUtil.getUserIP());
                        
                        paramMap.put(key, converMap);
                        // type = types[0].getTypeName();
                    }
                }
            }

        } catch (ClassCastException e) {
            return paramMap;
        }
        return paramMap;
    }

    /**
      * Object type 변수가 비어있는지 체크
      * 
      * @param obj 
      * @return Boolean : true / false
      */
    @SuppressWarnings("rawtypes")
    public static Boolean empty(Object obj) {
        if (obj instanceof String)
            return obj == null || obj.equals("undefined") || "".equals(obj.toString().trim());
        else if (obj instanceof List)
            return obj == null || ((List) obj).isEmpty();
        else if (obj instanceof Map)
            return obj == null || ((Map) obj).isEmpty();
        else if (obj instanceof Object[])
            return obj == null || Array.getLength(obj) == 0;
        else
            return obj == null;
    }

    /**
     * Object type 변수가 비어있지 않은지 체크
     * 
     * @param obj
     * @return Boolean : true / false
     */
    public static Boolean notEmpty(Object obj) {
        return !empty(obj);
    }
}
