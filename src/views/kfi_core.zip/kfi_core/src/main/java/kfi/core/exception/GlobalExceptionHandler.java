package kfi.core.exception;

import java.util.Locale;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;
import kfi.core.constants.Constants;
import kfi.core.service.PropertyService;
import kfi.core.util.MessageUtils;
import lombok.extern.slf4j.Slf4j;


/**
 *
 * @className : GlobalExceptionHandler
 * @description : global exception handler class 이다.
 *
 * @modification : 2020. 4. 10.(수정자) 최초생성
 *
 * @author hirob
 * @Date 2020. 4. 10.
 * @version 1.0
 * @see
 *  == 개정이력(Modification Information) ==
 *
 *   수정일                     수정자                  수정내용
 *  -------    --------    ---------------------------
 *  
 * Copyright (C) by KFI All right reserved.
 * (C) by KFI All right reserved.
 */
@ControllerAdvice
@Slf4j
public class GlobalExceptionHandler {

    @Autowired
    PropertyService propertyService;
    
    /**
     * AbstractRuntimeException handling 한다.
     * @param request
     * @param response
     * @param are
     * @return
     */
    @ExceptionHandler(AbstractRuntimeException.class)
    //@ResponseStatus (HttpStatus.OK)
    public ModelAndView handleCustomException(HttpServletRequest request,
                                            HttpServletResponse response,
                                            AbstractRuntimeException are) {
        log.error("handleLdfsException", are);
        Locale locale = MessageUtils.getLocale();
        String contentType = request.getHeader("Content-Type");
        String url = request.getRequestURI();
        ModelAndView model=null;
        String reason= HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase();
        int statusCode= HttpStatus.INTERNAL_SERVER_ERROR.value();
        // Content-Type 확인, json 만 View를 따로 처리함.
        String headerSvcType = request.getHeader("headerSvcType");
        String nexacroFileType = request.getParameter("nexacroFileType");
        if (headerSvcType !=null && headerSvcType.equals("nexacro") || nexacroFileType != null) {
        	model = new ModelAndView("nexacroView");
            model.addObject(Constants.ERROR_CODE,-1);
            //넥사크로 인경우 정상 코드 전송
            statusCode = HttpStatus.OK.value();
        }else if(contentType!= null && contentType.indexOf("json") != -1){
            model = new ModelAndView("jsonView");
            model.addObject(Constants.ERROR_CODE,-1);
        } else {
        	model = new ModelAndView("error/error");
            model.addObject("statusCode",statusCode);
        }
        model.addObject("reason",reason);
        model.addObject(Constants.ERROR_MSG,are.getMessage());
        model.addObject("locale",locale.getLanguage());
        model.addObject("path",url);

        response.setStatus(statusCode);

        return model;
    }

    
    /**
     * All Exception handling 한다.
     * @param request
     * @param response
     * @param e
     * @return
     */
    @ExceptionHandler(Exception.class)
    //@ResponseStatus (HttpStatus.INTERNAL_SERVER_ERROR)
    public ModelAndView handleUnknownException(HttpServletRequest request,
                                               HttpServletResponse response,
                                               Throwable e) {
        log.error("handleUnknownException", e);
        //return ResultHelper.failureResult(e.getMessage());

        Locale locale = MessageUtils.getLocale();
        String contentType = request.getHeader("Content-Type");
        String url = request.getRequestURI();
        String message;
        ModelAndView model=null;
        String reason= HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase();
        int statusCode= HttpStatus.INTERNAL_SERVER_ERROR.value();

        // Content-Type 확인, json 만 View를 따로 처리함.
        String headerSvcType = request.getHeader("headerSvcType");
        String nexacroFileType = request.getParameter("nexacroFileType");
        if (headerSvcType !=null && headerSvcType.equals("nexacro") || nexacroFileType != null) {
            model = new ModelAndView("nexacroView");
            //넥사크로 인경우 정상 코드 전송
            statusCode = HttpStatus.OK.value();
        }else if(contentType!= null && contentType.indexOf("json") != -1){
            model = new ModelAndView("jsonView");
        } else {
            //json 이 아닐경우 error page 로 이동
            model = new ModelAndView("error/error");
            model.addObject("statusCode",statusCode);
        }
        if(url.indexOf("select") > -1) {
            message = "error.common.select";
        }else if(url.indexOf("insert") > -1) {
            message = "error.common.insert";
        }else if(url.indexOf("save") > -1) {
            message = "error.common.save";
        }else if(url.indexOf("update") > -1) {
            message = "error.common.update";
        }else if(url.indexOf("delete") > -1) {
            message = "error.common.delete";
        }else if(url.indexOf("multi") > -1) {
            message = "error.common.multi";
        }else {
        	message = "error.common.error";
        }
        model.addObject("reason",reason);
        //사이버인 경우 문구 추가
        if(propertyService.getString("sysCd").equals("CY")) {
            model.addObject(Constants.ERROR_MSG,MessageUtils.getMessage(message)+"\n시스템 관리자에게 문의주세요.\n(070–4128–1505,1506,,1510)");
        }else {
            model.addObject(Constants.ERROR_MSG,MessageUtils.getMessage(message));
        }
        model.addObject(Constants.ERROR_CODE,-1);
        model.addObject("locale",locale.getLanguage());
        model.addObject("path",url);
        response.setStatus(statusCode);
        return model;
    }
}
