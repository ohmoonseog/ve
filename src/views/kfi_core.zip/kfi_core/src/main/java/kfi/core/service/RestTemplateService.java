package kfi.core.service;
import java.io.IOException;
import java.util.Arrays;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import kfi.core.constants.Constants;
import kfi.core.vo.RestTemplateVO;
import kfi.core.xss.HTMLCharacterEscapes;
import lombok.extern.slf4j.Slf4j;


/**
 *
 * @className : RestTemplateService
 * @description : Rest 통신을 제공하는  서비스 클레스 이다.
 *
 * @modification : 2018. 8. 1.(수정자) 최초생성
 *
 * @author AA lee
 * @Date 2018. 8. 1.
 * @version 1.0
 * @see
 *  == 개정이력(Modification Information) ==
 *
 *   수정일      수정자           수정내용
 *  -------    --------    ---------------------------
 *
 * Copyright (C) by AIRA All right reserved.
 */
@Slf4j
@Service
public class RestTemplateService {

	@Autowired
	RestTemplate restTemplate;

	@Autowired
	PropertyService propertyService;


	@SuppressWarnings("unchecked")
    public RestTemplateVO syncPostCall(String url, Map<String, ?> map){

        RestTemplateVO restTemplateVO = new RestTemplateVO();
		//RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON_UTF8));

		try {
        	ObjectMapper mapper = new ObjectMapper();
        	mapper.getFactory().setCharacterEscapes(new HTMLCharacterEscapes());
        	String requestJson = mapper.writeValueAsString(map);
        	HttpEntity<?> requestEntity = new HttpEntity<String>(requestJson,headers);
        	Map<String, Object> returnMap = restTemplate.postForObject(url, requestEntity, Map.class);
            if(returnMap.get(Constants.ERROR_CODE) !=  null) {
                restTemplateVO.setErrCd(Integer.parseInt(returnMap.get(Constants.ERROR_CODE).toString()));
            }
            if(returnMap.get(Constants.ERROR_MSG) != null) {
                restTemplateVO.setErrMsg((String) returnMap.get(Constants.ERROR_MSG));
            }
            restTemplateVO.setResturnObject(returnMap);
            returnMap.remove(Constants.ERROR_CODE);
            returnMap.remove(Constants.ERROR_MSG);
        }catch(HttpServerErrorException e) {
        	restTemplateVO.setErrCd(-1);
        	restTemplateVO.setErrMsg(e.getMessage());
        	log.error("RestTemplateUtil.syncPostCall : "+e.getMessage());
        }catch(HttpClientErrorException e) {
        	restTemplateVO.setErrCd(-1);
        	restTemplateVO.setErrMsg(e.getMessage());
        	log.error("RestTemplateUtil.syncPostCall : "+e.getMessage());
        } catch (JsonProcessingException e) {
        	restTemplateVO.setErrCd(-1);
        	restTemplateVO.setErrMsg(e.getMessage());
        	log.error("RestTemplateUtil.syncPostCall : "+e.getMessage());
		}catch (ResourceAccessException e) {
			restTemplateVO.setErrCd(-1);
        	restTemplateVO.setErrMsg(e.getMessage());
        	log.error("RestTemplateUtil.syncPostCall : "+e.getMessage());
		}
		return restTemplateVO;
    }
	
	@SuppressWarnings({ "rawtypes" })
    public RestTemplateVO syncPostEsbCall(String url, Map<String, ?> map){
	    String esbUrl = propertyService.getString("esb.url");
	    url = esbUrl + url;
        RestTemplateVO restTemplateVO = new RestTemplateVO();
        //RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON_UTF8));

        try {
            ObjectMapper mapper = new ObjectMapper();
            mapper.getFactory().setCharacterEscapes(new HTMLCharacterEscapes());
            String requestJson = mapper.writeValueAsString(map);
            HttpEntity<?> requestEntity = new HttpEntity<String>(requestJson,headers);

            //Map<String, Object> returnMap = restTemplate.postForObject(url, requestEntity, Map.class);
            String returnMap1 = restTemplate.postForObject(url, requestEntity, String.class);
            ObjectMapper objectMapper = new ObjectMapper();
            Map jsonMap = null;
            try {
                jsonMap = objectMapper.readValue(returnMap1, Map.class);
                if(jsonMap.containsKey("faultstring"))
                {
                    restTemplateVO.setErrCd(-1);
                    restTemplateVO.setErrMsg(jsonMap.get("detail").toString());
                    log.error("RestTemplateUtil.syncPostCall : "+jsonMap.get("detail").toString());
                }
            } catch (IOException e) {
                log.debug(e.getMessage());
            }
            //Map<String, Object> returnMap = new ObjectMapper().readValue(returnMap1, HashMap.class);
            restTemplateVO.setResturnObject(jsonMap);
        }catch(HttpServerErrorException e) {
            restTemplateVO.setErrCd(-1);
            restTemplateVO.setErrMsg(e.getMessage());
            log.error("RestTemplateUtil.syncPostCall : "+e.getMessage());
        }catch(HttpClientErrorException e) {
            restTemplateVO.setErrCd(-1);
            restTemplateVO.setErrMsg(e.getMessage());
            log.error("RestTemplateUtil.syncPostCall : "+e.getMessage());
        } catch (JsonProcessingException e) {
            restTemplateVO.setErrCd(-1);
            restTemplateVO.setErrMsg(e.getMessage());
            log.error("RestTemplateUtil.syncPostCall : "+e.getMessage());
        }catch (ResourceAccessException e) {
            restTemplateVO.setErrCd(-1);
            restTemplateVO.setErrMsg(e.getMessage());
            log.error("RestTemplateUtil.syncPostCall : "+e.getMessage());
        }
        return restTemplateVO;
    }

	@SuppressWarnings("unchecked")
    public RestTemplateVO syncPostCall(String url, String jsonParam){

        RestTemplateVO restTemplateVO = new RestTemplateVO();
        //RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON_UTF8));

        try {
            HttpEntity<?> requestEntity = new HttpEntity<String>(jsonParam,headers);
            Map<String, Object> returnMap = restTemplate.postForObject(url, requestEntity, Map.class);
            if(returnMap.get(Constants.ERROR_CODE) !=  null) {
                restTemplateVO.setErrCd(Integer.parseInt(returnMap.get(Constants.ERROR_CODE).toString()));
            }
            if(returnMap.get(Constants.ERROR_MSG) != null) {
                restTemplateVO.setErrMsg((String) returnMap.get(Constants.ERROR_MSG));
            }
            restTemplateVO.setResturnObject(returnMap);
            returnMap.remove(Constants.ERROR_CODE);
            returnMap.remove(Constants.ERROR_MSG);
        }catch(HttpServerErrorException e) {
            restTemplateVO.setErrCd(-1);
            restTemplateVO.setErrMsg(e.getMessage());
            log.error("RestTemplateUtil.syncPostCall : "+e.getMessage());
        }catch(HttpClientErrorException e) {
            restTemplateVO.setErrCd(-1);
            restTemplateVO.setErrMsg(e.getMessage());
            log.error("RestTemplateUtil.syncPostCall : "+e.getMessage());
        }catch (ResourceAccessException e) {
            restTemplateVO.setErrCd(-1);
            restTemplateVO.setErrMsg(e.getMessage());
            log.error("RestTemplateUtil.syncPostCall : "+e.getMessage());
        }
        return restTemplateVO;
    }
	
    public RestTemplateVO syncPostCallXml(String url, String xmlParam){

        RestTemplateVO restTemplateVO = new RestTemplateVO();
        //RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.TEXT_XML);
        headers.setAccept(Arrays.asList(MediaType.TEXT_XML));

        try {
            HttpEntity<?> requestEntity = new HttpEntity<String>(xmlParam,headers);
            String xmlStr = restTemplate.postForObject(url, requestEntity, String.class);
            restTemplateVO.setResturnObject(xmlStr);
        }catch(HttpServerErrorException e) {
            restTemplateVO.setErrCd(-1);
            restTemplateVO.setErrMsg(e.getMessage());
            log.error("RestTemplateUtil.syncPostCall : "+e.getMessage());
        }catch(HttpClientErrorException e) {
            restTemplateVO.setErrCd(-1);
            restTemplateVO.setErrMsg(e.getMessage());
            log.error("RestTemplateUtil.syncPostCall : "+e.getMessage());
        }catch (ResourceAccessException e) {
            restTemplateVO.setErrCd(-1);
            restTemplateVO.setErrMsg(e.getMessage());
            log.error("RestTemplateUtil.syncPostCall : "+e.getMessage());
        }
        return restTemplateVO;
    }
    
    @SuppressWarnings("unchecked")
    public RestTemplateVO syncPostCallForm(String url, Map<String, ?> map){

        RestTemplateVO restTemplateVO = new RestTemplateVO();
        //RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_FORM_URLENCODED));

        try {
            MultiValueMap<String, String> map2= new LinkedMultiValueMap<String, String>();
            for ( String key : map.keySet() ) {
                map2.add(key, (String) map.get(key));
            }

            HttpEntity<MultiValueMap<String, String>> requestEntity = new HttpEntity<MultiValueMap<String, String>>(map2, headers);
            
            //HttpEntity<?> requestEntity = new HttpEntity<Map<String,Object>>(map,headers);
            //HttpEntity<Map<String, Object>> requestEntity = new HttpEntity<Map<String, Object>>((Map<String, Object>) map, headers);
            Map<String, Object> returnMap = restTemplate.postForObject(url, requestEntity, Map.class);
            restTemplateVO.setResturnObject(returnMap);
        }catch(HttpServerErrorException e) {
            restTemplateVO.setErrCd(-1);
            restTemplateVO.setErrMsg(e.getMessage());
            log.error("RestTemplateUtil.syncPostCall : "+e.getMessage());
        }catch(HttpClientErrorException e) {
            restTemplateVO.setErrCd(-1);
            restTemplateVO.setErrMsg(e.getMessage());
            log.error("RestTemplateUtil.syncPostCall : "+e.getMessage());
        }catch (ResourceAccessException e) {
            restTemplateVO.setErrCd(-1);
            restTemplateVO.setErrMsg(e.getMessage());
            log.error("RestTemplateUtil.syncPostCall : "+e.getMessage());
        }
        return restTemplateVO;
    }
    
	@SuppressWarnings("unchecked")
    public RestTemplateVO syncGetCall(String url, Map<String, ?> map){

        RestTemplateVO restTemplateVO = new RestTemplateVO();
        //RestTemplate restTemplate = new RestTemplate();
        try {
            String strParam = "";
//            try {
                for ( String key : map.keySet() ) {
                    String val = (String) map.get(key) == null ? "": (String) map.get(key); 
                    strParam += key +"="+ val +"&";
                }
            
//            } catch (UnsupportedEncodingException e) {
//                // TODO Auto-generated catch block
//                log.debug(e.getMessage());
//            }
            Map<String, Object> returnMap = restTemplate.getForObject(url+"?"+strParam, Map.class);//(url, responseType, uriVariables)(url, requestEntity, Map.class);
            restTemplateVO.setResturnObject(returnMap);
            returnMap.remove(Constants.ERROR_CODE);
            returnMap.remove(Constants.ERROR_MSG);
        }catch(HttpServerErrorException e) {
            restTemplateVO.setErrCd(-1);
            restTemplateVO.setErrMsg(e.getMessage());
            log.error("RestTemplateUtil.syncPostCall : "+e.getMessage());
        }catch(HttpClientErrorException e) {
            restTemplateVO.setErrCd(-1);
            restTemplateVO.setErrMsg(e.getMessage());
            log.error("RestTemplateUtil.syncPostCall : "+e.getMessage());
        }catch (ResourceAccessException e) {
            restTemplateVO.setErrCd(-1);
            restTemplateVO.setErrMsg(e.getMessage());
            log.error("RestTemplateUtil.syncPostCall : "+e.getMessage());
        }
        return restTemplateVO;
    }
}
