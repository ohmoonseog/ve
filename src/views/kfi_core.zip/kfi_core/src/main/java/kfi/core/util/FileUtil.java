package kfi.core.util;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.BufferedInputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.multipart.MultipartFile;
import com.drew.imaging.ImageMetadataReader;
import com.drew.imaging.ImageProcessingException;
import com.drew.metadata.Directory;
import com.drew.metadata.Metadata;
import com.drew.metadata.MetadataException;
import com.drew.metadata.exif.ExifIFD0Directory;
import kfi.core.exception.BizException;
import kfi.core.vo.FileVO;
import lombok.extern.slf4j.Slf4j;

/**
 *
 * @className : ReqestUtil
 * @description : Request  Utility Class 이다.
 *
 * @modification : 2018. 8. 1.(수정자) 최초생성
 *
 * @author AA lee
 * @Date 2018. 8. 1.
 * @version 1.0
 * @see
 *  == 개정이력(Modification Information) ==
 *
 *   수정일      수정자           수정내용
 *  -------    --------    ---------------------------
 *
 * Copyright (C) by AIRA All right reserved.
 */
@Slf4j
public class FileUtil {


	public static  void downLoad(String filePath, String fileName)  {

		HttpServletRequest request = ((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getRequest();
		HttpServletResponse response = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getResponse();

		File file = new File(filePath);
	    if (file.exists()) {

	        //get the mimetype
	        String mimeType = URLConnection.guessContentTypeFromName(file.getName());
	        if (mimeType == null) {
	            //unknown mimetype so set the mimetype to application/octet-stream
	            mimeType = "application/octet-stream";
	        }

	        response.setContentType(mimeType);

	        /**
	         * In a regular HTTP response, the Content-Disposition response header is a
	         * header indicating if the content is expected to be displayed inline in the
	         * browser, that is, as a Web page or as part of a Web page, or as an
	         * attachment, that is downloaded and saved locally.
	         *
	         */

	        /**
	         * Here we have mentioned it to show inline
	         */
	        String header = request.getHeader("User-Agent");
	        if (header.contains("MSIE") || header.contains("Trident")) {
	            try {
                    fileName = URLEncoder.encode(fileName,"UTF-8").replaceAll("\\+", "%20");
                } catch (UnsupportedEncodingException e) {
                    // TODO Auto-generated catch block
                    log.debug(e.getMessage());
                }
	            response.setHeader("Content-Disposition", "attachment;filename=" + fileName + ";");
	        } else {
	            try {
                    fileName = URLEncoder.encode(fileName,"UTF-8").replaceAll("\\+", "%20");
                } catch (UnsupportedEncodingException e) {
                    // TODO Auto-generated catch block
                    log.debug(e.getMessage());
                }
	            response.setHeader("Content-Disposition", "attachment;filename=" + fileName + ";");
	        }
	        //response.setHeader("Content-Disposition", String.format("inline; filename=\"" + file.getName() + "\""));

	         //Here we have mentioned it to show as attachment
	         //response.setHeader("Content-Disposition", String.format("attachment; filename=\"" + file.getName() + "\""));

	        response.setContentLength((int) file.length());
	        InputStream inputStream  = null;
	        try {
	            try {
                    inputStream = new BufferedInputStream(new FileInputStream(file));
                } catch (FileNotFoundException e) {
                    // TODO Auto-generated catch block
                    log.debug(e.getMessage());
                }
	            try {
                    FileCopyUtils.copy(inputStream, response.getOutputStream());
                } catch (IOException e) {
                    // TODO Auto-generated catch block
                    log.debug(e.getMessage());
                }
	        }finally {
	            if(inputStream != null)
                    try {
                        inputStream.close();
                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        log.debug(e.getMessage());
                    }
            }

	    }else {
	        throw new BizException("fail.common.file");
	    }
	}
	public static  void downLoad(File file, String fileName) throws Exception {

		HttpServletRequest request = ((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getRequest();
		HttpServletResponse response = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getResponse();

	    if (file.exists()) {

	        //get the mimetype
	        String mimeType = URLConnection.guessContentTypeFromName(file.getName());
	        if (mimeType == null) {
	            //unknown mimetype so set the mimetype to application/octet-stream
	            mimeType = "application/octet-stream";
	        }

	        response.setContentType(mimeType);

	        /**
	         * In a regular HTTP response, the Content-Disposition response header is a
	         * header indicating if the content is expected to be displayed inline in the
	         * browser, that is, as a Web page or as part of a Web page, or as an
	         * attachment, that is downloaded and saved locally.
	         *
	         */

	        /**
	         * Here we have mentioned it to show inline
	         */
	        String header = request.getHeader("User-Agent");
	        if (header.contains("MSIE") || header.contains("Trident")) {
	            fileName = URLEncoder.encode(fileName,"UTF-8").replaceAll("\\+", "%20");
	            response.setHeader("Content-Disposition", "attachment;filename=" + fileName + ";");
	        } else {
	            fileName = new String(fileName.getBytes("UTF-8"), "ISO-8859-1");
	           response.setHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");
	        }
	        //response.setHeader("Content-Disposition", String.format("inline; filename=\"" + file.getName() + "\""));

	         //Here we have mentioned it to show as attachment
	         //response.setHeader("Content-Disposition", String.format("attachment; filename=\"" + file.getName() + "\""));

	        response.setContentLength((int) file.length());
	        InputStream inputStream  = null;
            try {
                inputStream = new BufferedInputStream(new FileInputStream(file));
                FileCopyUtils.copy(inputStream, response.getOutputStream());
            }finally {
                if(inputStream != null) inputStream.close();
            }
	    }else {
            throw new BizException("fail.common.file");
        }
	}
	public static List<FileVO> upload(MultipartFile[] files,String fileBasePath){

		Calendar cal = Calendar.getInstance();
	    String dateString;
	    List<FileVO> fileList = new ArrayList<FileVO>();

	    dateString = String.format("%04d/%02d/%02d", cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH));
		if(files.length > 0){ //업로드할 파일이 없을 시
		   for (int i = 0; i < files.length; i++) {
			   FileVO fileVO = new FileVO();
			   MultipartFile file = files[i];
			   String fileName = file.getOriginalFilename();
			   long fileSize = file.getSize();
	           String fileNameExtension = FilenameUtils.getExtension(fileName).toLowerCase();
	           File destinationFile;
	           String destinationFileName;
	           String uploadPath = fileBasePath+dateString+"/";
	           //do {
               destinationFileName = RandomStringUtils.randomAlphanumeric(32) + "." + fileNameExtension;
               destinationFile = new File(uploadPath);
               if(!destinationFile.exists()) {
                   destinationFile.setExecutable(false,true);
                   destinationFile.setReadable(true);
                   destinationFile.setWritable(false,true);
                   destinationFile.mkdirs();
               }
               FileOutputStream fos = null;
               try {

                   //file.transferTo(new File(uploadPath+ destinationFileName));
                   byte[] data = file.getBytes();
                   fos = new FileOutputStream(uploadPath+ destinationFileName);
                   fos.write(data);
                   fileVO.setOriginalFileName(fileName);
                   fileVO.setFileSize(fileSize);
                   fileVO.setFilePath(uploadPath);
                   fileVO.setFileExt(fileNameExtension);
                   fileVO.setFileName(destinationFile.getName());


                } catch (IllegalStateException | IOException e) {
                    // TODO Auto-generated catch block
                    log.debug(e.getMessage());
                }finally {

                    if(fos != null)
                        try {
                            fos.close();
                        } catch (IOException e) {
                            // TODO Auto-generated catch block
                            log.debug(e.getMessage());
                        }
                }
		   }
		 }
		return fileList;
	}
	public static FileVO upload(MultipartFile file,String fileBasePath) {

	   Calendar cal = Calendar.getInstance();
	   String dateString;

	   dateString = String.format("%04d/%02d/%02d", cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH));
	   FileVO fileVO = new FileVO();
	   String fileName = file.getOriginalFilename();
	   long   fileSize = file.getSize();
       String fileNameExtension = FilenameUtils.getExtension(fileName).toLowerCase();
       File destinationFile;
       String destinationFileName;
       String uploadPath = fileBasePath+dateString+"/";
       destinationFileName = RandomStringUtils.randomAlphanumeric(32) + "." + fileNameExtension;
       destinationFile = new File(uploadPath);
       if(!destinationFile.exists()) {
           destinationFile.setExecutable(false,true);
           destinationFile.setReadable(true);
           destinationFile.setWritable(false,true);
           destinationFile.mkdirs();
       }
       FileOutputStream fos = null;
       try {

           //file.transferTo(new File(uploadPath+ destinationFileName));
           byte[] data = file.getBytes();
           fos = new FileOutputStream(uploadPath+ destinationFileName);
           fos.write(data);
           fileVO.setOriginalFileName(fileName);
           fileVO.setFileSize(fileSize);
           fileVO.setFilePath(uploadPath);
           fileVO.setFileExt(fileNameExtension);
           fileVO.setFileName(destinationFileName);


		} catch (IllegalStateException | IOException e) {
			// TODO Auto-generated catch block
			log.debug(e.getMessage());
		}finally {
		    if(fos != null)
                try {
                    fos.close();
                } catch (IOException e) {
                    // TODO Auto-generated catch block
                    log.debug(e.getMessage());
                }
        }
		return fileVO;
	}

	/**
     * 파일의 확장자를 체크하여 필터링된 확장자를 포함한 파일인 경우에 true를 리턴한다.
     * @param file
     * */
    public static boolean badFileExtIsReturnBoolean(String fileName) {
        String ext = fileName.substring(fileName.lastIndexOf(".") + 1,
               fileName.length());
        final String[] BAD_EXTENSION = { "jsp", "php", "asp", "html", "perl","js","sh" };

        int len = BAD_EXTENSION.length;
        for (int i = 0; i < len; i++) {
            if (ext.equalsIgnoreCase(BAD_EXTENSION[i])) {
                return true; // 불량 확장자가 존재할때..
            }
        }
        return false;
    }


	public static String reSizeImg(String imgOriginalPath,String addName,int height,int width){

	    String imgTargetPath = null;
	    FileInputStream fis = null;
        try{
            String sPathChar = java.io.File.separator;
            File input = new File(imgOriginalPath);
            fis = new FileInputStream(imgOriginalPath);
            Metadata metadata = null;
            try {
                metadata = ImageMetadataReader.readMetadata(fis);
            } catch (ImageProcessingException e) {
                // TODO Auto-generated catch block
                log.debug(e.getMessage());
            }

            Directory directory = metadata.getFirstDirectoryOfType(ExifIFD0Directory.class);
            int orientation = 1;
            if(directory != null) {
                try {
                    orientation = directory.getInt(ExifIFD0Directory.TAG_ORIENTATION);
                } catch (MetadataException e) {
                    // TODO Auto-generated catch block
                    log.debug(e.getMessage());
                }
            }
            imgOriginalPath =  input.getPath();
            String imgFormat = imgOriginalPath.substring(imgOriginalPath.lastIndexOf(".")+1);                             // 새 이미지 포맷. jpg, gif 등
            //imgTargetPath= imgOriginalPath.substring(0, imgOriginalPath.lastIndexOf(sPathChar))+sPathChar+addName +"_"+ imgOriginalPath.substring(imgOriginalPath.lastIndexOf(sPathChar)+1);    // 새 이미지 파일명
            imgTargetPath= imgOriginalPath.substring(0, imgOriginalPath.lastIndexOf(sPathChar))+sPathChar+imgOriginalPath.substring(imgOriginalPath.lastIndexOf(sPathChar)+1, imgOriginalPath.lastIndexOf("."))+"_"+addName+imgOriginalPath.substring(imgOriginalPath.lastIndexOf("."));    // 새 이미지 파일명
            //imgOriginalPath.substring(imgOriginalPath.lastIndexOf(sPathChar)+1, imgOriginalPath.lastIndexOf("."))+"_"+addName+imgOriginalPath.substring(imgOriginalPath.lastIndexOf("."))
            BufferedImage image = ImageIO.read(input);
            if(orientation == 6){ //정위치
                image = rotateImage(image, 90);
            } else if (orientation == 3){//오른쪽으로 눞였을때
                image = rotateImage(image, 180);
            } else if (orientation == 8){//180도
                image = rotateImage(image, 270);
            }

            Image tmp = image.getScaledInstance(width, height, Image.SCALE_SMOOTH);
            int imgType = image.getType() == 0 ? 1 : image.getType();
            BufferedImage resized = new BufferedImage(width, height, imgType);
            Graphics2D g2d = resized.createGraphics();
            g2d.drawImage(tmp, 0, 0, null);
            g2d.dispose();

            File output = new File(imgTargetPath);
            ImageIO.write(resized, imgFormat, output);

        }catch (IOException e){
            log.debug(e.getMessage());
        }finally {
            try {
                if(fis != null)fis.close();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                log.debug(e.getMessage());
            }
        }
        return imgTargetPath;
	}

	public static BufferedImage rotateImage(BufferedImage orgImage,int radians) {
        BufferedImage newImage;
         if(radians==90 || radians==270){
               newImage = new BufferedImage(orgImage.getHeight(),orgImage.getWidth(),orgImage.getType());
        } else if (radians==180){
               newImage = new BufferedImage(orgImage.getWidth(),orgImage.getHeight(),orgImage.getType());
        } else{
                return orgImage;
        }
        Graphics2D graphics = (Graphics2D) newImage.getGraphics();
        graphics.rotate(Math. toRadians(radians), newImage.getWidth() / 2, newImage.getHeight() / 2);
        graphics.translate((newImage.getWidth() - orgImage.getWidth()) / 2, (newImage.getHeight() - orgImage.getHeight()) / 2);
        graphics.drawImage(orgImage, 0, 0, orgImage.getWidth(), orgImage.getHeight(), null );

         return newImage;
 }


	public static String saveTextFile(String data,String filePath,String fileNm) {

            // 폴더 생성
            File destinationFile = new File(filePath);
            if(!destinationFile.exists()) {
                destinationFile.setExecutable(false,true);
                destinationFile.setReadable(true);
                destinationFile.setWritable(false,true);
                destinationFile.mkdirs();
            }
            // true 지정시 파일의 기존 내용에 이어서 작성
            File file = new File(filePath+fileNm);
            if( file.exists() ){
                if(file.delete()){
                    log.debug("파일 삭제 성공");
                }else{
                    log.debug("파일 삭제 실패");
                }
            }

            FileWriter fw = null;
            try {
                fw = new FileWriter(file, false);

            // 파일안에 문자열 쓰기
            fw.write(data);
            fw.flush();

            } catch (IOException e) {
                // TODO Auto-generated catch block
                filePath = null;
                log.debug(e.getMessage());
            }finally {

                try {
                    if(fw != null)fw.close();
                } catch (IOException e) {
                    // TODO Auto-generated catch block
                    log.debug(e.getMessage());
                }
            }


	    return filePath;
	}
	@SuppressWarnings("unused")
    public static void zipFileDownload(String filePathNm,String fileNm,String zipFileNm, HttpServletRequest request, HttpServletResponse response)
    {
        int bufferSize = 1024 * 2;

        ZipOutputStream zos = null;
        BufferedInputStream bis = null;
        FileInputStream fileStream = null;
        try {

            if (request.getHeader("User-Agent").indexOf("MSIE 5.5") > -1) {
                response.setHeader("Content-Disposition", "filename=" + zipFileNm + ".zip" + ";");
            } else {
                response.setHeader("Content-Disposition", "attachment; filename=" + zipFileNm + ".zip" + ";");
            }
            response.setHeader("Content-Transfer-Encoding", "binary");


            OutputStream os = response.getOutputStream();
            zos = new ZipOutputStream(os); // ZipOutputStream
            zos.setLevel(8); // 압축 레벨 - 최대 압축률은 9, 디폴트 8

            File sourceFile = new File(filePathNm+fileNm);
            fileStream =new FileInputStream(sourceFile);
            bis = new BufferedInputStream(fileStream);
            ZipEntry zentry = new ZipEntry(fileNm);
            zentry.setTime(sourceFile.lastModified());
            zos.putNextEntry(zentry);

            byte[] buffer = new byte[bufferSize];
            int cnt = 0;
            while ((cnt = bis.read(buffer, 0, bufferSize)) != -1) {
                zos.write(buffer, 0, cnt);
            }
            zos.closeEntry();
        } catch(IOException e){
            log.debug(e.getMessage());
            throw new BizException("fail.common.file");
        } finally {
            // TODO: handle finally clause
            try {
                if(zos != null) zos.close();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                log.debug(e.getMessage());
            }
            try {
                if(bis != null)  bis.close();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                log.debug(e.getMessage());
            }
            try {
                if(fileStream != null)  fileStream.close();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                log.debug(e.getMessage());
            }

        }
    }
	@SuppressWarnings("unused")
    public static void zipFileDownload(List<Map<String,String>> fileList, HttpServletRequest request, HttpServletResponse response)
    {
        int bufferSize = 1024 * 2;
        String ouputName = "Download";

        ZipOutputStream zos = null;
        BufferedInputStream bis = null;
        FileInputStream fileStream = null;
        try {

            if (request.getHeader("User-Agent").indexOf("MSIE 5.5") > -1) {
                response.setHeader("Content-Disposition", "filename=" + ouputName + ".zip" + ";");
            } else {
                response.setHeader("Content-Disposition", "attachment; filename=" + ouputName + ".zip" + ";");
            }
            response.setHeader("Content-Transfer-Encoding", "binary");


            OutputStream os = response.getOutputStream();
            zos = new ZipOutputStream(os); // ZipOutputStream
            zos.setLevel(8); // 압축 레벨 - 최대 압축률은 9, 디폴트 8

            int    i = 0;
            for(Map<String, String> fileMap : fileList){
                File sourceFile = new File(fileMap.get("atchFilePathNm"));
                fileStream =new FileInputStream(sourceFile);
                bis = new BufferedInputStream(fileStream);
                ZipEntry zentry = new ZipEntry(fileMap.get("atchFileLogcNm"));
                zentry.setTime(sourceFile.lastModified());
                zos.putNextEntry(zentry);

                byte[] buffer = new byte[bufferSize];
                int cnt = 0;
                while ((cnt = bis.read(buffer, 0, bufferSize)) != -1) {
                    zos.write(buffer, 0, cnt);
                }
                zos.closeEntry();

                i++;
            }

        } catch(IOException e){
            log.debug(e.getMessage());
        } finally {
            // TODO: handle finally clause
            try {
                if(zos != null) zos.close();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                log.debug(e.getMessage());
            }
            try {
                if(bis != null)  bis.close();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                log.debug(e.getMessage());
            }
            try {
                if(fileStream != null)  fileStream.close();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                log.debug(e.getMessage());
            }

        }
    }
	public static boolean isImage(String filepath)
    {
	    File f = new File(filepath);
	    try {
            return (ImageIO.read(f) != null);
        } catch (IOException e) {
            return false;
        }
	}
	public static boolean isImage(File file)
    {
        try {
            return (ImageIO.read(file) != null);
        } catch (IOException e) {
            return false;
        }
    }
	
	public static String stringFileSave(String basePath, String fileName, String val) {
	    String filePath = null;
	    Calendar cal = Calendar.getInstance();
	    BufferedWriter output = null;
	    String dateString;
	    dateString = String.format("%04d/%02d/%02d", cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH));
	    try {
    	    File targetFile = new File(basePath+dateString+"/");
    	    if(!targetFile.exists()) {
    	        targetFile.setExecutable(false,true);
    	        targetFile.setReadable(true);
    	        targetFile.setWritable(false,true);
    	        targetFile.mkdirs();
    	    }
    	    filePath = targetFile.getPath()+"/"+fileName;
    	    targetFile.createNewFile();
    	    output = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(filePath), "UTF8"));
    	    output.write(val);
            
            
	    } catch(UnsupportedEncodingException uee) {
	        log.debug(uee.getMessage());
	        return null;
	    } catch(IOException ioe) {
	        log.debug(ioe.getMessage());
	        return null;
	    }finally {
	        if(output != null) {
                try {
                    output.close();
                } catch (IOException e) {
                    // TODO Auto-generated catch block
                    log.debug(e.getMessage());
                }
	        }
        }

	    return filePath;
	}
}
