package kfi.core.vo;

import java.io.Serializable;
import kfi.core.config.annotation.Auth.Role;
import lombok.Data;

@Data
public class UserSessionVO implements Serializable {
    private static final long serialVersionUID = 4220995889836229077L;
	String userId = null; 		   // 사용자 ID
	String userNm = null;          // 사용자 명
	String userTyCd = null;        // 사용자유형코드
	String deptId = null;          // 부서ID
	String deptNm = null;          // 부서명
	String cmpyId = null;          // 업체ID
    String cmpyNm = null;          // 업체명
	String loginId  = null;        // 로그인 ID
	Role role    = null;
	String sysCd  = null;        // 시스템 구분
}
