package kfi.core.support.json;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.core.MethodParameter;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import kfi.core.exception.CoreException;
import kfi.core.util.ObjectUtil;
import lombok.experimental.UtilityClass;

/**
 *
 * @className : JsonConvertData
 * @description : Josn 데이터라를 파싱한다.
 *
 * @modification : 2020. 4. 10.(수정자) 최초생성
 *
 * @author hirob
 * @Date 2020. 4. 10.
 * @version 1.0
 * @see
 *  == 개정이력(Modification Information) ==
 *
 *   수정일                     수정자                  수정내용
 *  -------    --------    ---------------------------
 *  
 * Copyright (C) by KFI All right reserved.
 * (C) by KFI All right reserved.
 */
@UtilityClass
public class JsonConvertData {
	
	@SuppressWarnings("unchecked")
	public Object getDataObject(HttpServletRequest request,MethodParameter parameter, Map<String, Object> paramdMap) throws JsonParseException, JsonMappingException, IOException, InstantiationException, IllegalAccessException, ClassNotFoundException {
		MultiValueMap<String, Object> paramdMultiValueMap = new LinkedMultiValueMap<String, Object>();
		Class<?> paramType = parameter.getParameterType();
		String paramTypeName = parameter.getGenericParameterType().getTypeName();
		ParameterizedType parameterizedType = null;
        Type[] types = null;
		if(paramTypeName.indexOf("<") != -1) {
			parameterizedType = ((ParameterizedType) parameter.getGenericParameterType());
			types = parameterizedType.getActualTypeArguments();
		}
		
		ObjectMapper mapper = new ObjectMapper();
		String strJson = getRequestBodyJson(request);
		if(strJson == null || strJson.equals("")) {
			if(Map.class.isAssignableFrom(parameter.getParameterType())) {
				return paramdMap;
			}else if(List.class.isAssignableFrom(parameter.getParameterType())) {
				List<Object> objectList = new ArrayList<>();
				if(paramdMap.size() > 0) {
					objectList.add(paramdMap);
				}
				return objectList;
			}else {
				Class<?> c = Class.forName(paramType.getName());
				return c.newInstance();
			}
			
		}
        Object jsonObject = mapper.readValue(strJson, Object.class);
        
        if(jsonObject instanceof Map) {
        	paramdMap.putAll((Map<String, Object>) jsonObject);

        }else if(jsonObject instanceof List) {
            return ObjectUtil.convertListMapToListObject(jsonObject,types);
        }
        if(MultiValueMap.class.isAssignableFrom(parameter.getParameterType())) {
        	paramdMultiValueMap =(MultiValueMap<String, Object>) jsonObject;
			return paramdMultiValueMap;
		}else if(Map.class.isAssignableFrom(parameter.getParameterType())) {
			return ObjectUtil.convertMapToObject(paramdMap,types);
		}else if(List.class.isAssignableFrom(parameter.getParameterType())) {
			List<Object> objectList = new ArrayList<>();
			objectList.add(paramdMap);
			return ObjectUtil.convertListMapToListObject(objectList,types);
		}else {
			Object object = null;
            object = Class.forName(paramType.getName()).newInstance(); 
			return ObjectUtil.convertMapToObject(paramdMap, object);
		}
	}
	public String getRequestBodyJson(HttpServletRequest request) {
		String jsonText = null;
		try {
			BufferedReader reader = request.getReader();
			jsonText = readAll(reader);
		}catch (IOException e) {
			// TODO: handle exception
			throw new CoreException("error.json.parse");
		}
		return jsonText;
    }
	private String readAll(Reader rd) throws IOException {
	    StringBuilder sb = new StringBuilder();
	    int cp;
	    while ((cp = rd.read()) != -1) {
	      sb.append((char) cp);
	    }
	    return sb.toString();
	}
}