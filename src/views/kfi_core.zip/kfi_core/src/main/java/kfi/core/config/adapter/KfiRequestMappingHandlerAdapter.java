/*
 * Copyright 2014 MOSPA(Ministry of Security and Public Administration).
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */
package kfi.core.config.adapter;

import java.util.ArrayList;
import java.util.List;
import org.springframework.web.method.annotation.MapMethodProcessor;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerAdapter;
import kfi.core.config.annotation.Param;
import kfi.core.config.resolver.AnnotationParamArgumentResolver;


/**
 *
 * @className : KfiRequestMappingHandlerAdapter
 * @description :  * <p/><b>NOTE:</b> <pre>Spring 3.1부터 AnnotationMethodHandlerAdapter는 deprecated되고 RequestMappingHandlerAdapter를 대신 써야한다.
 * 또한 Map타입의 Argument를 처리해주는 MapMethodProcessor가 추가되어 RequestMappingHandlerAdapter를 그대로 써줄 경우
 * AnnotationParamArgumentResolver를 쓸 수 없다.
 * HandlerMethodArgumentResolver을 implements하는  AnnotationParamArgumentResolver를 구현하였으며
 * RequestMapping에서는 MapMethodProcessor보다 AnnotationParamArgumentResolver가 먼저 ArgumentResolver로  인식될 수 있도록
 * ArgumentResolver list의 순서를 변경해준다.
 *
 * @modification : 2018. 8. 1.(수정자) 최초생성
 *
 * @author hirob
 * @Date 2020. 3. 20.
 * @version 1.0
 * @see
 *  == 개정이력(Modification Information) ==
 *
 *   수정일      수정자           수정내용
 *  -------    --------    ---------------------------
 *
 * Copyright (C) by KFI All right reserved.
 */
public class KfiRequestMappingHandlerAdapter extends RequestMappingHandlerAdapter {

    /**
     * AnnotationParamArgumentResolver를 쓰기 위하여
     * ArgumentResolver list에서 MapMethodProcessor보다 앞에 AnnotationParamArgumentResolver를 추가한다.
     * MapMethodProcessor의 기능을 살리기 위해 AnnotationParamArgumentResolver를 쓸 때는 @Param 을 붙여야 한다.
     *
     * @see Param
     */
    @Override
    public void afterPropertiesSet() {
        super.afterPropertiesSet();
        if (getArgumentResolvers() != null) {
            // List<HandlerMethodArgumentResolver> resolvers = new
            // ArrayList<HandlerMethodArgumentResolver>(getArgumentResolvers().getResolvers());
            List<HandlerMethodArgumentResolver> resolvers = new ArrayList<HandlerMethodArgumentResolver>(getArgumentResolvers());
            int mapMethodProcessorInx = -1;
            int paramMapInx = -1;
            HandlerMethodArgumentResolver paramMapArgResolver = null;

            for (int inx = 0; inx < resolvers.size(); inx++) {
                HandlerMethodArgumentResolver resolver = resolvers.get(inx);
                if (resolver instanceof MapMethodProcessor) {
                    mapMethodProcessorInx = inx;
                } else if (resolver instanceof AnnotationParamArgumentResolver) {
                    paramMapInx = inx;
                }
            }

            if (paramMapInx != -1) {
                paramMapArgResolver = resolvers.remove(paramMapInx);
                resolvers.add(mapMethodProcessorInx, paramMapArgResolver);
                setArgumentResolvers(resolvers);
            }
        }
    }
}
