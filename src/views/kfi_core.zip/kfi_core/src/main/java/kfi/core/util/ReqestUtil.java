package kfi.core.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import javax.servlet.http.HttpServletRequest;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import kfi.core.exception.CoreException;

/**
 *
 * @className : ReqestUtil
 * @description : Request  Utility Class 이다.
 *
 * @modification : 2018. 8. 1.(수정자) 최초생성
 *
 * @author AA lee
 * @Date 2018. 8. 1.
 * @version 1.0
 * @see
 *  == 개정이력(Modification Information) ==
 *
 *   수정일      수정자           수정내용
 *  -------    --------    ---------------------------
 *
 * Copyright (C) by AIRA All right reserved.
 */
public class ReqestUtil {

	public static  String getRequestBody(HttpServletRequest request) {
		String jsonText = null;
		try {
			BufferedReader reader = request.getReader();
			jsonText = readAll(reader);
		}catch (IOException e) {
			// TODO: handle exception
			throw new CoreException("error.json.parse");
		}
		return jsonText;
    }

	private static String readAll(Reader rd) throws IOException {
	    StringBuilder sb = new StringBuilder();
	    int cp;
	    while ((cp = rd.read()) != -1) {
	      sb.append((char) cp);
	    }
	    return sb.toString();
	}
	public static String getUserIP(HttpServletRequest request) {
	    String ip = null;
	    if(request == null)
	    {
	        request= getCurrentRequest();
	    }
	    if(request != null)
	    {
    	    ip = request.getHeader("X-FORWARDED-FOR");

    	    if (ip == null) {
    	        ip = request.getHeader("Proxy-Client-IP");
    	    }
    	    if (ip == null) {
    	        ip = request.getHeader("WL-Proxy-Client-IP");
    	    }
    	    if (ip == null) {
    	        ip = request.getHeader("HTTP_CLIENT_IP");
    	    }
    	    if (ip == null) {
    	        ip = request.getHeader("HTTP_X_FORWARDED_FOR");
    	    }
    	    if (ip == null) {
    	        ip = request.getRemoteAddr();
    	    }
	    }
	    return ip;
    }
	public static String getUserIP() {
        HttpServletRequest request= getCurrentRequest();
        String ip = "";
        if(request != null) {
            ip = request.getHeader("X-FORWARDED-FOR");
            if (ip == null) {
                ip = request.getHeader("Proxy-Client-IP");
            }
            if (ip == null) {
                ip = request.getHeader("WL-Proxy-Client-IP");
            }
            if (ip == null) {
                ip = request.getHeader("HTTP_CLIENT_IP");
            }
            if (ip == null) {
                ip = request.getHeader("HTTP_X_FORWARDED_FOR");
            }
            if (ip == null) {
                ip = request.getRemoteAddr();
            }
        }
        return ip;
    }

	public static String getUri() {
        HttpServletRequest request= getCurrentRequest();
        if(request == null)
        {
            return null;
        }
        else
        {
            return request.getRequestURI();
        }
    }


	public static HttpServletRequest getCurrentRequest() {
	    try {
	        ServletRequestAttributes sra = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
	        HttpServletRequest servletRequest = sra.getRequest();
	        return servletRequest;
	    }catch (IllegalStateException e) {
            // TODO: handle exception
	        return null;
        }


   }
}
